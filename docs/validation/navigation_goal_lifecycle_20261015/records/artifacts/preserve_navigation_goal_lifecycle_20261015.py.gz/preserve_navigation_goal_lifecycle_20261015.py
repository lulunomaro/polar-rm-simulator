"""Seal literal joint Qt/PB evidence after final quality, excluding credentials/binaries."""
from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs/validation/navigation_goal_lifecycle_20261015';BASE='97828ded30b823fac8b14542aba153548a33340a'
def sha(raw):return hashlib.sha256(raw).hexdigest()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-11/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,expected in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==expected,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not OUT.exists(),'Immutable package already exists'
directories=['navigation-goal-preservation-20261015-01','navigation-goal-preservation-20261015-02', 'navigation-goal-lifecycle-focused-20261015-01', 'nav2-goal-backend-focused-20261015-01', 'nav2-goal-backend-focused-20261015-02', 'nav2-goal-backend-focused-20261015-03', 'quality-aim-followup-20261014-11', 'aim-followup-quality-driver-20261014-11', 'navigation-goal-coop-actual-20261015-01', 'navigation-goal-coop-actual-20261015-02', 'navigation-goal-coop-actual-20261015-03', 'navigation-goal-coop-actual-20261015-04', 'navigation-goal-coop-driver-20261015-01', 'navigation-goal-coop-driver-20261015-02', 'navigation-goal-coop-driver-20261015-03', 'navigation-goal-coop-driver-20261015-04']
files=[]
for name in directories:
    d=ROOT/'artifacts'/name;assert d.is_dir(),name
    files += [p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
source=['rm_match/integrations/navigation_goal_lifecycle.py', 'rm_match/integrations/nav2_goal_backend.py', 'rm_match/platform_v2/decision_contracts.py', 'tools/pb_coop_cleanup.py', 'tools/navigation_goal_session.py', 'tools/qa_navigation_goal_client.py', 'tools/qa_navigation_goal_supervisor.py', 'tools/qa_navigation_goal_coop_sil.py', 'tests/test_navigation_goal_lifecycle.py', 'tests/test_nav2_goal_backend.py', 'docs/NAVIGATION_GOAL_LIFECYCLE.md', 'docs/UNIVERSAL_PLUGIN_INTERFACES.md', 'docs/COOP_PLAYABLE_PATH.md', 'docs/IMPLEMENTATION_PROGRESS.md', 'artifacts/goal_lifecycle_client_main_20261015.py', 'artifacts/create_goal_lifecycle_probes_20261015.py', 'artifacts/create_goal_driver_20261015.py', 'artifacts/run_navigation_goal_coop_20261015.py', 'artifacts/run_aim_followup_quality_20261014.py', 'artifacts/create_navigation_goal_preservation_20261015.py', 'artifacts/preserve_navigation_goal_lifecycle_20261015.py']
files += [ROOT/name for name in source]
rows=[]
for p in sorted(set(files)):
    original=p.relative_to(ROOT).as_posix();raw=p.read_bytes()
    assert p.suffix.lower() not in {'.exe','.elf','.dll','.onnx','.key','.pem','.pfx','.git'},original
    # Explicit focused stdout/stderr captures are UTF-8 text despite .bin.
    # They are not executable/model binary assets.
    if p.suffix=='.bin':
        assert p.parent.name in {'nav2-goal-backend-focused-20261015-01','nav2-goal-backend-focused-20261015-02','nav2-goal-backend-focused-20261015-03'} and p.name in {'stdout.bin','stderr.bin'},original
        raw.decode('utf8') # Read-only text stdout/stderr captures, not binary assets.
    assert raw[:4]!=b'\x7fELF' and raw[:2]!=b'MZ',original
    assert p.name not in {'SDK_EVENTS.jsonl','admission.json','UserData'} and not p.name.endswith('.local.json'),original
    assert len(raw)<=12*1024*1024,original
    if p.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,original
    compression='gzip' if len(raw)>4096 and p.suffix not in {'.gz','.png'} else 'literal';stored=Path('records')/original
    if compression=='gzip':stored=Path(str(stored)+'.gz');data=gzip.compress(raw,mtime=0)
    else:data=raw
    rows.append((stored,data,dict(original_path=original,original_bytes=len(raw),original_sha256=sha(raw),
        stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for stored,data,_ in rows:
    p=OUT/stored;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit=BASE,
 qualification='goal-only asynchronous library and real original offscreen Qt/PB Nav2 cancellation then second-goal completion; synthetic high-level policy, first three actual failures retained; no match tree/feedback-linked velocity/aim/visible desktop/performance/LAN/full match acceptance',records=[r[2] for r in rows])
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'# Literal evidence/source bytes; no checkout conversion.\n* -text -whitespace\n*.gz binary\n*.png binary\n*.bin binary\n')
print(json.dumps(dict(records=len(rows),original_bytes=sum(r[2]['original_bytes'] for r in rows),stored_bytes=sum(r[2]['stored_bytes'] for r in rows),manifest_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()))))
