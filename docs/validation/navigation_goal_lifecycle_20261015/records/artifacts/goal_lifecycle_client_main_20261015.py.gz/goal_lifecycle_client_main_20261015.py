def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--spec',required=True);p.add_argument('--spec-sha256',required=True);p.add_argument('--run',action='store_true')
    args=p.parse_args(argv);spec,out=load_spec(args.spec,args.spec_sha256)
    if not args.run:return 0
    if sys.platform!='linux':raise ValueError('actual_linux_required')
    bootstrap(spec,checked_ref(spec['environment_ref']),sys.argv[1:] if argv is None else argv)
    from tools.qa_pb_navigation_sil import AlgorithmObserver,recorded_transform
    from rm_match.integrations.navigation_goal_lifecycle import NavigationGoalLifecycle
    from rm_match.integrations.nav2_goal_backend import Nav2GoalBackend,Nav2GoalSettings
    from rm_match.platform_v2.contracts import IDENTITY
    from lifecycle_msgs.srv import GetState
    from geometry_msgs.msg import PoseStamped
    from nav2_msgs.msg import Costmap
    from rclpy.qos import QoSProfile,ReliabilityPolicy,DurabilityPolicy
    from rclpy.time import Time
    stop=threading.Event();old={sig:signal.getsignal(sig) for sig in (signal.SIGINT,signal.SIGTERM)}
    for sig in old:signal.signal(sig,lambda *_:stop.set())
    started=time.perf_counter();end=started+spec['max_wall_seconds'];ident=process_identity()
    observer=backend=engine=None;errors=[];events=[];completed=False;clients=[];goal_report={};snapshots=[]
    grid_lock=threading.Lock();grid_cache={'last':None,'count':0,'error':None}
    def event(name,**values):
        if len(events)>=128:raise ValueError('bounded_goal_events')
        events.append(dict(event=name,receive_clock='linux_local_perf_counter',receive_wall=time.perf_counter(),**values))
    try:
        observer=AlgorithmObserver(spec['namespace'],84,receive_clock='linux_local_perf_counter')
        backend=Nav2GoalBackend(observer.node,Nav2GoalSettings('compute_path_then_follow',
            planner_action=spec['namespace']+'/compute_path_to_pose',controller_action=spec['namespace']+'/follow_path',
            planner_id='GridBased',controller_id='FollowPath',goal_checker_id='general_goal_checker'))
        engine=NavigationGoalLifecycle(backend,deadline_mode='opaque');engine.reset(dict(robot_id='red_sentry',episode=0,binding_epoch=1))
        topic=spec['namespace']+'/global_costmap/costmap_raw'
        def receive_grid(message):
            try:
                with grid_lock:
                    grid_cache['count']+=1
                    if grid_cache['count']>512:raise ValueError('bounded_costmaps')
                    grid_cache['last']=costmap_snapshot(message,grid_cache['count'],time.perf_counter(),topic)
            except BaseException as exc:grid_cache['error']=type(exc).__name__
        observer.subs.append(observer.node.create_subscription(Costmap,topic,receive_grid,
            QoSProfile(depth=1,reliability=ReliabilityPolicy.RELIABLE,durability=DurabilityPolicy.TRANSIENT_LOCAL)))
        for name in ('controller_server','planner_server'):
            clients.append((name,observer.node.create_client(GetState,spec['namespace']+'/'+name+'/get_state')))
        publish_json(out/'READY.json',dict(schema='polar.pb.external-goal-ready.v1',run_uuid=spec['run_uuid'],session_run_uuid=spec['session_run_uuid'],
            namespace=spec['namespace'],domain_id=84,state='OBSERVING_NO_INPUT_PUBLISHED',**ident,environment_sha256=spec['environment_ref']['sha256'],
            source_sha256=spec['source_sha256'],spec_sha256=args.spec_sha256,sensor_published=False,goal_sent=False,lifecycle_changed=False))
        state_futures={};states={};last_seq=-1;phase='first';target=None;active_at=None;event_key=None
        def map_target():
            transform=observer.buffer.lookup_transform('map','base_link',Time())
            pose,saved=goal_from_estimate(transform,PoseStamped)
            with grid_lock:grid=grid_cache['last']
            if grid is None:return None
            decision=geometry_decision(*grid,saved)
            if not decision['ready']:return None
            q=pose.pose.orientation;yaw=math.atan2(2*(q.w*q.z+q.x*q.y),1-2*(q.y*q.y+q.z*q.z))
            goal=dict(frame='map',position_m=[float(pose.pose.position.x),float(pose.pose.position.y)],yaw_rad=yaw)
            event('actual_estimate_goal',source_transform=recorded_transform(transform),goal=goal,geometry_decision=decision)
            return goal
        while not stop.is_set() and time.perf_counter()<end:
            if observer.errors or grid_cache['error']:raise RuntimeError('actual_observer_failed')
            for name,client in clients:
                future=state_futures.get(name)
                if future is None and client.service_is_ready():state_futures[name]=client.call_async(GetState.Request())
                elif future is not None and future.done():
                    value=future.result().current_state.id
                    if type(value) is not int:raise ValueError('actual_lifecycle_type')
                    states[name]=value
                    if value!=3:state_futures.pop(name)
            current=engine.poll()
            key=(current['active'],current['state'],tuple((g['state'],g['terminal'],g['cancel_acknowledged'],tuple(g['goal_uuids'].values())) for g in current['goals']))
            if key!=event_key:
                if len(snapshots)>=128:raise ValueError('bounded_lifecycle_snapshots')
                snapshots.append(current);event_key=key
            if current['fault']:raise RuntimeError('lifecycle_fault:'+current['fault'])
            goals=current['goals']
            if phase=='first' and goals and goals[0]['goal_uuids']['navigation'] is not None:
                if active_at is None:active_at=time.perf_counter()
                if time.perf_counter()-active_at>=.2 and goals[0]['state']=='active':phase='hold'
                elif goals[0]['terminal']:raise RuntimeError('first_goal_finished_before_cancel_probe')
            if phase=='hold' and goals and goals[0]['terminal']:
                if not (goals[0]['state']=='canceled' and goals[0]['cancel_acknowledged'] and goals[0]['stop_confirmed']):raise RuntimeError('actual_cancel_not_confirmed')
                event('real_cancel_ack_and_terminal',operation=goals[0]);phase='second';target=None
            if phase=='second' and len(goals)==2 and goals[1]['terminal']:
                if not (goals[1]['state']=='succeeded' and goals[1]['stop_confirmed']):raise RuntimeError('second_goal_not_successful')
                completed=True;phase='done';event('second_real_goal_completed',operation=goals[1])
            with observer.lock:
                requests=[r['value'] for r in observer.rows if r.get('topic_kind')=='request']
            raw=requests[-1] if requests else None
            if raw is not None and raw['observed_seq']>last_seq and gate_active(states) and backend.ready() and observer.map_count and observer.odom_count:
                source={key:raw[key] for key in IDENTITY}
                if phase in ('first','second') and target is None:
                    try:target=map_target()
                    except Exception:target=None
                if phase=='hold':command=dict(behavior='hold',reason='actual_cancel_confirmation_probe')
                elif phase in ('first','second') and target is not None:command=dict(behavior='navigate_to_pose',reason='actual_estimated_relative_goal',goal=target)
                else:command=None
                if command is not None:
                    intent=dict(schema='polar.sim.decision-intent.v1',**source,kind='decision',mode='navigation_intent',command=command)
                    engine.submit(intent,expected_source=source);last_seq=source['observed_seq']
                    event_name='hold_original_intent' if phase=='hold' else None
                    if event_name and not any(r['event']==event_name for r in events):event(event_name,intent=intent)
            stop.wait(.005)
        if not stop.is_set() and not completed:raise TimeoutError('actual_goal_scenario_bound')
    except BaseException as exc:
        errors.append(type(exc).__name__+':'+str(exc));traceback.print_exc()
    finally:
        resource_deadline=time.perf_counter()+1.
        if engine is not None:
            engine.request_stop()
            while time.perf_counter()<resource_deadline:
                final=engine.poll()
                if final['clean']:break
                time.sleep(.005)
            if not engine.snapshot()['clean']:errors.append('goal_stop_unproved')
            goal_report=dict(schema='polar.sim.navigation-goal-scenario.v1',completed=completed,lifecycle=engine.snapshot(),snapshots=snapshots,
                cancel_ack_is_terminal=False,sensor_published=False,cmd_vel_published=False,source_clock='original_Windows_header_opaque_in_Linux')
        if backend is not None:
            try:backend.destroy()
            except BaseException as exc:errors.append('backend_destroy:'+type(exc).__name__)
        if observer is not None:
            for _,client in clients:
                try:observer.node.destroy_client(client)
                except BaseException as exc:errors.append('state_client_close:'+type(exc).__name__)
            try:observer.close()
            except BaseException as exc:errors.append('observer_close:'+type(exc).__name__)
            errors+=observer.errors
            (out/'ROS_SOURCE.jsonl').write_text(''.join(json.dumps(row,allow_nan=False,separators=(',',':'))+'\n' for row in observer.rows),encoding='utf8')
        for name,expected in spec['source_sha256'].items():
            if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=expected:errors.append('source_changed:'+name)
        (out/'GOAL_REPORT.json').write_text(json.dumps(goal_report,indent=2,allow_nan=False)+'\n',encoding='utf8')
        (out/'EXTERNAL_EVENTS.jsonl').write_text(''.join(json.dumps(r,allow_nan=False,separators=(',',':'))+'\n' for r in events),encoding='utf8')
        cleanup=cleanup_record(spec['run_uuid'],ident,errors,observer is not None and observer.thread.is_alive());publish_json(out/'CLEANUP.json',cleanup)
        result=dict(schema='polar.pb.external-goal-result.v1',run_uuid=spec['run_uuid'],session_run_uuid=spec['session_run_uuid'],namespace=spec['namespace'],
            goal_completed=completed,cleanup=cleanup,source_sha256=spec['source_sha256'],environment_ref=spec['environment_ref'],goal_report=goal_report,
            algorithm_input_has_truth=False,lifecycle_changed=False,sensor_published=False,cmd_vel_published=False,
            scope='synthetic original-source goal/hold lifecycle policy with actual Nav2 actions, sourced PB sensors/controller; no match tree/feedback integration')
        (out/'RESULT.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf8')
        for sig,handler in old.items():signal.signal(sig,handler)
    return 0 if completed and cleanup['clean'] else 2

if __name__=='__main__':raise SystemExit(main())
