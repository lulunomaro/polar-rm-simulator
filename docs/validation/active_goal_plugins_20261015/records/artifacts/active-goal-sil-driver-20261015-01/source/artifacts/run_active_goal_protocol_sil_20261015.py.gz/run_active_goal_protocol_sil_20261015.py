"""One fresh bounded synthetic active-goal SIL with an outer owned Job proof."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
import traceback

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.qa_active_goal_protocol_sil import SOURCE_FILES
from rm_match.deployment.windows_owned_job import WindowsOwnedJobProcess


def write(path,value):
    path.write_text(json.dumps(value,allow_nan=False,indent=2)+'\n',encoding='utf8')


def main():
    actual=ROOT/'artifacts/active-goal-protocol-sil-20261015-01'
    out=ROOT/'artifacts/active-goal-sil-driver-20261015-01'
    if out.exists() or actual.exists():raise RuntimeError('fresh_output_required')
    out.mkdir(parents=True)
    files=(*SOURCE_FILES,'tests/test_active_goal_protocol_audit.py',
        'artifacts/run_active_goal_protocol_sil_20261015.py')
    def hashes():
        return [dict(path=p,sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),
            size=(ROOT/p).stat().st_size) for p in files]
    before=hashes();write(out/'SOURCE_BEFORE.json',dict(files=before))
    for relative in ('tests/test_active_goal_protocol_audit.py',
                     'artifacts/run_active_goal_protocol_sil_20261015.py'):
        target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/relative).read_bytes())
    command=[sys.executable,str(ROOT/'tools/qa_active_goal_protocol_sil.py'),
        '--run','--out',str(actual),'--duration','4']
    write(out/'COMMAND.json',dict(argv=command,cwd=str(ROOT),timeout_s=40.,duration_s=4.,
        scope='synthetic active-goal protocol over real low-rate MuJoCo; not RTF or native algorithm acceptance'))
    owner=None;reader=None;errors=[];forced=False;job_empty=False;code=None
    started=time.perf_counter()
    with (out/'stdout.log').open('wb') as sink,(out/'stderr.log').open('wb') as stderr:
        try:
            owner=WindowsOwnedJobProcess(command,cwd=str(ROOT),env=dict(os.environ),stderr=stderr)
            owner.stdin.close()
            def drain():
                try:shutil.copyfileobj(owner.stdout,sink)
                except BaseException as exc:errors.append('stdout:'+type(exc).__name__)
            reader=threading.Thread(target=drain,name='active-goal-driver-stdout',daemon=True)
            reader.start()
            code=owner.wait(timeout=40.)
            job_empty=owner.active_processes()==0
            if not job_empty:
                forced=True
                write(out/'FORCED_RESIDUAL_CLEANUP.json',owner.cleanup(time.perf_counter()+1.5))
                errors.append('owned_job_nonempty_after_probe_exit')
        except BaseException as exc:
            errors.append(type(exc).__name__)
            (out/'failure.log').write_text(traceback.format_exc(),encoding='utf8')
            if owner is not None:
                forced=True
                write(out/'FORCED_FAILURE_CLEANUP.json',owner.cleanup(time.perf_counter()+1.5))
                code=owner.poll()
        finally:
            if reader is not None:reader.join(1.5)
            if reader is not None and reader.is_alive():errors.append('stdout_reader_not_stopped')
            if owner is not None:
                try:
                    job_empty=owner.active_processes()==0
                    owner.stdout.close()
                    owner.release_handles()
                except BaseException as exc:errors.append('release:'+type(exc).__name__)
    elapsed=time.perf_counter()-started
    after=hashes();write(out/'SOURCE_AFTER.json',dict(files=after))
    result_path=actual/'RESULT.json'
    probe=json.loads(result_path.read_text(encoding='utf8')) if result_path.exists() else None
    result=dict(passed=bool(code==0 and not errors and before==after and probe and probe.get('passed')
        and probe.get('source_unchanged') and not forced and job_empty),returncode=code,
        elapsed_s=elapsed,process_reaped=code is not None,owned_job_empty=job_empty,
        forced_cleanup=forced,source_unchanged=before==after,source_file_count=len(before),
        errors=errors,probe_result=str(result_path),qualification='synthetic_protocol_only')
    write(out/'RESULT.json',result)
    print(json.dumps(result,allow_nan=False))
    return 0 if result['passed'] else 2


if __name__=='__main__':raise SystemExit(main())
