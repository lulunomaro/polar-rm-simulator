"""Fresh SIL 03 with one shared outer cleanup deadline.

Leader wait does not prove Windows Job accounting has removed every process.
Observe real active_processes repeatedly inside one original 1.5 s cleanup
deadline shared by Job queries/reaping, reader join and handle release. No
signal is sent on a normally empty Job. Every wait uses the remaining budget;
passing also requires the final cleanup completion to precede that deadline.
This changes no production sensor, SDK 150 ms or PB 50 ms budget.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
import traceback

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.qa_active_goal_protocol_sil import SOURCE_FILES
from rm_match.deployment.windows_owned_job import WindowsOwnedJobProcess


def write(path,value):
    path.write_text(json.dumps(value,allow_nan=False,indent=2)+'\n',encoding='utf8')


def main():
    if len(sys.argv)!=1:raise ValueError('no_arguments_supported')
    actual=ROOT/'artifacts/active-goal-protocol-sil-20261015-03'
    out=ROOT/'artifacts/active-goal-sil-driver-20261015-03'
    if out.exists() or actual.exists():raise RuntimeError('fresh_output_required')
    out.mkdir(parents=True)
    files=(*SOURCE_FILES,'tests/test_active_goal_protocol_audit.py',
        'tests/test_navigation_plugin.py','artifacts/run_active_goal_protocol_sil_20261015_03.py')
    def hashes():
        return [dict(path=p,sha256=hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),
            size=(ROOT/p).stat().st_size) for p in files]
    before=hashes();write(out/'SOURCE_BEFORE.json',dict(files=before))
    for relative in ('tests/test_active_goal_protocol_audit.py','tests/test_navigation_plugin.py',
                     'artifacts/run_active_goal_protocol_sil_20261015_03.py'):
        target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/relative).read_bytes())
    command=[sys.executable,str(ROOT/'tools/qa_active_goal_protocol_sil.py'),
        '--run','--out',str(actual),'--duration','4']
    write(out/'COMMAND.json',dict(argv=command,cwd=str(ROOT),timeout_s=40.,
        duration_s=4.,outer_shared_cleanup_budget_s=1.5,
        unchanged_production_budgets=dict(sdk_window_s=.15,pb_navigation_s=.05),
        scope='synthetic active-goal protocol over real low-rate MuJoCo; not RTF or native algorithm acceptance'))
    owner=None;reader=None;errors=[];forced=False;job_empty=False;code=None;counts=[]
    cleanup_started=None;cleanup_deadline=None;cleanup_elapsed=None;reader_stopped=True;handles_released=False
    def claim_cleanup():
        nonlocal cleanup_started,cleanup_deadline
        if cleanup_started is None:
            cleanup_started=time.perf_counter();cleanup_deadline=cleanup_started+1.5
        return cleanup_deadline
    def remaining_cleanup():
        return max(0.,claim_cleanup()-time.perf_counter())
    def cleanup_check(stage):
        if time.perf_counter()>=claim_cleanup():
            errors.append('outer_shared_cleanup_deadline_exceeded:'+stage)
            return False
        return True
    def job_count(stage):
        cleanup_check('before_'+stage)
        stamp=time.perf_counter();count=owner.active_processes()
        counts.append(dict(stage=stage,elapsed_s=stamp-cleanup_started,active_processes=count))
        cleanup_check('after_'+stage)
        return count
    started=time.perf_counter()
    with (out/'stdout.log').open('wb') as sink,(out/'stderr.log').open('wb') as stderr:
        try:
            owner=WindowsOwnedJobProcess(command,cwd=str(ROOT),env=dict(os.environ),stderr=stderr)
            owner.stdin.close()
            def drain():
                try:shutil.copyfileobj(owner.stdout,sink)
                except BaseException as exc:errors.append('stdout:'+type(exc).__name__)
            reader=threading.Thread(target=drain,name='active-goal-driver-stdout',daemon=True)
            reader.start()
            code=owner.wait(timeout=40.)
            claim_cleanup()
            while True:
                count=job_count('settle_query')
                if count==0:
                    job_empty=True
                    break
                remaining=remaining_cleanup()
                if remaining<=0:break
                # This sleep is only a polling interval. Passing depends on an
                # actual subsequent zero accounting observation, never time.
                time.sleep(min(.005,remaining))
            if not job_empty:
                forced=True
                write(out/'FORCED_RESIDUAL_CLEANUP.json',owner.cleanup(cleanup_deadline))
                errors.append('owned_job_nonempty_after_probe_exit')
        except BaseException as exc:
            errors.append(type(exc).__name__)
            (out/'failure.log').write_text(traceback.format_exc(),encoding='utf8')
            if owner is not None:
                forced=True
                write(out/'FORCED_FAILURE_CLEANUP.json',owner.cleanup(claim_cleanup()))
                code=owner.poll()
        finally:
            claim_cleanup()
            if reader is not None:
                reader.join(remaining_cleanup())
                reader_stopped=not reader.is_alive()
                if not reader_stopped:errors.append('stdout_reader_not_stopped')
            cleanup_check('after_reader_join')
            if owner is not None:
                try:
                    job_empty=job_count('final_query')==0
                    # poll is the original owned handle, not a PID query. The
                    # child has already exited in the success path; no new wait
                    # or resource grace period is introduced here.
                    cleanup_check('before_final_reap_query')
                    code=owner.poll()
                    cleanup_check('after_final_reap_query')
                    if reader_stopped:owner.stdout.close()
                    else:errors.append('stdout_close_deferred_reader_still_active')
                    cleanup_check('before_release_handles')
                    owner.release_handles()
                    handles_released=True
                    cleanup_check('after_release_handles')
                except BaseException as exc:errors.append('release:'+type(exc).__name__)
            cleanup_elapsed=time.perf_counter()-cleanup_started
            if cleanup_elapsed>=1.5:errors.append('outer_shared_cleanup_total_exceeded')
    elapsed=time.perf_counter()-started
    after=hashes();write(out/'SOURCE_AFTER.json',dict(files=after))
    result_path=actual/'RESULT.json'
    probe=json.loads(result_path.read_text(encoding='utf8')) if result_path.exists() else None
    write(out/'JOB_ACCOUNTING.json',dict(budget_s=1.5,observations=counts,
        empty_observed=any(v['active_processes']==0 for v in counts),
        forced_cleanup=forced,reader_stopped=reader_stopped,handles_released=handles_released,
        outer_cleanup_elapsed_s=cleanup_elapsed,
        scope='exact owned Windows Job, reaping, reader join and handles share one cleanup deadline'))
    result=dict(passed=bool(code==0 and not errors and before==after and probe and probe.get('passed')
        and probe.get('source_unchanged') and not forced and job_empty and reader_stopped
        and handles_released and cleanup_elapsed is not None and cleanup_elapsed<1.5),returncode=code,
        elapsed_s=elapsed,process_reaped=code is not None,owned_job_empty=job_empty,
        outer_shared_cleanup_budget_s=1.5,outer_cleanup_elapsed_s=cleanup_elapsed,
        reader_stopped=reader_stopped,handles_released=handles_released,
        forced_cleanup=forced,source_unchanged=before==after,source_file_count=len(before),
        errors=errors,probe_result=str(result_path),qualification='synthetic_protocol_only')
    write(out/'RESULT.json',result)
    print(json.dumps(result,allow_nan=False))
    return 0 if result['passed'] else 2


if __name__=='__main__':raise SystemExit(main())
