"""Create a separate joint probe; the delivered manual probe stays immutable."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
target=ROOT/'tools/qa_qt_pb_coop_sil.py';assert not target.exists()
source=(ROOT/'tools/qa_qt_manual_sil.py').read_text(encoding='utf8')
source=source.replace('Opt-in original Qt keyboard/mouse/HTTP camera/manual SDK/MuJoCo SIL.', 'Opt-in original manual Qt infantry plus real PB Point-LIO/Nav2 sentry SIL.')
source=source.replace("SOURCE_FILES=('tools/qa_qt_manual_sil.py'", "SOURCE_FILES=('tools/qa_qt_pb_coop_sil.py','tools/pb_coop_cleanup.py','tools/pb_external_goal_session.py','tools/qa_pb_navigation_sil.py','rm_match/integrations/pb_wsl_navigation_registry.py','rm_match/integrations/pb_wsl_navigation.py','rm_match/navigation_sensors.py'")
source=source.replace("    rows=[];lock=", "    from tools.qa_pb_navigation_sil import audit_navigation_consumption\n    from tools.pb_external_goal_session import ExternalGoalSession\n    from tools.qa_pb_external_navigation_goal import SOURCE_FILES as PEER_SOURCES, SCHEMA as PEER_SCHEMA\n    from rm_match.integrations.pb_wsl_navigation_registry import register_pb_wsl_navigation, SCHEMA\n    from rm_match.platform_v2.adapters import Registry\n    from rm_match.platform_v2.client import PlatformClient\n    from rm_match.navigation_sensors import NavigationSensorConfig\n    from tools.pb_coop_cleanup import close_pb_sessions\n    session=peer=nav_sdk=nav_thread=peer_cleanup_thread=None;peer_cleanup=None;nav_stop=threading.Event()\n    rows=[];lock=")
source=source.replace("len(rows)>=50000", "len(rows)>=100000")
source=source.replace("    try:\n        backend=MuJoCoBackend(camera=True);initial=backend.display_snapshot()", '''    def begin_cleanup():
        nonlocal peer_cleanup_thread
        deadline=budget.claim();nav_stop.set()
        if peer is not None and peer_cleanup_thread is None:
            peer.request_stop()
            def close_peer():
                nonlocal peer_cleanup
                peer_cleanup=close_pb_sessions(external_goal=peer,deadline=deadline)
            peer_cleanup_thread=threading.Thread(target=close_peer,name='coop-external-owner-cleanup')
            peer_cleanup_thread.start()
        if runtime is not None:runtime.request_stop()
        return deadline
    try:
        registry=Registry();prepared=time.perf_counter()
        manifest=out/'PB_MANIFEST.json'
        write(manifest,dict(schema=SCHEMA,config_ref=dict(path=str(args.stack_config),sha256=digest(args.stack_config)),
            environment_ref=dict(path=str(args.environment),sha256=digest(args.environment)),out=str(out/'session'),diagnostics=True))
        session=register_pb_wsl_navigation(registry,manifest,repo_root=ROOT,relative_test_goal=False)
        peer_out=out/'peer';peer_out.mkdir();peer_spec=peer_out/'EXTERNAL_SPEC.json'
        write(peer_spec,dict(schema=PEER_SCHEMA,run_uuid=secrets.token_hex(16),session_run_uuid=session.run_uuid,
            session_ref=dict(path=session._map(session.spec_path),sha256=session.spec_sha256),namespace=session.namespace,
            domain_id=84,root_linux=session._map(ROOT),out_linux=session._map(peer_out),environment_ref=session.spec['environment_ref'],
            source_sha256={n:digest(ROOT/n) for n in PEER_SOURCES},goal_offset_m=[1.,0.],max_wall_seconds=60.))
        peer=ExternalGoalSession(ROOT,peer_out,peer_spec,digest(peer_spec));peer.prepare()
        write(out/'PREPARE.json',dict(elapsed_s=time.perf_counter()-prepared,ready=session.ready,external_ready=peer.ready,
            physics_steps=0,sensor_frames=0,algorithm_data_warmup=False))
        backend=MuJoCoBackend(camera=True,navigation_sensors=NavigationSensorConfig());initial=backend.display_snapshot()''')
source=source.replace("        def trace(row):\n            if row.get('robot_id')==RID and row['event']=='actuator_consumed' and row['phase']=='integration_entry':retain(row)\n        runtime=PlatformRuntime(backend,camera=camera,trace=trace,action_ttl=.15)", '''        def trace(row):
            if row['event'] in ('adapter_enqueue','adapter_result'):retain(row);return
            if row['event']!='actuator_consumed' or row['phase']!='integration_entry':return
            if row.get('robot_id')==RID:retain(row);return
            if row.get('robot_id')!='red_sentry':return
            auth=row['adapter_authorizations']['navigation']
            retain(dict(event='navigation_consumed',phase=row['phase'],consume_wall=row['consume_wall'],consume_sim_time=row['consume_sim_time'],
                target=copy.deepcopy(row['target']),action=copy.deepcopy(runtime.outputs.get(('red_sentry','navigation'))),
                navigation_budget=copy.deepcopy(runtime.output_budgets.get(('red_sentry','navigation'))),
                output_authorization=copy.deepcopy(runtime.output_authorizations.get(('red_sentry','navigation'))),
                authorization={k:auth.get(k) for k in ('epoch','activation_required','activation_seq','activation_expires','activation_window_id','activation_window_deadline')}))
        runtime=PlatformRuntime(backend,registry=registry,camera=camera,trace=trace,action_ttl=.15)''')
source=source.replace("        policy=AdmissionPolicy([dict(credential_sha256=hashlib.sha256(credential.encode()).hexdigest(),role='operator',allowed_robots=[RID],audit_authorized=False)])", "        nav_credential=secrets.token_urlsafe(32)\n        policy=AdmissionPolicy([dict(credential_sha256=hashlib.sha256(token.encode()).hexdigest(),role='operator',allowed_robots=[rid],audit_authorized=False) for token,rid in ((credential,RID),(nav_credential,'red_sentry'))])")
source=source.replace("        if check_client(args.client_root", '''        nav_sdk=PlatformClient('http://127.0.0.1:'+str(server.server_address[1]),control_profile='server_window_v1',admission_credential=nav_credential)
        nav_sdk.open('operator');nav_sdk.claim('red_sentry',['motion']);binding=nav_sdk.bind('red_sentry','navigation','custom_pb_navigation',{})
        if type(binding['binding_epoch']) is not int or binding['binding_epoch']!=1:raise RuntimeError('single_nav_generation_required')
        def deadman():
            renewed=time.perf_counter();next_tick=renewed
            try:
                while not nav_stop.is_set():
                    if session.process.poll() is not None or peer.child.poll() is not None:raise RuntimeError('owned_PB_supervisor_exited_early')
                    if time.perf_counter()-renewed>=.25:
                        begin=time.perf_counter();nav_sdk.renew('red_sentry',['motion']);renewed=time.perf_counter()
                        retain(dict(event='sdk_lease_renewed',started_wall=begin,completed_wall=renewed))
                    window=nav_sdk.control_window('red_sentry',['motion'])
                    activation=nav_sdk.adapter_input('red_sentry','navigation',1,window_id=window['window_id'],valid_for_s=.15)
                    ack=time.perf_counter();retain(dict(event='sdk_adapter_activation',wall_time=ack,
                        window={k:window[k] for k in ('window_id','issued_wall','expires_wall','valid_for_s','lease_epochs')},
                        activation={k:activation[k] for k in ('binding_epoch','seq','window_id','activation_expires')}))
                    next_tick+=.05
                    if next_tick<=ack:next_tick+=(math.floor((ack-next_tick)/.05)+1)*.05
                    nav_stop.wait(max(0.,next_tick-time.perf_counter()))
            except BaseException as exc:
                if not nav_stop.is_set():errors.append('nav_sdk:'+type(exc).__name__);(out/'NAV_SDK_FAILURE.log').write_text(traceback.format_exc(),encoding='utf8')
                begin_cleanup()
        nav_thread=threading.Thread(target=deadman,name='coop-real-PB-sdk');nav_thread.start()
        if check_client(args.client_root''',1)
source=source.replace("qt_finished=row;runtime.request_stop()", "qt_finished=row;begin_cleanup()")
source=source.replace("errors.append('reader:'+type(exc).__name__);runtime.request_stop()", "errors.append('reader:'+type(exc).__name__);begin_cleanup()")
source=source.replace("        deadline=budget.claim()", "        deadline=begin_cleanup()")
# The replace above also reaches begin_cleanup's own first line; keep its claim.
source=source.replace("deadline=begin_cleanup();nav_stop.set()", "deadline=budget.claim();nav_stop.set()")
source=source.replace("        if camera is not None:\n            try:camera_clean", '''        if nav_thread is not None:
            nav_thread.join(max(0.,deadline-time.perf_counter()))
            if nav_thread.is_alive():errors.append('nav_sdk_thread_not_reaped')
        if session is not None and not session._closed:
            # A live runtime slot exclusively owns its session close. Never race it.
            live=runtime is not None and any(getattr(slot,'thread',None) is not None and slot.thread.is_alive() for slot in runtime.slots.values())
            if live:errors.append('live_runtime_owns_navigation_cleanup')
            else:
                nav_cleanup=close_pb_sessions(navigation=session,deadline=deadline)
                if not nav_cleanup.get('clean'):errors.append('navigation_cleanup_unproved')
        if peer_cleanup_thread is not None:
            peer_cleanup_thread.join(max(0.,deadline-time.perf_counter()))
            if peer_cleanup_thread.is_alive():errors.append('external_cleanup_observer_not_joined')
        if nav_sdk is not None:
            try:nav_sdk.close()
            except Exception as exc:errors.append('nav_sdk_close:'+type(exc).__name__)
        if camera is not None:
            try:camera_clean''')
source=source.replace("camera_clean=camera_clean)\n        write(out/'CLEANUP.json',cleanup)", "camera_clean=camera_clean,external_owner=peer_cleanup,navigation_owner=None if session is None else session.cleanup,\n            nav_sdk_stopped=nav_thread is None or not nav_thread.is_alive(),external_observer_stopped=peer_cleanup_thread is None or not peer_cleanup_thread.is_alive(),\n            shared_host_deadline=deadline,finished_within_shared_host_budget=time.perf_counter()<=deadline)\n        write(out/'CLEANUP.json',cleanup)")
source=source.replace("    checks=dict(stages=", '''    ros_path=out/'peer/ROS_SOURCE.jsonl';ros=[] if not ros_path.is_file() else [json.loads(line) for line in ros_path.read_text().splitlines()]
    navigation=audit_navigation_consumption(rows,ros);write(out/'NAV_AUDIT.json',navigation)
    def read_record(path):return json.loads(path.read_bytes()) if path.is_file() else {}
    goal=read_record(out/'peer/GOAL_REPORT.json');external=read_record(out/'peer/RESULT.json');gate=read_record(out/'session/PRODUCTION_GATE_STATUS.json')
    write(out/'PB_RESULT.json',dict(goal=goal,external=external,gate=gate))
    go=qt.get('stages',{}).get('go_wall');release=qt.get('stages',{}).get('release_wall')
    interval_ok=type(go) in (int,float) and type(release) in (int,float) and math.isfinite(go) and math.isfinite(release) and release-go>=args.seconds
    manual_steps=set();nav_steps=set()
    if interval_ok:
        for row in rows:
            if row.get('event') not in ('actuator_consumed','navigation_consumed') or not go<=row['consume_wall']<release:continue
            motion=row['target'].get('motion')
            if motion is None or not any(abs(motion[k])>1e-8 for k in ('vx_mps','vy_mps','wz_rps')):continue
            (nav_steps if row['event']=='navigation_consumed' else manual_steps).add(round(row['consume_sim_time']/.002))
    overlap=dict(original_host_GO=go,original_host_F12=release,interval_ok=interval_ok,manual_nonzero_steps=len(manual_steps),
        navigation_nonzero_steps=len(nav_steps),same_physical_step_both_nonzero=len(manual_steps & nav_steps),clock='same Windows host perf_counter; no Linux conversion')
    write(out/'OVERLAP.json',overlap)
    pb_identity=bool(session is not None and peer is not None and gate.get('schema')=='polar.pb.production-gate-status.v1'
        and gate.get('run_uuid')==session.run_uuid and gate.get('namespace')==session.namespace
        and external.get('schema')=='polar.pb.external-goal-result.v1' and external.get('run_uuid')==peer.run_uuid
        and external.get('session_run_uuid')==session.run_uuid and external.get('namespace')==session.namespace)
    checks=dict(actual_PB_identity=pb_identity,actual_PB_source_consumption=navigation['passed'],
        simultaneous_original_manual_and_PB=interval_ok and bool(manual_steps & nav_steps),
        actual_PB_active=gate.get('production_gate') is True and gate.get('stack_state')=='ACTIVE' and gate.get('errors')==[],
        external_goal_not_input_or_lifecycle=external.get('sensor_published') is False and external.get('lifecycle_changed') is False,
        external_owned_cleanup=bool(peer_cleanup and peer_cleanup.get('clean')),
        nav_owned_cleanup=bool(session and session.cleanup and session.cleanup.get('clean')),
        shared_cleanup=cleanup['finished_within_shared_host_budget'] and cleanup['nav_sdk_stopped'] and cleanup['external_observer_stopped'],stages=''')
source=source.replace("physical=independent,steps=", "physical=independent,navigation=navigation,overlap=overlap,relative_goal_completed=goal.get('follow_path_status')==4,steps=")
source=source.replace("actual_offscreen_original_keyboard_mouse_camera_manual_SDK_MuJoCo_only", "actual_offscreen_original_keyboard_mouse_camera_manual_infantry_and_real_PB_navigation_MuJoCo_WSL")
source=source.replace("'no team navigation/decision/aim or NN/ROS'", "'no match decision tree or aiming/auto-fire/NN; PB is single-goal navigation only'")
source=source.replace("default=ROOT/'external/polar-rm-client-robotio-batch-review'", "default=ROOT/'external/polar-rm-client-camera-order-review'")
source=source.replace("default=ROOT/'client_patches/CLIENT_ROBOTIO_BATCH_PATCH_MANIFEST.json'", "default=ROOT/'client_patches/CLIENT_CAMERA_ORDER_PATCH_MANIFEST.json'")
source=source.replace("    p.add_argument('--run',action='store_true');args=p.parse_args(argv)", "    p.add_argument('--environment',type=Path,required=True);p.add_argument('--stack-config',type=Path,required=True)\n    p.add_argument('--run',action='store_true');args=p.parse_args(argv)\n    args.environment=args.environment.absolute();args.stack_config=args.stack_config.absolute()")
source=source.replace("scope='original Qt keyboard/mouse/HTTP camera/manual actuator consumption; no algorithm/match'", "scope='original Qt manual infantry alongside real PB navigation sentry; no aiming/match tree/full match',environment_sha256=digest(args.environment),stack_sha256=digest(args.stack_config)")
source=source.replace("    for name in SOURCE_FILES:", "    from rm_match.integrations.pb_wsl_navigation import SOURCE_FILES as PB_SOURCES\n    from tools.qa_pb_external_navigation_goal import SOURCE_FILES as EXTERNAL_SOURCES\n    for name in sorted(set(SOURCE_FILES+PB_SOURCES+EXTERNAL_SOURCES)):")
source=source.replace("    write(out/'SOURCE_MANIFEST.json'", "    for source in (args.environment,args.stack_config):\n        target=out/source.name;target.write_bytes(source.read_bytes());snapshots.append(dict(path=str(source),snapshot=source.name,sha256=digest(source)))\n    write(out/'SOURCE_MANIFEST.json'")
target.write_bytes(source.encode())
compile(source,str(target),'exec')
print('Created separate joint probe; compile only, no process started')
