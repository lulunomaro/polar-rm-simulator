"""Read-only PB resource identity, no ROS import or navigation executable launch."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
for name in ('environment', 'environment-sha', 'config', 'config-sha'):
    parser.add_argument('--' + name, required=True)
args = parser.parse_args()
result = dict(schema='polar.pb-coop-readonly-preflight.v1',
              timestamp_utc=datetime.now(timezone.utc).isoformat(), errors=[],
              ros_imported=False, nodes_or_algorithms_started=False,
              scope='resource_identity_only_not_navigation_or_coop_qualification')


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def checked(path, expected):
    path = Path(path)
    entry = dict(path=str(path), expected_sha256=expected, exists=path.is_file())
    if entry['exists']:
        entry.update(actual_sha256=digest(path), size_bytes=path.stat().st_size)
        entry['matches'] = entry['actual_sha256'] == expected
    else:
        entry['matches'] = False
    if not entry['matches']:
        result['errors'].append('resource_missing_or_changed:' + str(path))
    return entry


result['environment'] = checked(args.environment, args.environment_sha)
result['stack_config'] = checked(args.config, args.config_sha)
environment = json.loads(Path(args.environment).read_bytes())
config = json.loads(Path(args.config).read_bytes())
result['runtime_root'] = dict(path='/root/polar-humble-ext4-20261014-01',
                             exists=Path('/root/polar-humble-ext4-20261014-01').is_dir())
python = environment['venv_python']
probe = subprocess.run([python, '-I', '-B', '-S', '-c',
    'import sys,json; print(json.dumps(dict(version=sys.version,executable=sys.executable)))'],
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
result['python_abi'] = dict(command=[python, '-I', '-B', '-S', '-c', 'stdlib_only_python_abi'],
    exit_code=probe.returncode, stdout=probe.stdout.decode(), stderr=probe.stderr.decode(),
    reaped=True, site_packages_disabled=True)
if probe.returncode or json.loads(probe.stdout)['version'].split()[0][:4] != '3.10':
    result['errors'].append('expected_python310_unavailable')
result['install_prefixes'] = [dict(path=path, exists=Path(path).is_dir())
                              for path in config['install_prefixes']]
if not all(row['exists'] for row in result['install_prefixes']):
    result['errors'].append('install_prefix_missing')
result['assets'] = {}
for name, reference in dict(config['assets'], **config['libraries']).items():
    entry = checked(reference['path'], reference['sha256'])
    if entry['exists']:
        with Path(reference['path']).open('rb') as stream:
            entry['elf_magic'] = stream.read(4).hex()
        if entry['elf_magic'] != '7f454c46':
            result['errors'].append('not_elf:' + name)
    result['assets'][name] = entry
result['references'] = {name: checked(reference['path'], reference['sha256'])
                        for name, reference in dict(config['provenance'],
                            generation_config=config['generation_config'],
                            environment=config['environment']).items()}
git_command = ['/usr/bin/git', '-C', config['source_repo'], 'rev-parse', 'HEAD']
git = subprocess.run(git_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
result['upstream'] = dict(command=git_command, exit_code=git.returncode, reaped=True,
    expected_revision=config['source_revision'], actual_revision=git.stdout.decode().strip(),
    stderr=git.stderr.decode())
if git.returncode or result['upstream']['actual_revision'] != config['source_revision']:
    result['errors'].append('source_revision_mismatch')
prefix = Path('/root/polar-humble-ext4-20261014-01/prefix/opt/ros/humble/share')
result['package_xml_versions'] = {}
for package in ('rclpy', 'nav2_controller', 'nav2_planner', 'slam_toolbox'):
    source = prefix / package / 'package.xml'
    result['package_xml_versions'][package] = dict(path=str(source), exists=source.is_file(),
        version=ET.parse(source).getroot().findtext('version') if source.is_file() else None)
process_command = ['/usr/bin/ps', '-e', '-o', 'pid=,comm=,stat=']
processes = subprocess.run(process_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5)
names = ('pointlio', 'planner_server', 'controller_serv', 'sync_slam_tool', 'terrain',
         'sensor_scan_gen', 'loam_interface', 'pointcloud_to_l')
result['matching_processes'] = [line.strip() for line in processes.stdout.decode().splitlines()
    if len(line.split()) >= 2 and line.split()[1].startswith(names)]
result['process_check'] = dict(command=process_command, exit_code=processes.returncode,
                               reaped=True, arguments_or_environment_logged=False)
result['resource_identity_passed'] = not result['errors']
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['resource_identity_passed'] else 2)
