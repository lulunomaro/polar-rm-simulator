"""Original JPEG/display/state ordering with deterministic clocks/events.

Images are small synthetic JPEG fixtures, not actual renderer or physics proof.
"""
import copy
import threading
import unittest
from unittest.mock import patch
import cv2
from rm_client.sim_platform_transport import PlatformTransport
from platform_v2_fixtures import Client,state,frame,install_owned_state


class CameraOrderTests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.client=Client();t=self.t=PlatformTransport(role='operator',client=self.client,clock=lambda:self.now)
        t.connect_once();t.install_state(state(stamp=4.01));t.watch('red_infantry');t.process_jobs();t.install_state(state(stamp=4.01))
        self.assertTrue(t.install_frame(self.packet(1,4.0),generation=t._watch_generation,request_started=100.))
        t.request_claim();t.process_jobs();install_owned_state(t);self.assertTrue(t.activate());t.heartbeat(True)
        t.install_state(state(owner=self.client.session_id,epoch=t.owned_epochs['motion'],stamp=4.01))
    def tearDown(self):self.t.stop()
    def packet(self,index=2,stamp=4.064,age=.0305):
        p=frame(self.t,seq=index,age=age);p['capture_sim_time']=stamp;return p
    def install(self,p,started=100.):return self.t.install_frame(p,generation=self.t._watch_generation,request_started=started)
    def anchors(self):
        t=self.t
        return copy.deepcopy((id(t.video),t.video_at,t.video_sequence,t.video_sim_time,t.video_native_size,
            t.video_source_sequence,t.max_frame_age,t.frame_error,t.raw_state,t.raw_state_at,t.telemetry,t.telemetry_at,
            t._operator_hud_at,t._operator_hud_deadline,t._operator_lease_deadlines,t._window,t._window_deadline,
            t._window_sample_cut,t._input_at,t._heartbeat_at,t.owned_robot,t.owned_epochs,t._focus,t._release_job,
            t._generation,t._control_generation,t._connection_generation,t._watch_generation))
    def catch_up(self,stamp=4.015):
        self.t.install_state(state(owner=self.client.session_id,epoch=self.t.owned_epochs['motion'],stamp=stamp))
    def test_valid_54ms_ahead_drop_keeps_all_anchors_then_same_packet_matches(self):
        p=self.packet();original=copy.deepcopy(p);before=self.anchors()
        self.assertFalse(self.install(p));self.assertEqual(before,self.anchors());self.assertEqual(p,original)
        self.assertTrue(self.t._focus);self.assertFalse(self.client.uncertain)
        self.catch_up();self.now=100.01
        self.assertTrue(self.install(p));self.assertEqual(p,original)
        self.assertEqual(self.t.video_sequence,2);self.assertEqual(self.t.video_sim_time,4.064)
        self.assertAlmostEqual(self.t.video_at,100.-.0305);self.assertTrue(self.t._focus)
    def test_exact_original_50ms_boundary_is_preserved(self):
        boundary=self.t.raw_state['sim_time']+.05
        self.assertTrue(self.install(self.packet(stamp=boundary)))
        before=self.anchors();self.assertFalse(self.install(self.packet(index=3,stamp=boundary+1e-9)))
        self.assertEqual(before,self.anchors())
    def test_event_controlled_state_catchup_during_decode_accepts_original_frame(self):
        entered=threading.Event();deliver=threading.Event();returns=[];errors=[];decoder=cv2.imdecode;p=self.packet();original=copy.deepcopy(p)
        def decode(*args,**kwargs):
            entered.set()
            if not deliver.wait(1.):raise RuntimeError('fixture_decode_timeout')
            return decoder(*args,**kwargs)
        def receive():
            try:returns.append(self.install(p))
            except BaseException as exc:errors.append(type(exc).__name__)
        with patch('cv2.imdecode',side_effect=decode):
            thread=threading.Thread(target=receive);thread.start()
            try:self.assertTrue(entered.wait(1.));self.catch_up()
            finally:deliver.set();thread.join(1.)
        self.assertFalse(thread.is_alive());self.assertEqual(errors,[]);self.assertEqual(returns,[True]);self.assertEqual(p,original)
        self.assertEqual(self.t.video_sequence,2);self.assertAlmostEqual(self.t.video_at,99.9695)
    def test_valid_ahead_must_really_validate_and_decode_before_drop(self):
        p=self.packet();decoder=cv2.imdecode
        with patch('cv2.imdecode',wraps=decoder) as called:self.assertFalse(self.install(p))
        self.assertEqual(called.call_count,1)
    def test_ahead_does_not_hide_corrupt_jpeg_calibration_or_source(self):
        mutations=[lambda p:p['image'].update(data_base64='notbase64'),lambda p:p['image'].update(data_base64='bm90IGpwZWc='),
            lambda p:p['image'].update(width=9),lambda p:p['image'].update(encoding='bgr8'),
            lambda p:p['calibration']['intrinsics'].update(fx=0.),lambda p:p['calibration']['extrinsics'].update(rotation_xyzw=[0.,0.,0.,0.]),
            lambda p:p.update(source='enemy_truth'),lambda p:p.update(own_qpos_at_capture=[0.]*5)]
        for change in mutations:
            with self.subTest(change=mutations.index(change)):
                p=self.packet();change(p);before=self.anchors()
                with self.assertRaises(ValueError):self.install(p)
                self.assertEqual(before,self.anchors())
    def test_scope_and_reversed_time_still_error_not_ahead_drop(self):
        for change in [dict(watch_epoch=99),dict(robot_id='blue_sentry'),dict(episode=1),dict(capture_sim_time=3.99)]:
            with self.subTest(change=change):
                p=self.packet();p.update(change)
                with self.assertRaises(ValueError):self.install(p)
        self.assertEqual(self.t.video_sequence,1)
    def test_old_generation_no_install_and_decode_epoch_watch_session_change_no_install(self):
        self.assertFalse(self.t.install_frame(self.packet(),generation=self.t._watch_generation-1,request_started=100.))
        for change in ('episode','watch','session','role'):
            with self.subTest(change=change):
                if change!='episode':self.tearDown();self.setUp()
                decoder=cv2.imdecode
                def decode(*args,**kwargs):
                    pixels=decoder(*args,**kwargs)
                    if change=='episode':self.t.install_state(state(episode=1,stamp=4.02))
                    elif change=='watch':self.t.watch('blue_hero')
                    elif change=='session':self.client.session_id='new_synthetic_session';self.t.connect_once()
                    else:self.t.role='spectator'
                    return pixels
                with patch('cv2.imdecode',side_effect=decode):self.assertFalse(self.install(self.packet()))
                self.assertNotEqual(self.t.video_sequence,2)
    def test_current_episode_rechecked_even_if_fixture_does_not_bump_generation(self):
        decoder=cv2.imdecode
        def decode(*args,**kwargs):
            pixels=decoder(*args,**kwargs);self.t.raw_state=copy.deepcopy(self.t.raw_state);self.t.raw_state['episode']=1;return pixels
        with patch('cv2.imdecode',side_effect=decode),self.assertRaisesRegex(ValueError,'Wrong watched-camera identity'):
            self.install(self.packet())
        self.assertEqual(self.t.video_sequence,1)
    def test_original_ttl_expires_while_waiting_for_state_without_rejuvenation(self):
        p=self.packet();self.assertFalse(self.install(p));self.catch_up();self.now=102.6;before=self.anchors()
        with self.assertRaisesRegex(ValueError,'Expired camera sample'):self.install(p)
        self.assertEqual(before,self.anchors())
    def test_decode_expiry_checked_before_legal_ahead_drop(self):
        p=self.packet(age=.099);p['max_frame_age_wall_s']=.1;decoder=cv2.imdecode
        def decode(*args,**kwargs):
            pixels=decoder(*args,**kwargs);self.now+=.002;return pixels
        before=self.anchors()
        with patch('cv2.imdecode',side_effect=decode),self.assertRaisesRegex(ValueError,'Camera expired during decode'):
            self.install(p)
        self.assertEqual(before,self.anchors())
    def test_final_lock_sequence_recheck_does_not_overwrite_newer_frame(self):
        decoder=cv2.imdecode;called=[False]
        def decode(*args,**kwargs):
            pixels=decoder(*args,**kwargs)
            if not called[0]:
                called[0]=True
                self.assertTrue(self.install(self.packet(index=3,stamp=4.03)))
            return pixels
        with patch('cv2.imdecode',side_effect=decode):self.assertFalse(self.install(self.packet(index=2,stamp=4.02)))
        self.assertEqual(self.t.video_sequence,3);self.assertEqual(self.t.video_sim_time,4.03)
    def test_final_lock_reverse_time_still_rejects_after_another_frame_installs(self):
        decoder=cv2.imdecode;called=[False]
        def decode(*args,**kwargs):
            pixels=decoder(*args,**kwargs)
            if not called[0]:called[0]=True;self.assertTrue(self.install(self.packet(index=3,stamp=4.03)))
            return pixels
        with patch('cv2.imdecode',side_effect=decode),self.assertRaisesRegex(ValueError,'Reversed camera time'):
            self.install(self.packet(index=4,stamp=4.02))
        self.assertEqual(self.t.video_sequence,3);self.assertEqual(self.t.video_sim_time,4.03)

if __name__=='__main__':unittest.main()
