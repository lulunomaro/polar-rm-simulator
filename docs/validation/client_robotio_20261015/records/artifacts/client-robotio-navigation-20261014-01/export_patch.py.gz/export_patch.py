"""Export the new client's combined fixed-base patch; preserve old evidence."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
CLIENT=ROOT/'external/polar-rm-client-robotio-review'
OLD_CLIENT=ROOT/'external/polar-rm-client-state-review'
OLD_MANIFEST=ROOT/'client_patches/CLIENT_PATCH_MANIFEST.json'
old_bytes=OLD_MANIFEST.read_bytes();old=json.loads(old_bytes)
old_patch=ROOT/'client_patches'/old['patch_file'];old_patch_bytes=old_patch.read_bytes()
BASE='0cedf99b70b1beec99865b9980af6789e6c53d99'
sys.path.insert(0,str(ROOT))
from tools.apply_client_patch import inspect_client,git,source_sha,sha

if old['base_commit']!=BASE:raise ValueError('Unexpected old fixed base')
old_check=inspect_client(OLD_CLIENT)
if old_check['status']!='verified_patched':raise ValueError('Old checked client is not exactly reviewed')
if git(CLIENT,'rev-parse','HEAD').decode().strip()!=BASE:raise ValueError('New client base changed')

names=set(old['files'])
changed={p.decode('utf8') for p in git(CLIENT,'diff','HEAD','--name-only','-z').split(b'\0') if p}
if changed-names:raise ValueError('Unexpected new-client tracked path')
manifest=dict(schema='polar.sim.own_client_patch.v1',base_commit=BASE,
    patch_file='robotio_navigation_v1.patch',source_hash_scope='UTF-8 file bytes with CRLF normalized to LF',
    prior_patch_sha256=old['patch_sha256'],files={},
    qualification='Own fixed-base client plus combined reviewed patches; protocol discovery and offscreen Qt fixture tests, not live navigation/NN qualification',
    validation=dict(tests_passed=286,subtests_passed=91,tests_skipped=0,
        qt_platform='offscreen',process_result='artifacts/client-robotio-navigation-20261014-01/pytest-owned/PROCESS_RESULT.json',
        original_operator_projection_preserved=True,physical_ROS_NN_GUI_visible_run=False))
pieces=[];records=[]
new_paths={'rm_client/sim_platform_adapters.py','rm_client/ui/sim_platform_window.py','tests/test_platform_adapters.py'}
for name in sorted(names):
    raw=(CLIENT/name).read_bytes();after=raw.replace(b'\r\n',b'\n')
    before=None if old['files'][name]['before_sha256'] is None else git(CLIENT,'show',BASE+':'+name)
    normalized_before=b'' if before is None else before.replace(b'\r\n',b'\n')
    if before is not None and source_sha(before)!=old['files'][name]['before_sha256']:
        raise ValueError('Base source provenance mismatch: '+name)
    if source_sha((OLD_CLIENT/name).read_bytes())!=old['files'][name]['after_sha256']:
        raise ValueError('Old client source drift: '+name)
    pieces.extend(difflib.unified_diff(normalized_before.decode('utf8').splitlines(True),
        after.decode('utf8').splitlines(True),fromfile='/dev/null' if before is None else 'a/'+name,tofile='b/'+name))
    reason=old['files'][name]['reason']
    if name in new_paths:
        reason+='; generic typed custom navigation/pipeline discovery, empty local binding config, own robot/sensor scope, original Qt claim/arm/window regression'
    manifest['files'][name]=dict(before_sha256=None if before is None else source_sha(before),
        after_sha256=source_sha(raw),after_checkout_sha256=sha(raw),reason=reason)
    if name in new_paths:
        target=HERE/'after'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    records.append(dict(path=name,old_source_raw_sha256=sha((OLD_CLIENT/name).read_bytes()),new_source_raw_sha256=sha(raw)))
patch=''.join(pieces).encode('utf8');manifest['patch_sha256']=sha(patch)
patch_path=ROOT/'client_patches'/manifest['patch_file']
manifest_path=ROOT/'client_patches/CLIENT_ROBOTIO_PATCH_MANIFEST.json'
for path in (patch_path,manifest_path):
    if path.exists():raise ValueError('Refuse to overwrite new export '+str(path))
patch_path.write_bytes(patch)
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
check=inspect_client(CLIENT,manifest_path)
git(CLIENT,'apply','--reverse','--check',str(patch_path))
if OLD_MANIFEST.read_bytes()!=old_bytes or old_patch.read_bytes()!=old_patch_bytes:
    raise ValueError('Old patch artifacts changed')
if inspect_client(OLD_CLIENT)['status']!='verified_patched':raise ValueError('Old checkout changed')
proof=dict(schema='polar.sim.client-robotio-export.v1',old_manifest_sha256=sha(old_bytes),
    old_patch_sha256=sha(old_patch_bytes),new_manifest_sha256=sha(manifest_path.read_bytes()),
    new_patch_sha256=sha(patch),new_checkout_check=check,old_client_check=old_check,
    reverse_apply_check=True,old_patch_and_checkout_unchanged=True,files=records,
    export_script_sha256=sha(Path(__file__).read_bytes()))
(HERE/'EXPORT_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k!='files'},indent=2))
