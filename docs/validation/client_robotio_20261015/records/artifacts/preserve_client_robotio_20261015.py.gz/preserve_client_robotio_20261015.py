"""Curated exact Qt/protocol evidence, including failures; no private inputs."""
from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/validation/client_robotio_20261015'
def sha(raw):return hashlib.sha256(raw).hexdigest()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-06/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,expected in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==expected,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='e3bac435551e400501e622ee917c7311a6a9c4da'
assert not OUT.exists(),'Immutable output already exists'
directories=['client-robotio-navigation-20261014-01','coop-robotio-options-focused-20261014-04',
 'navigation-reset-capture-fixture-failure-20261015-01','qt-robotio-protocol-actual-20261014-01',
 'qt-robotio-protocol-actual-20261014-02','qt-robotio-protocol-driver-20261014-01',
 'qt-robotio-protocol-driver-20261014-02','qt-robotio-protocol-static-20261014-01',
 'quality-aim-followup-20261014-06','aim-followup-quality-driver-20261014-06',
 'client-robotio-final-dry-check-20261015-01']
files=[]
for name in directories:
    directory=ROOT/'artifacts'/name
    assert directory.is_dir(),name
    files += [p for p in directory.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for name in ['coop-robotio-options-focused-20261014-01.xml','coop-robotio-options-focused-20261014-02.xml',
 'coop-robotio-options-focused-20261014-03.xml','navigation-reset-capture-focused-20261015-02.xml',
 'run_qt_robotio_20261014.py','run_coop_robotio_options_focused_20261014.py','run_aim_followup_quality_20261014.py',
 'preserve_client_robotio_20261015.py']:
    path=ROOT/'artifacts'/name;assert path.is_file(),name;files.append(path)
for name in ['DEVELOPMENT_CHANGES.json','rm_match/platform_v2/runtime.py','rm_match/deployment/navigation_plugin.py',
 'rm_match/deployment/robotio_plugin.py','rm_match/deployment/launcher.py','rm_match/deployment/coop_launcher.py',
 'tests/test_coop_launcher.py','tests/test_robotio_plugin.py','tests/test_navigation_reset_capture.py',
 'tests/test_selected_client_patch.py','tools/qa_qt_robotio_peer.py','tools/qa_qt_robotio_protocol.py',
 'client_patches/CLIENT_ROBOTIO_PATCH_MANIFEST.json','client_patches/robotio_navigation_v1.patch',
 'examples/coop_robotio_protocol.json','docs/CLIENT_ROBOTIO_INTERFACE.md','docs/UNIVERSAL_PLUGIN_INTERFACES.md',
 'client_patches/README.md','docs/IMPLEMENTATION_PROGRESS.md']:
    files.append(ROOT/name)
prepared=[]
for path in sorted(set(files)):
    relative=path.relative_to(ROOT).as_posix();raw=path.read_bytes()
    assert path.suffix.lower() not in {'.onnx','.exe','.elf','.dll','.key','.pem','.bin'},relative
    assert path.name not in {'SDK_EVENTS.jsonl','admission.json','UserData'},relative
    assert not path.name.endswith('.local.json'),relative
    assert len(raw)<=8*1024*1024,relative
    if path.suffix in {'.json','.jsonl','.log','.stdout','.stderr'}:
        # Production secrets aren't among these records. Reject accidental value dumps.
        assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,relative
        assert b'"POLAR_OPERATOR_CREDENTIAL":' not in raw,relative
    compression='gzip' if len(raw)>4096 and path.suffix!='.gz' else 'literal'
    stored=Path('records')/relative
    if compression=='gzip':stored=Path(str(stored)+'.gz');data=gzip.compress(raw,mtime=0)
    else:data=raw
    prepared.append((stored,data,dict(original_path=relative,original_bytes=len(raw),original_sha256=sha(raw),
     stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for stored,data,record in prepared:
    dest=OUT/stored;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit='e3bac435551e400501e622ee917c7311a6a9c4da',
 qualification='actual offscreen Qt regressions and widgets/SDK/low-rate MuJoCo synthetic protocol only; no team aim/navigation/match qualification',
 records=[row[2] for row in prepared])
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'# Literal source/evidence bytes; no checkout conversion.\n* -text -whitespace\n*.gz binary\n')
print(json.dumps(dict(records=len(prepared),original_bytes=sum(row[2]['original_bytes'] for row in prepared),
 stored_bytes=sum(row[2]['stored_bytes'] for row in prepared),manifest_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()))))
