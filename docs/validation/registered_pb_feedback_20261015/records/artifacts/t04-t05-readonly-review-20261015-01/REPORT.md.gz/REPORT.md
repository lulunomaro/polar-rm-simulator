# T04/T05 只读接入诊断

本轮仅读取本地源码、原计划和已有原件，未修改生产/测试/正式文档，未执行 NN、MuJoCo、训练、ROS、WSL、构建或测试。以下是静态发现与待测方案，不能当移动成功证据。上轮 feedback/decision v2 源保持冻结。

## 结论与优先级

1. **当前 base_link action 合法，不应静默重解释为世界锁定。** `native_adapter.py:253-254` 的 `command_from_direction(response, raw)` 将原 world 方向按 observation 本车 yaw 转为 base_link 相对目标；`runtime.py:695-724` / `backend.py:184-186` 后续保持这个相对角。底盘继续转向时，保持相对角符合现公开 gimbal_target/base_link 合同（contracts.py:154-160），却不等于用户期望的惯性视线稳定。这是移动时中间姿态更新带来的参考系选择缺口，不是现有静态坐标公式错误，不能简单删 stationary 门或偷偷重解释所有旧动作。
2. **蓝方实际敌色会错。** 除 descriptor 单 red_sentry 和 `_act_sensor` 明确拒绝其它机器人外，`native_adapter.py:215` 的 frame 固定 `own_team='red', own_referee_id=7`。runner main.cpp:174-178 根据 own_team 真正选择敌色，故只改 supported_robots 无法正确接蓝车。runner 当前未读取 own_referee_id；不能把这个未使用字段假称动态队伍已接。
3. **可独立测的曝光状态边界。** eligible(native_adapter.py:166-176) 只看 observation 的平移/角速度和固定 anchor，不检查曝光包的 own_odom_velocity_at_capture。可控序列：已稳定超过 .4s；两个观测之间短运动脉冲，移动中曝光、原80ms内停下且位移<.025m；下一观测和消费均静止，原门可能接受移动曝光。尚未跑复现，不是已证实际故障；应先测试其 stationary profile 声明是否要求曝光也静止。原测试 test_sensor_packet_exposure_pose_and_fire_authority 只验证捕获角速度被保留，并未覆盖此平移脉冲。
4. **任意机器人不等于任意 MJCF 即插即用。** 目前所有角色沿用五关节模板与相同相机安装；own_state 写死 yaw_origin z=.65、camera .24/0/.06、muzzle .38/0/0，Native 固定1440x1080/K/D/光轴外参。另一合法车辆必须显式声明关节轴、安装与参考系，逐项验证，不宜全 roster 自动放行。

## 现有守卫和时间来源

- `deployment/profile.py:233-239` 与 `deployment/wsl_registry.py:23-30`：旧 aim_native_rmcs_v1 descriptor supported_robots=['red_sentry']、stationary_only=True、camera/odometry、80ms sim+wall。
- `native_adapter.py:159`：同一机器人硬拒；:166-180 需 alive/running/非急停，own速度<=.03m/s、yaw<=.03rad/s、anchor漂移<=.025m、时间不回退、稳定 .4simsec、原曝光<=80ms且帧号递增。
- `runtime.py:717-723`：每次原消费 guard 还同时拒绝实际请求运动和 measured own速度>同阈值；不能只从 adapter 删门。
- `runtime.py:552`：私有 early pixels admission 明确只给旧 aim_native_rmcs_v1；native_observation.reviewed_native_instance 只认两个精确类+原 act。新 ID 即使创建成功也不会自动获得原高速私有路径；不得泛化到任意插件。
- `camera.py:180-205`：authority 在物理步间复制 MjData，同时保存原 capture wall/sim 和本车关节、速度、odom。渲染/编码沿同复制状态；不是后续 observation pose 替代曝光姿态。
- `native_adapter.py:214`：native frame 用捕获的四 own vectors 构造；own_state 的 quaternion/局部角速度来自原 capture q/qvel。main.cpp:142-146 在 exposure stamp 更新 gimbal/gyro；:165-190 检测/PnP/tracker 使用这个姿态和曝光 stamp，control_time_ns 另为原观察时间。
- `rmcs_contract.rotation`：Rz(base_yaw+gimbal_yaw)*Ry(-pitch)，与本模板 base/yaw z轴、pitch负y轴一致；角速度包含 chassis+wrist yaw 与 pitch rate，不应把 q[3] 单独当世界朝向。command_from_direction world分支先 atan2、减 observation baseyaw、wrap到当前joint附近；原 helper 支持 pitch_link 但实际 native响应验证只允许 world，不能因此扩大 wire 权限。
- 当前 observation own ideal odometry 属已声明的仿真输入；不能把它冒称真实定位/IMU-only。本轮反馈 v2 的实际估计 TF 与此是独立数据平面。完整移动方案需明确虚拟C板姿态来源，不能以得到sim/data后自己找敌方状态替代。

## 最小显式 opt-in 方案（待授权实现/实测）

保留旧 ID、旧 base_link mode 与静止门原样。新本地描述符声明 `aim_reference=inertial_imu_v1` 与明确 supported_robots/速度范围；HTTP只原有有限FOV，不能选择模式、模型或扩展机器人。

建议先给**独立显式 mode/内部类型** `gimbal_inertial_direction_v1`：输入来自原 native world方向，但在入口按本车曝光IMU参考系冻结其惯性基准；携带原6、曝光 frame/预算、原方向、姿态基准ID。它不能伪装成旧 base_link 固定目标。初期只 reviewed Native 两精确类/原方法可走私有类型，generic插件要另有正式版本化协商。

虚拟C板消费过程：在已有每个实际 guard 的同次fresh权限/80ms/150ms检查后，仅取该车当前IMU/编码器反馈，将同一原惯性目标换算当前关节目标，再做原机器人限位；pitch/yaw有独立本车测量、轴/零位/符号标定。使用同一真实消费采样，原 source/deadline 不刷新；结果不得跨 frame/episode/binding/consumer；no_target/pending/expiry/release/camera fault清除。receipt保留原惯性方向与实际换算关节目标，便于独立重算；保持旧action记录而非改写原来源。

若先做小的原生原型，所需精确文件：
- 新 `platform_v2/native_motion.py`（不访问sim/model、纯方向/自身姿态换算与边界）；`contracts.py` 如对外提供新mode必须显式验证，旧mode不变。
- `native_adapter.py`：可信constructor选项、显式ID/team/自身姿态来源、capture/observation两处状态门；新参考类型原方向输出。`wsl_native_adapter.py` 仅传可信配置，保留spec/prepare/ownership。
- `deployment/wsl_registry.py` 和 Linux `profile.py`：本地新descriptor、合法机器人声明、prepare单资源交接与独立实例；拒绝prepared模式/机器人配置错配，不共享一个tracker到两车。
- `runtime.py`：仅显式新cap参考类型的私有采样准入/结果绑定/逐消费转换；原_targets/lease/epoch/activation/budget检查均保留。`backend.py` 如需本车IMU/编码器抽象，仅添加own反馈API，不能导出世界地图或目标坐标。
- 独立新实际移动 probe，或显式扩展 `smoke_wsl_native_live.py` 场景/actor：原probe固定单red_sentry/gimbal claim/静态布局不能拿来声称移动或双实例。默认无需改。

## 蓝方/角色 ID 的来源

颜色可从已经受 server roster/context 约束的 own.team 精确 red|blue 取得，与本地注册 robot profile 再核验；未知team直接拒绝，不依据HTTP传来的自由字符串决定友敌。模型视觉装甲角色标签现为 match_model.py:64 的 hero1/infantry3/sentry7。competition_judge RobotState 无数值 referee_id，现没有完整动态自有refID服务。最小使用可信本地 robot profile 显式 refID（按所选规则声明队伍+角色编号，例红1/3/7、蓝101/103/107仅在该规则profile下有效），再绑定原robot/team/role；不要到处 split字符串、全局默认7或在HTTP新增任意ID。当前runner未用refID，可先保持它作为明确未消费的声明字段，并测试实际 own_team→enemycolor 的真正行为。进一步任意自定义车辆必须本地提供该规则映射，不能臆造。

## 平移与弹道风险

main.cpp 实际只消费 capture quaternion/gyro、相机自身偏移；不读取 base_odom_vxyw、yaw_origin_world/base平移位置。相机iso只加 gimbal*相机安装偏移，不加底盘位移。它有完整原检测/PnP/跟踪/火控，但不能因 own_state带线速度便声称完整 ego-motion/惯性弹道/枪口速度继承。平移可能令同一目标在惯性坐标中的跟踪轨迹混入自车运动；旋转参考补偿不能修复这一点。应分别限定低速常平移、旋转、起停和加速度scope；移动命中率须实际评测，不能靠角度变换测试宣告通过。所有 fire_permission 保持false/manual_only，实体弹丸另测。

## 可复用实际 CPU4 基线

- spec `artifacts/native-production-cpu4-build-20261014/operator_source.local.json`，SHA8dd41a6905a1bb49e69b28a5c4f432d8b6c0fd9ab9b9b042f3a03fbffaba8e49；ELF67819b6812c2c4a87e2b411eed49c1e01cfb67212efdd2f2e0abd2aa3a963dec；模型b53470b42a5778aca8f3382ebe3c623482599cbf8ebad2e9a0dcc0c7f42c9255；inference profile显式CPU4非diagnostic。这里只读旧manifest/spec，不运行当前strictguard，不能保证任意未来代码仍满足旧spec。
- 正式原件 `artifacts/aim-live-20261014-formal-scheduling-01/RESULT.json`，driver `artifacts/aim-formal-scheduling-driver-20261014-formal-scheduling-01/COMMAND.json`：RTF .9971029121、107及时结果/97独立实际帧、0fault/0fire、原像素与全部检查通过。仅 live_static_chain；GUI/fullmatch/hardware/moving均未签。
- 精确原profile：wsl_async_bgr_v3 + private-native-pixels + raw codec pybase64_1_5_1；host OpenCV线程4（不是版本4）、Python switch1ms、authority thread mask0x10；原6车/dt2ms/1440x1080/总15FPS/1view/10s、extraauthoritytimers关。两条旧lean06/07静态通过也是独立历史，不是移动证据。
- 主CLI已提供同三个显式本机调度/codec选项（__main__.py），helper负责实读/恢复；不能更改为隐式默认或OS全局配置。
- 已有 review-only候选 `artifacts/t05-moving-t2-candidate-20261014-01/` 从旧source派生、未应用/测试，且只red_sentry。可复用TEST_DESIGN思路，不直接apply旧patch覆盖新runtime，尤其不能忽略其原reference语义问题。

## 有意义的验证次序

1. 纯函数独立矩阵oracle：capture/observation/消费三个不同yaw、正负pitch和±pi边界，使用MuJoCo实际body xmat/Jacobian作后续物理oracle，旧base_link动作保持相对目标，新显式惯性目标保持同方向；错IMU基准/符号/consumer/epoch/frame均拒。
2. 精确clock+事件：上述移动曝光/已停观察脉冲，原 .080边界拒绝、SDK .150与activation/lease/rebind/camera fault仍立即撤销；越速度范围→no_target且不复用旧方向，回范围也不得自动复活；原捕获时间不变。
3. 两个精确机器人（红步兵/蓝哨兵或两个本地声明profile）独立prepared process/tracker/目录/owner；team误配和未注册refID拒绝；一个取消/过期不串另一车；所有资源原1.3/1.5证明。
4. root独占实际：先旋转 .2rad/s，再侧移 .25m/s，再起停/反转/自身导航；真实RGB和同冻结模型/CPU4/profile，不暖假帧，不降画质/point/FPS，不改阈值。每原NN结果→惯性目标→实际消费→真实joint反馈逐条join；目标/机器人qpos仅独立EVAL，算法只有真实图像+本车传感器。分别报告及时帧、RTF、角误差与源像素；不把方向正确等同命中率。

本次只有只读分析；没有新增产品bug修复/新的通过数字。下一最小可执行改动应先解决显式参考系+捕获状态负例及蓝方颜色映射，再按独立运动scope实测，不能直接放宽旧stationary。
