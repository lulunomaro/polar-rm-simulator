"""Preserve the registered real-PB checkpoint without rewriting older evidence."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/validation/registered_pb_feedback_20261015'
BASE='292eba12b3d86e3bfdcc634d8d1796f92d873b66'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not OUT.exists()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-14/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,expected in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==expected,name
actual=json.loads((ROOT/'artifacts/registered-pb-goal-actual-20261015-03/RESULT.json').read_bytes())
outer=json.loads((ROOT/'artifacts/registered-pb-goal-driver-20261015-03/RESULT.json').read_bytes())
assert actual['passed'] and actual['source_unchanged'] and outer['passed'] and not outer['forced_cleanup']
names=json.loads((ROOT/'artifacts/registered_pb_checkpoint_sources_20261015.json').read_bytes())
assert len(names)==len(set(names)) and all(not n.startswith('docs/validation/') for n in names)
paths=[ROOT/name for name in names]
paths += [ROOT/'artifacts'/name for name in (
    'run_registered_pb_goal_20261015.py','run_staged_protocol_focus_20261015.py',
    'run_aim_followup_quality_20261014.py','preserve_registered_pb_feedback_20261015.py',
    'registered_pb_checkpoint_sources_20261015.json')]
patterns=(
    'registered-pb-goal-actual-20261015-*','registered-pb-goal-prep-20261015-*',
    'registered-pb-goal-driver-20261015-*','registered-pb-goal-review-20261015-*',
    'staged-protocol-focused-20261015-*','pb-goal-plugin-focused-20261015-*',
    'pb-goal-plugin-review-20261015-*','pb-match-decision-readonly-20261015-*','navigation-feedback-focused-20261015-*',
    't04-t05-readonly-review-20261015-*','registered-pb-feedback-postqa-20261015-*','quality-aim-followup-20261014-14',
    'aim-followup-quality-driver-20261014-14')
for pattern in patterns:
    for directory in sorted((ROOT/'artifacts').glob(pattern)):
        if not directory.is_dir():continue
        paths += [p for p in directory.rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
rows=[];excluded=[]
for path in sorted(set(paths)):
    name=path.relative_to(ROOT).as_posix();raw=path.read_bytes()
    if (path.name in {'SDK_EVENTS.jsonl','admission.json','UserData'}
        or path.name.endswith('.local.json') or path.suffix.lower() in {'.key','.pem','.pfx'}):
        excluded.append(dict(path=name,reason='private_or_credential_excluded'));continue
    assert raw[:4]!=b'\x7fELF' and raw[:2]!=b'MZ',name
    assert path.suffix.lower() not in {'.exe','.elf','.dll','.so','.a','.o','.onnx'},name
    assert len(raw)<=12*1024*1024,name
    if path.suffix=='.bin':raw.decode('utf8')
    if path.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:
        assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,name
    stored=Path('records')/name
    compression='gzip' if len(raw)>4096 and path.suffix not in {'.gz','.png'} else 'literal'
    data=gzip.compress(raw,mtime=0) if compression=='gzip' else raw
    if compression=='gzip':stored=Path(str(stored)+'.gz')
    rows.append((stored,data,dict(original_path=name,original_bytes=len(raw),original_sha256=sha(raw),
        stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for relative,data,_ in rows:
    target=OUT/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit=BASE,
    qualification='real PB navigation through registered estimated-feedback pipeline with synthetic single-goal decision; not competition tree, aim, RTF, DDS LAN or complete match acceptance',
    records=[row[2] for row in rows],excluded=excluded)
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'* -text -whitespace\n*.gz binary\n*.png binary\n*.bin binary\n')
(OUT/'README.md').write_bytes((ROOT/'artifacts/registered_pb_archive_readme_20261015.md').read_bytes())
(OUT/'verify_archives.py').write_bytes((ROOT/'docs/validation/goal_velocity_20261015/verify_archives.py').read_bytes())
files=[dict(path=p.relative_to(OUT).as_posix(),bytes=len(p.read_bytes()),sha256=sha(p.read_bytes()))
    for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
(OUT/'FILES.json').write_bytes((json.dumps(dict(files=files),indent=2)+'\n').encode())
subprocess.run([str(ROOT/'.venv-sim/Scripts/python.exe'),str(OUT/'verify_archives.py')],cwd=ROOT,check=True)
print(json.dumps(dict(records=len(rows),package_files=len(files)+1,
    preservation_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()),
    files_sha256=sha((OUT/'FILES.json').read_bytes()))))
