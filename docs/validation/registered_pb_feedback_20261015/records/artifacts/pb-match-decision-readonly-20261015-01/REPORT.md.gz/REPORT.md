# PB 真正比赛树：下一步最小接入范围（只读）

此轮只阅读本地固定源码、既有构建资料和原生接口定义；没有构建、启动 ROS、执行 BT、运行测试或改冻结源码。已有真实导航与估计反馈通过，不代表 PB 比赛树已经接入。`READ_INPUTS_02.ps1` 仅重读/计算输入 SHA，`INPUTS.json` 固定本报告依据；`SOURCE_CHECKS.json` 对比以前完整 source roster，原上游字节保持。首次脚本误用了 protocol manifest 文件名，未生成完成结果；原脚本保留，02只纠正该读取路径，不是构建失败。

## 原 BT 在哪里、实际做什么

固定目录：`artifacts/pb-match-behavior-audit-20261014-01/`。

| 源 | 固定 revision |
| --- | --- |
| 官方 pb2025_sentry_behavior | d111b635d326775c6c19aa12500a0bbd6a27a588 |
| 官方 pb2025_sentry_ws | 5faf964b121642d1c8d22dcabf683a13158c2351 |
| PB fork BehaviorTree.ROS2 humble | 7d177dcfbd7dbb7f5e5cd79c4e5e3e744e389c56 |
| BehaviorTree.CPP 4.6.2 | 2a8a226fbbd99f524f0796e0d8a3145773c61c06 |
| pb_rm_interfaces protocol-v1.7.0 | 8912fa565a7ac57ef070df218957379123d238ee |

默认入口是 `pb2025_sentry_behavior/launch/pb2025_sentry_behavior_launch.py`，运行该包 server/client；`params/sentry_behavior.yaml` 指定 client `target_tree=rmul_2025`，server tick_frequency=5。工作区 node_params 同样选此树。

外层 ROS action 名 `pb2025_sentry_behavior`，类型 `btcpp_ros2_interfaces/action/ExecuteTree`：goal 为 target_tree/payload，result 为 node_status/return_message，feedback 为 message。client 等待 server 后启动 100 ms wall timer；**任何终态都会 reset timer 再发树**，因此不要原样启动自动重发 client 作为可取消的受控插件。

真正默认 XML 是 `pb2025_sentry_behavior/behavior_trees/rmul_2025.xml`，格式 BTCPP4：

1. `IsGameStatus`：RUNNING(4)，剩余时间 0..420；失败时发 spin=0、Twist=0。
2. 正常时发 **7 rad/s spin**。
3. `IsStatusOK`：hp>=200、heat<=350、ammo>=0。
4. 不满足状态时，检查本车补给 RFID；未检测到则 PubNav2Goal 到 map `(0,0,0)`。
5. 满足时 PubNav2Goal 到 map `(4.65,-3.5,0)`。

**默认输出是相对 topic `goal_pose`，类型 geometry_msgs/PoseStamped。它不是 NavigateToPose action。** `plugins/action/pub_nav2_goal.cpp::setMessage` 仅将 BT 输入 pose 拷贝，frame 固定 map，stamp 使用 node now。不存在执行反馈、目标取消或当前 source6。`SendNav2Goal` 才用 `nav2_msgs/action/NavigateToPose`、相对 action `navigate_to_pose`；它只出现在 dev_rm 的测试/补给树。现生产栈明确没有 bt_navigator，不能假称此 action 可用。

### 必须保留的多 tick 陷阱

PB fork `behaviortree_ros2/include/behaviortree_ros2/bt_topic_pub_action_node.hpp` 的 `RosTopicPubStatefulActionNode::onStart` 在发布后**无条件 RUNNING**；即使 duration=0，也须下一次 `onRunning` 才 SUCCESS。直接“每观察 tickExactlyOnce 一次，无新 goal 就 hold”的 wrapper 会把正常的中间 RUNNING 误判停止，可能隔 tick 取消/重发。不能复制 last goal 然后贴新的 observed_seq 掩盖这个问题。

首个最小场景应显式 XML overlay：禁用当前没有授权协议的 7 rad/s spin，并保留原 game/status/RFID fallback 和目标选择节点；例如将 spin 节点替为 AlwaysSuccess，保留修改 diff/原 XML SHA/新 XML SHA。不得静默把7夹到2并称原行为。停止分支真正产生的零 Twist 只表达 hold/cancel，不获得裸速度控制权限。若选择不做此 overlay，则必须实现并记录有界、同 source 的多 tick 调度，而不是重贴上次输出。

## 全输入与当前可用范围

原 server `src/pb2025_sentry_behavior_server.cpp::subscribe` 只把收到的最后消息写黑板，未检查代/时效，不能直接作为新的 exact-source 协议边界。

| ROS 相对 topic / 类型 | 现通用输入可提供 | 当前必须保持 unavailable / 禁用的内容 |
| --- | --- | --- |
| referee/game_status — pb_rm_interfaces/GameStatus | 原 own/referee 的 phase、remaining_seconds；running→4、countdown→3、finished→5；paused/e-stop必须 fail closed，不能视为running。保留秒整数化策略与原数值证据。 | idle不能虚构已自检；paused无该消息枚举，必须外层明确hold gate。 |
| referee/robot_status — RobotStatus | 本车 hp、ammo、heat、alive，只给原 IsStatusOK 实际读取的三字段；浮点到 uint16须显式保守/精确策略，不静默溢出或截断。 | max_hp/冷却/热限/等级需合法规则元数据；受击原因、armor_id、金币等无通用字段。robot_pos不得填理想odom，也不能把估计字段冒充裁判位置。 |
| referee/rfid_status — RfidStatus | 当前 v2 没有本车 RFID 接触字段。 | 不把缺失当真实 NOT_DETECTED，也不从理想坐标生成。先对依赖它的低血/高热分支返回明确hold；后续 trusted own-judge contact 版本才能启用真正补给区分支。 |
| referee/event_data — EventData | 无；默认树不读。 | 占点事件不可编造。 |
| referee/all_robot_hp — GameRobotHP | 无；默认树不读。 | 不发送全场内部 HP 表。 |
| referee/ground_robot_position — GroundRobotPosition | 无；默认树不读。 | 不发送友军理想位置；该 msg 也不是敌人位置接口。 |
| referee/buff — Buff | 无；默认树不读。 | 不编造增益。 |
| detector/armors — auto_aim_interfaces/Armors | 现决策 v2 perception明确unavailable。 | 必须来自真实相机→detector/PnP才可给；不以像素/敌真值生成。 |
| tracker/target — auto_aim_interfaces/Target | 现决策 v2 perception明确unavailable。 | 不由T2相对 direction直接当世界绝对坐标，不补未知ID/半径/速度。 |
| global_costmap/costmap — nav_msgs/OccupancyGrid | 现导航原算法内部有真实costmap，但通用 decision v2只提供map→base_link估计与goal历史，不提供栅格。 | 不给理想场地栅格；需单独固定真实costmap源才可启用CalculateAttackPose。 |

现可给出的定位是 `navigation_feedback` 中原 LIO context stamp 精确 TFBuffer(map,base_link,stamp) 的真实估计及二进制来源。可供**显式场景 waypoint 坐标配置/验证**，不可当 enemy感知、RFID或官方场地图标定。原默认 `(4.65,-3.5)/(0,0)` 与在线 SLAM map 未完成场地标定。下一次演示应给独立、明示的 waypoint overlay；如果采用真实初始估计+配置偏移，只能称局部场景点，不称原比赛场地标定。

## 其它输出和停止风险

- cmd_spin/example_interfaces.Float32：7rad/s超过现导航普通wz ±2范围，自动spin未授权；必须明示禁用或以后独立扩有源协议。
- cmd_vel/geometry_msgs.Twist：默认树停止零，dev树有非零测试；不得接入物理裸Twist。
- cmd_gimbal/pb_rm_interfaces.GimbalCmd：dev树的角度/速度模式；不是导航/decision权限，本轮禁止映射到云台或火控。
- 默认/该包无射击输出；自动火仍 manual_only，本轮不得增加自动开火。
- 原 `RosActionNode::halt` 依次等 pending handle/cancel/result，各1000ms默认；这可超过1.3s资源预算。默认publisher树不需要该action节点，最小构建/runner不加载或执行SendNav2Goal。
- CalculateAttackPose 在tracking=false时可保留无TTL旧敌位；本轮不加载此攻击路径，不能只发空Target宣称停止。
- server main退出时往编译 ROOT_DIR/behavior_trees/models.xml 写模型。后续运行原server须使用owned source副本并验证原输入不变；独立runner不执行这段main。

## 依赖、已有构建与错误证据

此轮未找到 PB 比赛树构建目录/ELF/实际编译失败日志；不能把“尚未构建”写成某个已发生编译错误。以前该目录审计明确仅source contract审计。所查 Windows copied Humble prefix 的 package index 只有 `behaviortree_cpp_v3`/Nav2行为包；其 package.xml版本3.8.7，不是比赛所需4.6.2。没有对当前 Linux ext4 prefix重新运行查询，故不声称Linux绝对未安装。

固定的比赛依赖链：BT.CPP4.6.2；PB fork `behaviortree_ros2`0.2.0；`btcpp_ros2_interfaces`；`generate_parameter_library`（生成bt_executor_parameters.hpp，完整ROS2 library/server构建必需）；pb_rm_interfaces protocol-v1.7.0；auto_aim_interfaces；rclcpp/action/components、tf2/geometry、nav2_util/nav2_msgs、sensor/visualization/example接口。BT.CPP Groot/SQLite开关还引入ZeroMQ/SQLite，首个最小runner可明确关tools/examples/tests/Groot/SQLite。不能用已安装BTv3顶替，v4与Nav2 v3分进程/插件路径。

auto_aim/pb_rm接口此前有真实独立aim构建资料，但不等于比赛BT已编译；复用时按原msg字节SHA与实际生成库/ABI重新固定，不能按同名包假定等价。上游 dependencies.repos 使用humble/main/branch，下一patch必须用本报告固定commit而不是重新跟随分支。

## 最小下一 patch（建议，尚未实施）

1. **只增加 owned 构建准备工具** `tools/prepare_pb_match_decision.py`：只读固定上述source，复制到新ext4 build/out，固定CMake/源/LICENSE/ELF/loader/build结果。不改旧PB源码、Nav2 ELF、导航v3/v4环境。先只读preflight确认4.6.2和消息依赖实际可复用路径，再构建真实4.6.2及所需PB插件。不要启动上游bringup（会带相机/硬件）或自动重发client。
2. **只增加 native BT tick runner / scoped output hook**：在一个输入事务内验证完整决策v2/原typed6；新建/刷新该次黑板的合法 own/game 字段，清除 unavailable字段；调用真实BT.CPP `tree.tickExactlyOnce()`，使用原PB IsGameStatus/IsStatusOK/IsRfidDetected插件与显式XMLoverlay。goal sink必须在**本次原生PubNav2Goal setMessage/tick边界**捕获真实pose及该次scoped source，完整核验事务未变，再封装decision-intent。不要订阅裸goal_pose然后贴latest6。无本次有效输出/不支持分支为hold，日志保留真实节点状态；需要解决上述RUNNING多tick语义，不能缓存旧意图冒充新计算。
3. **只增加 decision JSONL peer 与一个显式manifest**：由真实native runner计算，输出已有 `polar.sim.decision-intent.v1`（navigate/hold/cancel）；声明现decision v2能力，空UI config/无actuator/fire权限。复用现owned WSL资源树和JSONL协议、原generation/host deadline/reset/cleanup预算，不改通用schema，也不为PB增加core第三执行通道。
4. **导航继续复用当前已实测 peer/manifest**：把graph的 synthetic decision entry换为新PB decision entry；保留相同 navigation component与原ComputePathToPose+FollowPath目标生命周期、native FollowPath UUID source、50ms emit gate/150ms host仲裁。默认树走PubNav2Goal，因此这一步不需要先新增bt_navigator，也不消费cmd_vel。只有以后明确启用SendNav2Goal dev树时，才独立准备真实NavigateToPose服务和取消验收。
5. **首轮实际验收只证一条真树路线**：running+合法健康状态→原PB条件节点→本次实际目标选择→有源导航动作；pause/e-stop→真实本次hold→原goal取消/stop证明；低状态且RFID unavailable→明确hold。固定waypoint overlay和spin-disabled overlay，保留每tick原输入/节点状态/goal来源和真实native UUID/物理join。不得称RFID补给、视觉攻击、开火或完整3v3已过。随后再单独引入合法RFID/场地图标定与真实感知。

这条路线的新代码范围约为一个准备工具、一个C++真实BT scoped runner/小输出hook、一个decision peer、一个manifest及focused测试；现MuJoCo、导航算法、目标协议、Qt与旧资产均无需修改。它直接把刚通过的真实导航闭环接到真正PB条件/树执行，而不是再造Python规则树。
