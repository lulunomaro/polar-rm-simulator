# 估计导航反馈与 decision v2 接口草稿

本稿仅供本轮集成，正式实际范围须待真实注册链结果。原 v1 的 own/referee、navigation/perception unavailable 和意图 v1 保持兼容；本轮没有运行 ROS、WSL、SLAM、神经网络、MuJoCo SIL 或可见客户端。

## 显式协商

- `DECISION_PROFILE_V1 = own_referee_v1` 为默认，输入 `polar.sim.decision-observation.v1`。
- `DECISION_PROFILE_V2 = own_referee_navigation_v2` 为本地 manifest 显式选择，输入 `polar.sim.decision-observation.v2`。capabilities schema 为 `polar.sim.decision-plugin.capabilities.v2`，`source_association=exact_observation_and_navigation_feedback_v1`。
- 输出仍是 `polar.sim.decision-intent.v1`，完整回显原六身份。v1 不会默默吞掉显式传入的 feedback；能力 reset ACK 必须与本地 manifest 完整匹配。
- API：`build_decision_observation(nav_o, feedback=None, *, profile=...)`。v2 的 navigation 嵌入整个原 feedback，不将上轮估计重贴成本轮来源；perception 仍不可用。

## Feedback 原始来源

`polar.sim.navigation-feedback.v1` 的精确顶层为 `schema/source/scan/navigation/goal_status`。source 是原 robot_id、episode、binding_epoch、observed_seq、sim_time、wall_deadline；scan 是 cloud_frame_id、acquisition_start_ns/end_ns、profile_sha256。不可用反馈同样保留这些本次扫描字段。

navigation 可用时固定 map→base_link，包含原 `stamp_ns == localization_stamp_ns`、position_m、rotation_xyzw，以及 method/producer_source_sha256/localization_binary_sha256/mapping_binary_sha256。返回的 ROS stamp 必须在原扫描 acquisition 窗口内并不晚于原 sim_time。生产者须由原定位上下文取得 LIO stamp，查询该时刻真实算法 TFBuffer 并检查其原返回 stamp；不能使用 latest/nearest/now、理想 odometry、敌方世界状态或跨 Windows/Linux 墙钟相减。TF2 自身在指定原时刻的估计链插值由生产者说明。

不可用 reason 仅 not_provided、pending_localization、map_transform_unavailable、staged_scan_expired、pending_navigation；最后一项用于真实 TF 已有但 Nav2 尚未 ACTIVE 的情况，决策保持 hold。无验证过的估计不补零位姿。

合同验证的是字段、类型和声明关系，不能仅凭数字与 hash 字符串证明估计不是伪造真值。owned 生产者、固定源/ELF 身份及实际采样审计承担这项来源责任；本轮旧实际 PB 记录没有精确 stamp TF feedback 的闭环证明。

## 实际目标回执

goal_status 无实际 lifecycle snapshot 时显式 unavailable。可用时包括实际 selection、最多最后八个实际 receipt 的 history、完整 operation_count、stop_requested、fault。history 是有限摘要，不能声称完整历史；完整证据仍在 owned lifecycle/GOAL_REPORT。

selection 只投影实际 snapshot.active；终态历史不替代当前授权。None 仅表示本次没有选中的可用回执，不证明全局无目标或已停止。origin_intent 不改写，latest_authorization 独立记录；cancel ACK 不等于真实 terminal+stop。succeeded 必须含实际 navigation UUID，schema 本身仍不能创造其算法来源。

`NavigationFeedbackHistory.check` 为每 binding 独立观察流提供有界连续性：同原六身份只允许完全相同 envelope 幂等；源 seq/sim、目标 origin/latest、已存在 UUID、取消/终态/stop 不可回退；UUID 不可跨 operation 复用；无 selection 不清除旧证明；失败事务不占用 UUID。不要将 observe 和 act 的不同 schema 流混入同一实例。

## 可调用 API

- `validate_navigation_feedback(value, observation=None)`；有 NAV 时对照完整原 scan，无 NAV 时仅验证声明关系。
- `navigation_feedback(observation, navigation, *, goal_status=None)`。
- `unavailable_navigation_feedback(observation, reason='not_provided', *, goal_status=None)`。
- `goal_status_from_lifecycle(snapshot, observation)`：只投影原 last8 与真实 active。
- `NavigationFeedbackHistory().check(value)`。

## 合成高层策略与验证边界

唯一示例 `tests/fixtures/decision_navigation_feedback_v2.py` 使用 `EstimatedMapGoalPolicy`。等待实际 navigation 与 goal_status available 后，取估计 map x+1m、原 y、原四元数 yaw 一次构造固定几何目标；后续只续同几何授权，对应真实历史 terminal+stop 后 hold。该策略是协议测试策略，不是北极熊比赛树、导航算法、目标达到证明或自动射击。

最终聚焦执行：84 passed（包含旧 decision_plugin 回归及真实本地标准库 JSONL 子进程资源-only prepare/reset/caps/act/close）。driver exit0/reaped，源前后一致；pytest 1.53s，driver 1.8959061s。原命令、stdout/stderr、JUnit、源码快照与 SHA 在同目录 `*02`。没有为模型投样预热，不改变原 150ms、50ms staged scan 或 reset/cleanup 预算。

待主代理/PB 生产者真实验证：精确 stamp map TF 的可用性；原 scan observe→decision v2→同 scan act 的授权与原 deadline；实际 UUID/目标终态反馈→后续决策 hold；所有 owned 进程/线程清理。尚不能称通用定位反馈闭环、PB 比赛树或完整比赛通过。
