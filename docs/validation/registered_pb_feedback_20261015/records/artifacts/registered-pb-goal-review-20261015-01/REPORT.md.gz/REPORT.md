# Registered PB attempt02 独立只读复核

结论：原始证据支持一次真实 PB 导航、显式 synthetic 高层策略、单车单目标的通用注册链路与物理消费。它不能证明公开 action 在全部计算、编码尾部之后仍满足原 Linux 50 ms 门限；这一缺口需要新程序与 fresh attempt03 的 final emission gate 证据。不得把 attempt02 改标为该新门已经通过。

本复核未启动 ROS、模拟器、测试或构建，也未调用原工具审计函数来复算。`inspect-02.ps1` 只读取已落盘 JSON、GZip trace、执行时源码快照及 SHA 清单；程序与 attempt02 文件均未改写。权威复算输出为 `RAW_CHECKS-02.json`，500 个输入文件的 SHA/大小见 `INPUTS-02.json`，前后均未变化，见 `EXECUTION-02.json`。

## 确认的链路

- 8,586 条原 trace 中有 149 组唯一 observe、decision v2、source6-only act。149 份 decision 输入均逐类型、逐字段等于原 own/referee 加原 feedback 的投影，intent 在 act 前保持原样。
- 138 份 available 估计逐一对应同一原 source/scan 的真实 LIO localization stamp 与唯一 raw TF lookup。TF 的请求、原 header stamp、位置、四元数与公开 feedback 一致；不是 nearest/latest 替代、旧估计重戳或世界坐标投影。
- 21 份公开 action、128 份公开 status。482 条非零 integration-entry 物理消费全部匹配这 21 份**实际公开 action**的原完整 DTO，未发现仅有 native 候选、已 withheld action 或 status 被计作物理动作。
- 所有实际消费关联到 FollowPath UUID `c2239986a4db479fba6fb3ad28502ce2`，其原 operation 为 `becd045959ed6ef00e3e8f0833475961`；planner UUID 为 `7e1382bf61ac402eade418fa0e74fda1`。native/source/SDK/物理数据均保持原六字段，不选择一个“最新 UUID”替换来源。
- 目标源为 seq13/sim1.3：原估计 x 加 1 m、y 不变，yaw 来自原估计四元数。seq72/sim7.2 的原 feedback 已包含同一目标的 `succeeded/terminal/stop_confirmed`，该次原 decision 返回 hold。这里的 stop 是实际 action-server 生命周期确认，不是编码器或物理速度归零认证。

## 时间与回收

- 原 source 的公开 action 对应 `stage_act_exit` 最大年龄为 49.947170 ms，唯一 stage begin 与唯一 scan publish 均保留原 deadline。
- host 三次协议回应的最小原 deadline 余量为 19.657000 ms。物理消费相对原 capture 的最大 wall/sim 年龄分别为 116.261700/110.000000 ms，原 action、原 SDK input window、当前授权及输出授权均未过期；最小 wall 授权余量约 75.700 μs。未放宽 150 ms，也未比较或换算 host 与 Linux 时钟。
- 7534 个 2 ms 物理步，SDK 受控跨度 15.0125695 s。peer cleanup 记录约 0.364 s；host 共享 1.5 s 内约 0.699893 s，runtime join 约 0.684883 s。WSL birth-bound/nested-session 归属证据为空组并 reaped，SDK/HTTP/IO 停止。outer Job 实测计数 1→1→0，回收约 10.9623 ms，无 outer 强制回收。
- 原 stack 有界关闭包含 SIGTERM 与 SIGKILL（部分进程 returncode -9），不能把“资源回收干净”描述成所有 ROS 进程自然退出。它未被用于代替目标的真实终态证明。

## 真正的门限缺口

旧 `stage_act_exit` 位于 `consume_sourced()` 返回前，之后仍有 GoalCompute poll/授权/深拷贝/history、peer 记录、JSONL 再验证、编码与写出。旧 `audit_stages()` 只检查该 source 事件。最大 source 年龄距 50 ms 仅约 **52.83 μs**，不能推断未记录尾部一定仍在窗口内。

因此，attempt02 的 `original_linux_50ms_stage_without_republication` 只支持原 source 门；它不独立支持 final encoded public action 门。建议已转交 root/PB 代理：保留同一原 source/scan/deadline，在编码完成、write 之前记录 `EMIT_GATES.jsonl`，将完整最终 result 与带 newline 的实际 encoded SHA 逐一关联到实际公开回应，要求同 Linux 时钟的 `begin <= gate < deadline`，过期拒绝写出。新工具将同时要求 source gate 与 final encoded gate；没有公开回应的 candidate 不计作 delivered action。before-write gate 仍不能声称拥有 pipe-write-completion 时戳。

## 无真值输入的代码复核

执行时源码快照中的 navigation observation 只含六字段、own/referee、原 ray pointcloud 与 IMU。`NavigationSensors` 内部使用 MuJoCo site pose 进行物理射线采样，只输出传感器局部坐标、命中距离和 gyro/acceleration，不输出 site/world pose、collider ID 或目标身份。额定 profile 为 200,000 rays/s；实际每包有效命中点 559–805，不能描述成每包 20,000 个有效点或已校准 MID360。

peer 的 estimate 来自实际 `TFBuffer.lookup_transform('map','base_link',Time(nanoseconds=original_LIO_stamp))` 的原返回值。transport 只发布原 scan/IMU/clock/request 与固定安装外参，没有发布机器人真值位姿。synthetic 策略仅读 decision v2；SDK actor 只做注册绑定、motion lease 与原 input-window 激活；harness 世界状态只用于停止后的独立 EVAL。代码与 raw 数据未发现真值、手工 TF/地图、像素代打或其他算法动作注入。

229 份执行时源码/配置快照 SHA 全部匹配原清单，21 份 peer evidence SHA 全部匹配原 index；driver before/after 源清单逐字节相同。工作区随后合法修改的 peer、JSONL serve 与 harness 已与旧快照区分，未追写旧结果。此复核未另启 WSL 重新读取 Linux ELF；二进制身份依据本轮 source-pinned loader、配置和记录的资产校验链，不是独立的新二进制运行验收。

## 范围与复核中间记录

仅支持本配置和显式 stationary scan accumulation profile 下的一车、一次真实 PB 导航、synthetic 决策单目标、估计反馈与原 source/SDK 物理路由。取消/替换/第二目标、PB 比赛决策树、自瞄、相机、射击、Qt、RTF、定位精度、完整 3v3/7v7、跨机 DDS 均未通过本次验收。

`EXECUTION-01.txt` 保留首次只读 helper 的 PowerShell 数组算术错误。`RAW_CHECKS.json` 是随后一次中间输出，其单元素 Hashtable `.Count` 被误当记录数，产生错误的 stage duplicate 诊断；它已被 `inspect-02.ps1` 的显式数组计数纠正。权威 `RAW_CHECKS-02.json` 的 `raw_join_problems=[]`，旧 attempt02 输入从未更改。该复核中间错误与实际导航运行失败无关。
