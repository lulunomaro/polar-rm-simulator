# Registered PB staged peer review

This review read existing files only. It started after actual attempt 02 and did not run ROS, physics, algorithms or a new reproduction. Later peer-only fixes were separately exercised in controlled unit fixtures, recorded in focused 03 and 04. Attempt 02 remains evidence for its own original source bytes.

## Evidence read

- `artifacts/registered-pb-goal-actual-20261015-02/RESULT.json`, `COMMAND.json`, `CLEANUP.json`, `STAGE_AUDIT.json`, `ESTIMATE_AUDIT.json`.
- `artifacts/registered-pb-goal-prep-20261015-02/peer-evidence/{ROS_SOURCE.jsonl,STAGES.jsonl,GOAL_REPORT.json,CLEANUP.json,stack/CLEANUP.json}`.
- Frozen staged source/peer, the original PB bridge/source/transport/gate, generic navigation JSONL peer/host adapter, RobotIO pipeline, goal lifecycle/compute and deadline-aware stack shutdown.

## Confirmed scope of attempt 02

The saved result records 149 original observations, 147 accepted native localizations, 138 delivered estimates with exact native LIO/TF joins, 23 native controller results and 482 nonzero physical consumption steps for the accepted FollowPath UUID. Its goal history retains one original estimate-derived goal, the actual planner/navigation UUIDs, `succeeded`, `terminal=true` and `stop_confirmed=true`; later high-level intent is feedback-driven hold. The reported peer cleanup is 0.363662134 s, host runtime join 0.6848829 s, all observed nested owned processes are reaped and their groups empty. Native stack termination may include its owned SIGKILL escalation; the goal's terminal/stop proof comes from the prior action result, not from those process exit codes.

Only observe invokes the original bridge begin/publish; act consumes the retained typed original observation without republishing. Original source6 and scan context are checked by type and value. The estimate path queries the actual TFBuffer at a native localization event's stamp and rejects a returned stamp/frame mismatch; no ideal pose, nearest/latest substitute or relabeled transform enters feedback. The host independently clamps both observe and compact staged act to the original host wall deadline.

## Boundary omission found and corrected separately

The source's timely native callback could be followed by goal polling, validation/history copying, journal copying and JSON encoding that crossed the same original local 50 ms limit. The original attempt-02 peer had no final gate after these operations. This was a code-level omission; the existing result does not show an actual bypass.

Focused 03 added the PB peer callback-return check. Focused 04 retained that check and added the optional `before_emit(response, encoded)` hook, with a typed whole-result/source comparison, encoded JSON comparison and same-deadline final check after journal copying. Late candidates raise an explicit error, never receive another same-seq status or a renewed deadline. `EMIT_GATES.jsonl` contains only action candidates passing the final check; rejection details remain separate. Its guarantee ends after encoding immediately before JSONL write; actual I/O remains bounded independently by the host's 150 ms window.

Final peer SHA256: `1b7fb82d5f560bd31528c4d225c60da542dd721402b172dba91fe679f46010fb`.

Focused 04: 63 tests passed, exit 0, child reaped, source snapshots unchanged, 1.3060177 s. These are controlled fixtures, not a live rerun of the final peer. Root owns the next actual attempt.

## Remaining limitations and review observations

- This route has qualified one registered real PB navigation goal with a synthetic estimate-based high-level policy. It has not qualified PB competition decisions, cancellation/replacement/second-goal behavior in this exact registered route, aiming/camera/fire, Qt or a complete match.
- A valid TF estimate plus ACTIVE servers does not guarantee that any proposed destination is within the current costmap or reachable; a real planner rejection remains possible. No coordinate clamping or fabricated map is used.
- Journals have a strict 8192-entry bound. At about six stage entries per 10 Hz scan, a continuous run reaches the stage journal limit after roughly 136 s and fails explicitly. The short SIL does not qualify multi-minute match operation.
- `PBGoalPluginPeer.close` currently samples `elapsed_s`/its end check before writing the four journals, the new gate/rejection journals, GOAL_REPORT and CLEANUP. Resource teardown shares one deadline, and the complete host-owned shutdown in attempt 02 was within budget, but the local elapsed field does not include the final evidence-write tail. A slow filesystem could make that local method-duration claim incomplete. No source change was made for this observation.
- Exact native context/TF and pinned binary evidence establish the producer route, not ground-truth localization accuracy. No independent localization accuracy measurement was performed here.
