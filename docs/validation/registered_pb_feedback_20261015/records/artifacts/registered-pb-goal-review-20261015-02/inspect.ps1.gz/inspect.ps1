$ErrorActionPreference = 'Stop'
$reviewRoot = 'C:/Users/lulu/Desktop/claude/polarsimulation/polar-rm-simulator'
$actualRoot = Join-Path $reviewRoot 'artifacts/registered-pb-goal-actual-20261015-03'
$peerRoot = Join-Path $reviewRoot 'artifacts/registered-pb-goal-prep-20261015-03/peer-evidence'
$driverRoot = Join-Path $reviewRoot 'artifacts/registered-pb-goal-driver-20261015-03'
$outRoot = Join-Path $reviewRoot 'artifacts/registered-pb-goal-review-20261015-02'
if (Test-Path -LiteralPath (Join-Path $outRoot 'RAW_CHECKS.json')) { throw 'fresh review result required' }
function J($path) { return (Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -AsHashtable -Depth 100) }
function Hash($path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
function C($value) {
    if ($null -eq $value) { return 'null' }
    if ($value -is [bool]) { return 'bool:' + $value.ToString() }
    if ($value -is [string]) { return 'str:' + $value.Length + ':' + $value }
    if ($value -is [double] -or $value -is [single] -or $value -is [decimal]) {
        return 'float:' + ([double]$value).ToString('R',[Globalization.CultureInfo]::InvariantCulture)
    }
    if ($value -is [ValueType]) { return 'integer:' + $value.ToString() }
    if ($value -is [Collections.IDictionary]) {
        $parts = foreach ($key in ($value.Keys | Sort-Object)) { (C ([string]$key)) + '=' + (C $value[$key]) }
        return '{' + ($parts -join ';') + '}'
    }
    if ($value -is [Collections.IEnumerable]) {
        $parts = foreach ($item in $value) { C $item }
        return '[' + ($parts -join ';') + ']'
    }
    throw 'unexpected non-JSON review value'
}
function K($value) {
    $parts = foreach ($name in @('robot_id','episode','binding_epoch','observed_seq','sim_time','wall_deadline')) {
        if (!$value.Contains($name)) { throw 'missing identity' }
        $name + '=' + (C $value[$name])
    }
    return ($parts -join '|')
}
function L($path) {
    $list = [Collections.Generic.List[object]]::new()
    foreach ($line in [IO.File]::ReadLines($path)) { $list.Add(($line | ConvertFrom-Json -AsHashtable -Depth 100)) }
    return ,$list
}
$inputs = [Collections.Generic.List[object]]::new()
$inputPaths = @(
    Get-ChildItem -LiteralPath $actualRoot -File -Recurse
    Get-ChildItem -LiteralPath (Split-Path $peerRoot) -File -Recurse
    Get-ChildItem -LiteralPath $driverRoot -File -Recurse
)
foreach ($path in ($inputPaths | Sort-Object FullName -Unique)) {
    $inputs.Add([ordered]@{path=$path.FullName;size=$path.Length;sha256=(Hash $path.FullName)})
}
$inputRaw = [ordered]@{scope='read-only review inputs before analysis; no ROS, simulator, test or build launched';files=$inputs}
$inputRaw | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $outRoot 'INPUT_HASHES.json') -Encoding utf8
$rows = [Collections.Generic.List[object]]::new()
$rawPublicResponse=@{}
$file = [IO.File]::OpenRead((Join-Path $actualRoot 'TRACE.jsonl.gz'))
$gzip = [IO.Compression.GZipStream]::new($file,[IO.Compression.CompressionMode]::Decompress)
$reader = [IO.StreamReader]::new($gzip,[Text.Encoding]::UTF8)
try {
    while (!$reader.EndOfStream) {
        $line=$reader.ReadLine();$parsed=$line | ConvertFrom-Json -AsHashtable -Depth 100
        $rows.Add($parsed)
        if ($parsed.event -eq 'peer_exchange' -and $parsed.peer -eq 'navigation' -and $parsed.packet.op -eq 'act') {
            $doc=[Text.Json.JsonDocument]::Parse($line)
            try {$rawPublicResponse[(K $parsed.packet.source)]=$doc.RootElement.GetProperty('response').GetRawText()}
            finally {$doc.Dispose()}
        }
    }
}
finally { $reader.Dispose();$gzip.Dispose();$file.Dispose() }
$stages = L (Join-Path $peerRoot 'STAGES.jsonl')
$ros = L (Join-Path $peerRoot 'ROS_SOURCE.jsonl')
$peerFeedback = L (Join-Path $peerRoot 'FEEDBACK.jsonl')
$peerResults = L (Join-Path $peerRoot 'ACT_RESULTS.jsonl')
$emitGates = L (Join-Path $peerRoot 'EMIT_GATES.jsonl')
$cleanup = J (Join-Path $actualRoot 'CLEANUP.json')
$aborted=@{}
$observed = @{};$decisions=@{};$act = @{};$native=@{};$windows=@{};$stageBySource=@{};$tfs=@{};$lios=@{}
$problems = [Collections.Generic.List[string]]::new()
$phaseCounts = @{};$pointCounts=[Collections.Generic.List[int]]::new();$hostSlack=[Collections.Generic.List[double]]::new()
foreach ($row in $rows) {
    if ($row.event -eq 'peer_exchange') {
        $packet=$row.packet
        if ($row.peer -eq 'navigation' -and $packet.op -eq 'observe') {
            $key=K $packet.observation
            if ($observed.ContainsKey($key)) { $problems.Add('duplicate original observe') }
            $observed[$key]=$row;$pointCounts.Add($packet.observation.sensors.pointcloud.point_count)
        } elseif ($row.peer -eq 'decision' -and $packet.op -eq 'act') { $decisions[(K $packet.observation)]=$row }
        elseif ($row.peer -eq 'navigation' -and $packet.op -eq 'act') { $act[(K $packet.source)]=$row }
    } elseif ($row.event -eq 'sdk_adapter_activation') {
        $a=$row.activation;$windows[($a.binding_epoch.ToString()+':'+$a.seq+':'+$a.window_id)]=$row.window
    }
    if ($row.event -eq 'peer_exchange_failed' -and $row.peer -eq 'navigation' -and $row.packet.op -eq 'act') {
        if ($row.completed_wall -lt $cleanup.shared_host_started_wall) {$problems.Add('failed transaction before shutdown')}
        $aborted[(K $row.packet.source)]=$row
    }
    if ($row.event -eq 'peer_exchange' -and $row.packet.op -in @('observe','act')) {
        $source = if ($row.packet.Contains('observation')) {$row.packet.observation} else {$row.packet.source}
        if ($row.completed_wall -ge $source.wall_deadline) { $problems.Add('host original deadline exceeded') }
        $hostSlack.Add(($source.wall_deadline-$row.completed_wall))
    }
}
foreach ($row in $stages) {
    $key=K $row.source
    if (!$stageBySource.ContainsKey($key)) { $stageBySource[$key]=[Collections.Generic.List[object]]::new() }
    $stageBySource[$key].Add($row)
}
foreach ($row in $ros) {
    if ($row.topic_kind -eq 'controller_result') {
        $key=K $row.value.action
        if (!$native.ContainsKey($key)) {$native[$key]=[Collections.Generic.List[object]]::new()}
        $native[$key].Add($row)
    } elseif ($row.topic_kind -eq 'estimated_transform') {
        $key=K $row.value.source
        if (!$tfs.ContainsKey($key)) {$tfs[$key]=[Collections.Generic.List[object]]::new()}
        $tfs[$key].Add($row)
    } elseif ($row.topic_kind -eq 'localization') {
        $key=K $row.value
        if (!$lios.ContainsKey($key)) {$lios[$key]=[Collections.Generic.List[object]]::new()}
        $lios[$key].Add($row)
    }
}
$publicActions=@{};$publicStatuses=@{};$stageActionAges=[Collections.Generic.List[double]]::new()
$tfMatched=0;$projectionMatched=0;$lateStageAvailable=0;$firstTerminalSource=$null;$firstTerminalHold=$null
foreach ($key in $observed.Keys) {
    $o=$observed[$key].packet.observation;$f=$observed[$key].response.feedback
    if (!$decisions.ContainsKey($key)) {$problems.Add('missing original decision');continue}
    if (!$act.ContainsKey($key) -and !$aborted.ContainsKey($key)) {$problems.Add('incomplete original route without shutdown abort')}
    $d=$decisions[$key];$a=$act[$key]
    $expected=[ordered]@{schema='polar.sim.decision-observation.v2';robot_id=$o.robot_id;episode=$o.episode;binding_epoch=$o.binding_epoch;observed_seq=$o.observed_seq;sim_time=$o.sim_time;wall_deadline=$o.wall_deadline;own=$o.own;referee=$o.referee;navigation=$f;perception=[ordered]@{available=$false;reason='not_provided_in_own_referee_v1'}}
    if ((C $expected) -ne (C $d.packet.observation)) {$problems.Add('feedback projection altered')} else {$projectionMatched++}
    $result=$null
    if ($null -ne $a) {
        if ((C $d.response.intent) -ne (C $a.packet.intent)) {$problems.Add('decision intent altered before act')}
        $result=$a.response.result
        if ($result.Contains('action')) {$publicActions[$key]=$result} else {$publicStatuses[$key]=$result}
    }
    if (@($stageBySource[$key] | Where-Object event -EQ 'stage_begin').Count -ne 1) {$problems.Add('stage reopened')}
    if (@($stageBySource[$key] | Where-Object event -EQ 'stage_published').Count -ne 1) {$problems.Add('scan republished')}
    $begin=@($stageBySource[$key] | Where-Object event -EQ 'stage_begin')[0]
    foreach ($event in $stageBySource[$key]) {if ($event.local_deadline -ne $begin.local_deadline) {$problems.Add('stage deadline renewed')}}
    if ($null -ne $result -and $result.Contains('action')) {
        $exit=@($stageBySource[$key] | Where-Object event -EQ 'stage_act_exit')[0]
        if ($exit.local_wall -ge $begin.local_deadline) {$problems.Add('raw source action beyond local50')}
        $stageActionAges.Add(($exit.local_wall-$begin.begin_wall))
        $matches=@($native[$key] | Where-Object { (C $_.value.action) -eq (C $result.action) -and $_.value.source.goal_uuid -eq $result.controller_goal_uuid })
        if ($matches.Count -lt 1) {$problems.Add('public action without exact native UUID action')}
    }
    if ($f.navigation.available) {
        $tfCandidates=@($tfs[$key]);$stamp=$f.navigation.stamp_ns
        if ($tfCandidates.Count -ne 1) {$problems.Add('TF proof missing or ambiguous');continue}
        $tf=$tfCandidates[0].value
        $raw=$tf.transform;$tr=$raw.transform.translation;$q=$raw.transform.rotation
        $position=@($tr.x,$tr.y,$tr.z);$rotation=@($q.x,$q.y,$q.z,$q.w)
        $loc=@($lios[$key] | Where-Object {$_.value.localization_stamp_ns -eq $stamp})
        if ($tf.requested_stamp_ns -ne $stamp -or $raw.header.stamp.sec*1000000000+$raw.header.stamp.nanosec -ne $stamp -or $loc.Count -lt 1 -or (C $position) -ne (C $f.navigation.position_m) -or (C $rotation) -ne (C $f.navigation.rotation_xyzw)) {$problems.Add('exact LIO TF estimate differs')} else {$tfMatched++}
        $fbEvent=@($stageBySource[$key] | Where-Object event -EQ 'stage_feedback')[0]
        if ($fbEvent.local_wall -ge $begin.local_deadline) {$lateStageAvailable++}
    }
    if ($f.goal_status.available) {
        foreach ($history in $f.goal_status.history) {
            if ($history.state -eq 'succeeded' -and $history.terminal -and $history.stop_confirmed) {
                if ($null -eq $firstTerminalSource -or $o.observed_seq -lt $firstTerminalSource.observed_seq) {$firstTerminalSource=$f.source}
                if ($d.response.intent.command.behavior -eq 'hold' -and ($null -eq $firstTerminalHold -or $o.observed_seq -lt $firstTerminalHold.observed_seq)) {$firstTerminalHold=$f.source}
            }
        }
    }
}
$gateBySource=@{};$gateAges=[Collections.Generic.List[double]]::new();$gateSlacks=[Collections.Generic.List[double]]::new()
$gateMatches=0;$gateHashes=0
foreach ($gate in $emitGates) {
    $key=K $gate.source
    if ($gateBySource.ContainsKey($key)) {$problems.Add('duplicate final gate source')}
    $gateBySource[$key]=$gate
    if (!$publicActions.ContainsKey($key)) {$problems.Add('gate without delivered public action');continue}
    $o=$observed[$key].packet.observation;$cloud=$o.sensors.pointcloud
    $scan=[ordered]@{cloud_frame_id=$cloud.frame_id;acquisition_start_ns=$cloud.acquisition_start_ns;acquisition_end_ns=$cloud.acquisition_end_ns;profile_sha256=$cloud.profile_sha256}
    $begin=@($stageBySource[$key] | Where-Object event -EQ 'stage_begin')[0]
    if ($gate.clock -ne 'linux_local_perf_counter' -or $gate.local_deadline -ne $begin.local_deadline -or (C $gate.scan) -ne (C $scan) -or (C $gate.result) -ne (C $publicActions[$key])) {$problems.Add('final gate clock deadline scan or full DTO changed')} else {$gateMatches++}
    if ($gate.gate_wall -lt $begin.begin_wall -or $gate.gate_wall -ge $begin.local_deadline) {$problems.Add('final emit beyond original 50ms stage')}
    $gateAges.Add(($gate.gate_wall-$begin.begin_wall));$gateSlacks.Add(($begin.local_deadline-$gate.gate_wall))
    $bytes=[Text.Encoding]::UTF8.GetBytes($rawPublicResponse[$key]+"`n")
    $sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
    if ($sha -ne $gate.encoded_sha256) {$problems.Add('final gate encoded raw public JSON bytes hash differs')} else {$gateHashes++}
}
foreach ($key in $publicActions.Keys) {if (!$gateBySource.ContainsKey($key)) {$problems.Add('public action missing final gate')}}
$physical=0;$physicalPublicMatches=0;$physicalNonzero=0;$maxWallAge=0.;$maxSimAge=0.;$minPhysicalSlack=[double]::PositiveInfinity
$consumedUUIDs=@{};$consumedSources=@{};$statusConsumed=0
foreach ($row in $rows) {
    if ($row.event -ne 'navigation_consumed' -or $null -eq $row.target.motion) {continue}
    $physical++;$value=$row.action;$key=K $value;$wall=$row.consume_wall;$sim=$row.consume_sim_time
    if ($publicStatuses.ContainsKey($key)) {$statusConsumed++;$problems.Add('status source physically consumed')}
    if ($aborted.ContainsKey($key)) {$problems.Add('shutdown aborted source physically consumed')}
    if (!$gateBySource.ContainsKey($key)) {$problems.Add('physical action missing final encoded emission gate')}
    if ($publicActions.ContainsKey($key) -and (C $publicActions[$key].action) -eq (C $value)) {$physicalPublicMatches++} else {$problems.Add('physical action not in actual public action response')}
    if ((C $row.target.motion) -ne (C $value.command)) {$problems.Add('physical command value changed')}
    $public=$publicActions[$key]
    if ($null -ne $public) {$consumedUUIDs[$public.controller_goal_uuid]=$true}
    $consumedSources[$key]=$true
    $maxWallAge=[Math]::Max($maxWallAge,$wall-$row.navigation_budget.capture_wall)
    $maxSimAge=[Math]::Max($maxSimAge,$sim-$row.navigation_budget.capture_sim_time)
    $margins=@(($value.wall_deadline-$wall),($row.navigation_budget.wall_deadline-$wall),($row.output_authorization.activation_expires-$wall),($row.authorization.activation_expires-$wall))
    foreach ($margin in $margins) {$minPhysicalSlack=[Math]::Min($minPhysicalSlack,$margin);if ($margin -le 0) {$problems.Add('physical original wall authority expired')}}
    foreach ($authority in @($row.output_authorization,$row.authorization)) {
        $windowKey=$authority.epoch.ToString()+':'+$authority.activation_seq+':'+$authority.activation_window_id
        $w=$windows[$windowKey]
        if ($null -eq $w -or $w.expires_wall -ne $authority.activation_expires -or $wall -ge $w.expires_wall -or $wall -lt $w.issued_wall -or $w.valid_for_s -gt .15) {$problems.Add('original SDK window does not authorize consumption')}
    }
    if ($maxWallAge -gt .150001 -or $maxSimAge -gt .150001) {$problems.Add('physical capture age exceeds150ms')}
    if ([Math]::Abs($value.command.vx_mps)+[Math]::Abs($value.command.vy_mps)+[Math]::Abs($value.command.wz_rps) -gt 1e-8) {$physicalNonzero++}
}
$manifest=J (Join-Path $actualRoot 'SOURCE_MANIFEST.json');$literalMismatches=@();$currentChanges=@()
foreach ($record in $manifest.files) {
    $snapshot=Join-Path (Join-Path $actualRoot 'source') $record.archive_path
    if ((Hash $snapshot) -ne $record.sha256) {$literalMismatches += $record.path}
    if ((Hash $record.path) -ne $record.sha256) {$currentChanges += $record.path}
}
$peerIndex=J (Join-Path $actualRoot 'PEER_EVIDENCE_INDEX.json');$peerMismatches=@()
foreach ($record in $peerIndex.files) {if ((Hash (Join-Path $peerRoot $record.path)) -ne $record.sha256) {$peerMismatches += $record.path}}
$goal=J (Join-Path $peerRoot 'GOAL_REPORT.json');$origin=$goal.lifecycle.goals[0].origin_intent
$originFeedback=$observed[(K $origin)].response.feedback
$goalDelta=@(($origin.command.goal.position_m[0]-$originFeedback.navigation.position_m[0]),($origin.command.goal.position_m[1]-$originFeedback.navigation.position_m[1]))
$summary=[ordered]@{
    independent_review_scope='raw read-only cross-check; no existing production audit functions executed; no ROS, simulator, test or build launched'
    trace_rows=$rows.Count;observe=$observed.Count;decision=$decisions.Count;act=$act.Count
    exact_decision_projections=$projectionMatched;exact_raw_LIO_TF_estimates=$tfMatched
    public_actions=$publicActions.Count;public_statuses=$publicStatuses.Count
    shutdown_aborted_sources=$aborted.Count;shutdown_aborted_receipts=@($aborted.Values)
    final_emit_gate_records=$emitGates.Count;final_emit_exact_source_scan_DTO_matches=$gateMatches;final_emit_raw_encoded_SHA_matches=$gateHashes
    final_emit_max_original_stage_age_s=($gateAges | Measure-Object -Maximum).Maximum;final_emit_min_original_stage_slack_s=($gateSlacks | Measure-Object -Minimum).Minimum
    physical_receipts=$physical;physical_exact_public_action_matches=$physicalPublicMatches
    physical_nonzero_steps=$physicalNonzero;physical_public_status_sources=$statusConsumed
    physical_distinct_source_actions=$consumedSources.Count;physical_goal_uuids=@($consumedUUIDs.Keys)
    max_public_raw_source_exit_age_s=($stageActionAges | Measure-Object -Maximum).Maximum
    min_original_host_response_slack_s=($hostSlack | Measure-Object -Minimum).Minimum
    max_physical_capture_wall_age_s=$maxWallAge;max_physical_capture_sim_age_s=$maxSimAge;min_physical_wall_authority_slack_s=$minPhysicalSlack
    late_available_feedbacks=$lateStageAvailable;point_count_min=($pointCounts | Measure-Object -Minimum).Minimum;point_count_max=($pointCounts | Measure-Object -Maximum).Maximum
    goal_estimated_offset_xy_m=$goalDelta;first_actual_succeeded_feedback_source=$firstTerminalSource;first_feedback_terminal_hold_source=$firstTerminalHold
    source_snapshot_files=$manifest.files.Count;literal_snapshot_mismatches=$literalMismatches;working_sources_changed_after_old_run=$currentChanges
    peer_evidence_files=$peerIndex.files.Count;peer_evidence_mismatches=$peerMismatches
    driver_source_before_after_identical=(Hash (Join-Path $driverRoot 'SOURCE_BEFORE.json')) -eq (Hash (Join-Path $driverRoot 'SOURCE_AFTER.json'))
    raw_join_problems=@($problems)
    evidence_limitation='final gate is after encoding immediately before write; it is not a completed pipe-write timestamp, and no host/Linux clock conversion is inferred'
}
$summary | ConvertTo-Json -Depth 40 | Set-Content -LiteralPath (Join-Path $outRoot 'RAW_CHECKS.json') -Encoding utf8
$changed=@()
foreach ($record in $inputs) {if ((Hash $record.path) -ne $record.sha256) {$changed += $record.path}}
[ordered]@{input_files=$inputs.Count;input_changed_during_review=$changed;review_script_sha256=(Hash $PSCommandPath)} | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $outRoot 'EXECUTION.json') -Encoding utf8
$summary | ConvertTo-Json -Depth 40
