"""Publish curated exact identity/registration/client-state and original Qt evidence."""
from pathlib import Path
import argparse,gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--actual-attempt',type=int,required=True);p.add_argument('--qa-attempt',type=int,required=True);a=p.parse_args()
OUT=ROOT/'docs/validation/robotio_state_qt_20261015'
def sha(raw):return hashlib.sha256(raw).hexdigest()
driver=json.loads((ROOT/f'artifacts/aim-followup-quality-driver-20261014-{a.qa_attempt:02}/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,s in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==s,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='f73532898c7b7ede7fe7119f405465b630ce11cf'
assert not OUT.exists(),'Immutable output already exists'
dirs=['action-identity-focused-20261015-01','robotio-registration-races-focused-20261015-01',
 'client-claim-state-readonly-20261015-01','client-claim-state-readonly-20261015-02','client-robotio-state-order-20261015-01',
 'qt-platform-robotio-static-20261015-01',f'quality-aim-followup-20261014-{a.qa_attempt:02}',
 f'aim-followup-quality-driver-20261014-{a.qa_attempt:02}']
dirs += [f'qt-platform-robotio-actual-20261015-{i:02}' for i in range(1,a.actual_attempt+1)]
dirs += [f'qt-platform-robotio-driver-20261015-{i:02}' for i in range(1,a.actual_attempt+1)]
files=[]
for name in dirs:
    d=ROOT/'artifacts'/name;assert d.is_dir(),name
    files += [x for x in d.rglob('*') if x.is_file() and '__pycache__' not in x.parts]
for name in ['DEVELOPMENT_CHANGES.json','rm_match/platform_v2/contracts.py','rm_match/deployment/robotio_plugin.py',
 'tests/test_action_identity_types.py','tests/test_robotio_registration_races.py','tools/qa_qt_platform_robotio.py',
 'tools/qa_qt_platform_robotio_peer.py','client_patches/CLIENT_ROBOTIO_STATE_PATCH_MANIFEST.json',
 'client_patches/robotio_state_order_v1.patch','examples/coop_robotio_state_protocol.json',
 'docs/CLIENT_ROBOTIO_INTERFACE.md','docs/UNIVERSAL_PLUGIN_INTERFACES.md','docs/COOP_PLAYABLE_PATH.md',
 'docs/IMPLEMENTATION_PROGRESS.md','client_patches/README.md','artifacts/run_qt_platform_robotio_20261015.py',
 'artifacts/run_aim_followup_quality_20261014.py','artifacts/preserve_robotio_state_20261015.py',
 'artifacts/robotio_state_next_steps_20261015.md']:
    files.append(ROOT/name)
rows=[]
for file in sorted(set(files)):
    relative=file.relative_to(ROOT).as_posix();raw=file.read_bytes()
    assert file.suffix.lower() not in {'.exe','.elf','.dll','.onnx','.bin','.key','.pem'},relative
    assert file.name not in {'SDK_EVENTS.jsonl','admission.json','UserData'} and not file.name.endswith('.local.json'),relative
    assert len(raw)<=12*1024*1024,relative
    if file.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:
        assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,relative
    compression='gzip' if len(raw)>4096 and file.suffix not in {'.gz','.png'} else 'literal'
    stored=Path('records')/relative
    if compression=='gzip':stored=Path(str(stored)+'.gz');data=gzip.compress(raw,mtime=0)
    else:data=raw
    rows.append((stored,data,dict(original_path=relative,original_bytes=len(raw),original_sha256=sha(raw),
       stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for name,raw,row in rows:
    dest=OUT/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit='f73532898c7b7ede7fe7119f405465b630ce11cf',
 qualification='validators/races/actual Qt regressions and offscreen window camera low-rate synthetic protocol; no team algorithm/raw aim80ms/match/milestone acceptance',
 records=[x[2] for x in rows])
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'# Literal evidence/source bytes; no checkout conversion.\n* -text -whitespace\n*.gz binary\n*.png binary\n')
print(json.dumps(dict(records=len(rows),original_bytes=sum(x[2]['original_bytes'] for x in rows),
 stored_bytes=sum(x[2]['stored_bytes'] for x in rows),manifest_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()))))
