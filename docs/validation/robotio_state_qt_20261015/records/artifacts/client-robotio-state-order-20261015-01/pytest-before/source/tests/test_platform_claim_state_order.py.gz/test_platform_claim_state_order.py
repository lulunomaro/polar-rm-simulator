"""Deterministic original-transport state/claim ordering; no devices/physics."""
import copy
import threading
import unittest
from unittest.mock import patch
from rm_client.sim_platform_transport import PlatformTransport, CHANNELS
from platform_v2_fixtures import state


class Client:
    uncertain=False;session_id='claim-order-fixture';control_profile='server_window_v1'
    def __init__(self):self.epoch=0;self.calls=[]
    def open(self,role):return dict(session_id=self.session_id,role=role)
    def watch(self,rid):return dict(robot_id=rid,watch_epoch=1)
    def claim(self,rid,channels):
        self.epoch+=1;self.calls.append(('claim',rid))
        return dict(robot_id=rid,lease_epochs={c:self.epoch for c in channels},lease_expires={c:101. for c in channels})
    def release(self,rid,channels):self.calls.append(('release',rid));return dict(released=True)
    def close(self):pass


class ClaimStateOrderTests(unittest.TestCase):
    def setUp(self):
        self.now=100.;self.client=Client()
        self.t=PlatformTransport(role='operator',clock=lambda:self.now,client=self.client)
        self.t.connect_once();self.t.install_state(state(owner=None,epoch=0));self.t.watch('red_infantry');self.t.process_jobs()
    def tearDown(self):self.t.stop()
    def claim(self):
        # Isolate the already-satisfied watched-camera prerequisite, without
        # creating an image or invoking any renderer/application.
        with patch.object(self.t,'selection_ready',return_value=True):self.t.request_claim()
        self.t.process_jobs()
        self.assertEqual(self.t.owned_robot,'red_infantry');self.assertFalse(self.t._focus)
    def anchors(self):
        return copy.deepcopy((self.t.raw_state,self.t.raw_state_at,self.t.telemetry,self.t.telemetry_at,
            self.t._operator_hud_at,self.t._operator_hud_deadline,self.t._operator_lease_deadlines,
            self.t._window,self.t._window_deadline,self.t._window_sample_cut))
    def test_event_controlled_preclaim_response_after_ack_is_dropped_without_any_anchor_refresh(self):
        captured=threading.Event();deliver=threading.Event();errors=[];returns=[]
        snapshot=state(owner=None,epoch=0,stamp=1.)
        generation=self.t._connection_generation
        def request():
            captured.set()
            if not deliver.wait(1.):errors.append('event_timeout');return
            try:returns.append(self.t.install_state(snapshot,connection_generation=generation,request_started=99.99))
            except Exception as exc:errors.append(type(exc).__name__)
        thread=threading.Thread(target=request);thread.start();self.assertTrue(captured.wait(1.))
        self.claim();before=self.anchors();self.now=100.02
        deliver.set();thread.join(1.);self.assertFalse(thread.is_alive())
        self.assertEqual(errors,[]);self.assertEqual(returns,[False]);self.assertEqual(before,self.anchors())
        self.assertEqual(self.t.owned_robot,'red_infantry');self.assertIsNone(self.t._release_job)
        self.assertEqual(self.client.calls,[('claim','red_infantry')]);self.assertFalse(self.t._focus)
    def test_old_simulation_stamp_with_preclaim_epochs_is_drop_not_transport_failure(self):
        self.claim();before=self.anchors()
        self.assertFalse(self.t.install_state(state(owner=None,epoch=0,stamp=.5),request_started=99.99))
        self.assertEqual(before,self.anchors());self.assertEqual(self.t.owned_robot,'red_infantry')
    def test_real_postclaim_revocation_from_request_started_before_ack_still_neutralizes(self):
        self.claim()
        self.assertTrue(self.t.install_state(state(owner=None,epoch=2,stamp=1.),request_started=99.99))
        self.assertIsNone(self.t.owned_robot);self.assertIsNotNone(self.t._release_job)
    def test_equal_epoch_wrong_owner_still_revokes(self):
        self.claim();value=state(owner=None,epoch=1)
        for c in CHANNELS:value['control']['leases']['red_infantry'][c]['epoch']=1
        self.t.install_state(value);self.assertIsNone(self.t.owned_robot)
    def test_missing_boolean_negative_and_mixed_epochs_fail_closed_not_stale_drop(self):
        for bad in ('missing','bool','negative','mixed'):
            with self.subTest(bad=bad):
                self.setUp();self.claim();value=state(owner=None,epoch=0)
                leases=value['control']['leases']['red_infantry']
                if bad=='missing':leases['motion'].pop('epoch')
                if bad=='bool':leases['motion']['epoch']=False
                if bad=='negative':leases['motion']['epoch']=-1
                if bad=='mixed':leases['motion']['epoch']=2
                with self.assertRaises(ValueError):self.t.install_state(value)
                self.assertIsNone(self.t.owned_robot);self.assertIsNotNone(self.t._release_job)
                self.t.stop()
    def test_new_episode_is_not_hidden_by_low_epochs(self):
        self.claim();self.t.install_state(state(owner=None,epoch=0,episode=1,stamp=0.))
        self.assertIsNone(self.t.owned_robot);self.assertEqual(self.t.raw_state['episode'],1)
    def test_old_connection_state_and_watch_change_do_not_touch_new_ownership(self):
        self.claim();before=self.anchors()
        self.assertFalse(self.t.install_state(state(owner=None,epoch=0),connection_generation=self.t._connection_generation-1))
        self.assertEqual(before,self.anchors());self.assertEqual(self.t.owned_robot,'red_infantry')
        self.t.watch('blue_sentry');self.assertIsNone(self.t.owned_robot);self.assertFalse(self.t._focus)
    def test_release_reclaim_floor_is_new_epoch_not_old_ack(self):
        self.claim();self.t.neutral('explicit release');self.t.process_jobs();self.claim()
        self.assertEqual(self.t.owned_epochs,{c:2 for c in CHANNELS})
        self.assertFalse(self.t.install_state(state(owner=self.client.session_id,epoch=1)))
        self.assertEqual(self.t.owned_robot,'red_infantry');self.assertIsNone(self.t._release_job)
        self.assertTrue(self.t.install_state(state(owner=self.client.session_id,epoch=2)))
        self.assertTrue(self.t.operator_hud_ready());self.assertFalse(self.t._focus)


if __name__=='__main__':unittest.main()
