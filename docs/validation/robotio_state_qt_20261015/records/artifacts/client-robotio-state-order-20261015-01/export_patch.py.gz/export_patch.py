"""Export an independent fixed-base combination; never overwrite prior files."""
import difflib
import json
from pathlib import Path
import re
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from tools.apply_client_patch import inspect_client,git,source_sha,sha
BASE='0cedf99b70b1beec99865b9980af6789e6c53d99'
CLIENT=ROOT/'external/polar-rm-client-robotio-state-review'
old_pairs=[(ROOT/'external/polar-rm-client-state-review',ROOT/'client_patches/CLIENT_PATCH_MANIFEST.json'),
           (ROOT/'external/polar-rm-client-robotio-review',ROOT/'client_patches/CLIENT_ROBOTIO_PATCH_MANIFEST.json')]
old_records=[]
for checkout,path in old_pairs:
    raw=path.read_bytes();manifest=json.loads(raw);patch=path.parent/manifest['patch_file']
    check=inspect_client(checkout,path)
    old_records.append(dict(checkout=str(checkout),manifest=str(path),manifest_bytes=raw,
        manifest_sha256=sha(raw),patch=str(patch),patch_sha256=sha(patch.read_bytes()),
        source_raw_sha256={name:sha((checkout/name).read_bytes()) for name in manifest['files']},check=check))
prior=json.loads(old_records[-1]['manifest_bytes'])
if prior['patch_sha256']!='594b8562ba88dadf2facb59a1bdaa3517c4be22bf7397b4512d97b07c942e9e3':raise ValueError('prior_patch_identity')
if git(CLIENT,'rev-parse','HEAD').decode().strip()!=BASE:raise ValueError('new_base_identity')
names=set(prior['files'])|{'tests/test_platform_claim_state_order.py','tests/test_transport_safety_regressions.py'}
changed={p.decode('utf8') for p in git(CLIENT,'diff','HEAD','--name-only','-z').split(b'\0') if p}
if changed-names:raise ValueError('unexpected_tracked_source')
result=json.loads((HERE/'pytest-after05/PROCESS_RESULT.json').read_bytes())
if result['exit_code']!=0 or not result['cleanup']['clean'] or not result['reader_stopped'] or not result['source_unchanged']:
    raise ValueError('final_suite_not_clean_pass')
log=(HERE/'pytest-after05/stdout.log').read_text(encoding='utf8')
match=re.search(r'(\d+) passed, (\d+) subtests passed',log)
if not match:raise ValueError('missing_actual_test_counts')
manifest=dict(schema='polar.sim.own_client_patch.v1',base_commit=BASE,patch_file='robotio_state_order_v1.patch',
    source_hash_scope='UTF-8 file bytes with CRLF normalized to LF',prior_patch_sha256=prior['patch_sha256'],files={},
    qualification='Fixed-base client combined operator/RobotIO/state-order patch; deterministic concurrency and offscreen Qt fixtures, not attribution of historical live failure or full match qualification',
    validation=dict(tests_passed=int(match[1]),subtests_passed=int(match[2]),tests_skipped=0,
        qt_platform='offscreen',process_result='artifacts/client-robotio-state-order-20261015-01/pytest-after05/PROCESS_RESULT.json',
        original_operator_projection_preserved=True,original_deadlines_preserved=True,
        physical_ROS_NN_GUI_visible_run=False,actual_prior_window_failure_root_cause_proven=False))
pieces=[];records=[]
for name in sorted(names):
    raw=(CLIENT/name).read_bytes();normalized=raw.replace(b'\r\n',b'\n')
    tracked=bool(git(CLIENT,'ls-tree',BASE,'--',name).strip())
    before=git(CLIENT,'show',BASE+':'+name) if tracked else None
    if name in prior['files'] and (None if before is None else source_sha(before))!=prior['files'][name]['before_sha256']:
        raise ValueError('original_blob_changed:'+name)
    pieces.extend(difflib.unified_diff((b'' if before is None else before.replace(b'\r\n',b'\n')).decode('utf8').splitlines(True),
        normalized.decode('utf8').splitlines(True),fromfile='/dev/null' if before is None else 'a/'+name,tofile='b/'+name))
    reason=prior['files'].get(name,{}).get('reason','Transport safety and deterministic claim/state ordering regression')
    if name=='rm_client/sim_platform_transport.py':reason+='; drop only complete provably preclaim lease-epoch snapshots before all time anchors; real revoke/malformed/mixed state fail closed'
    if name=='tests/test_operator_state_projection.py':reason+='; explicit actual release epoch increment in synthetic metadata, unchanged safety assertions'
    if name=='tests/test_transport_safety_regressions.py':reason+='; explicit UTF-8 JSON fixture reads on Windows, production loaders unchanged'
    manifest['files'][name]=dict(before_sha256=None if before is None else source_sha(before),after_sha256=source_sha(raw),
        after_checkout_sha256=sha(raw),reason=reason)
    if name in ('rm_client/sim_platform_transport.py','tests/test_platform_claim_state_order.py','tests/test_operator_state_projection.py','tests/test_transport_safety_regressions.py'):
        target=HERE/'final'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    records.append(dict(path=name,raw_sha256=sha(raw)))
patch=''.join(pieces).encode('utf8');manifest['patch_sha256']=sha(patch)
patch_path=ROOT/'client_patches'/manifest['patch_file'];manifest_path=ROOT/'client_patches/CLIENT_ROBOTIO_STATE_PATCH_MANIFEST.json'
if patch_path.exists() or manifest_path.exists():raise ValueError('new_export_already_exists')
patch_path.write_bytes(patch);manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8',newline='\n')
new_check=inspect_client(CLIENT,manifest_path);git(CLIENT,'apply','--reverse','--check',str(patch_path))
for row in old_records:
    if Path(row['manifest']).read_bytes()!=row['manifest_bytes'] or sha(Path(row['patch']).read_bytes())!=row['patch_sha256']:
        raise ValueError('old_patch_changed')
    if any(sha((Path(row['checkout'])/name).read_bytes())!=value for name,value in row['source_raw_sha256'].items()):raise ValueError('old_checkout_changed')
    inspect_client(row['checkout'],row['manifest']);row.pop('manifest_bytes')
proof=dict(new_manifest_sha256=sha(manifest_path.read_bytes()),new_patch_sha256=sha(patch),
    new_checkout_check=new_check,reverse_apply_check=True,old_patch_checkout_unchanged=True,
    old_checks=old_records,files=records,export_script_sha256=sha(Path(__file__).read_bytes()))
(HERE/'EXPORT_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k not in ('old_checks','files')},indent=2))
