"""Pure original transport race fixture; no Qt/images/physics/network."""
from pathlib import Path
import copy
import hashlib
import json
import sys
import threading
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
CLIENT=ROOT/'external/polar-rm-client-robotio-review'
sys.path.insert(0,str(CLIENT))
from rm_client.sim_platform_transport import PlatformTransport,CHANNELS


class Client:
    uncertain=False;session_id='fixture_session_not_a_bearer'
    def __init__(self):self.server_owned=False;self.calls=[]
    def open(self,role):return dict(session_id=self.session_id,role=role)
    def watch(self,rid):return dict(robot_id=rid,watch_epoch=1)
    def claim(self,rid,channels):
        self.server_owned=True;self.calls.append('claim')
        return dict(robot_id=rid,lease_epochs={ch:1 for ch in channels},lease_expires={ch:101. for ch in channels})
    def release(self,rid,channels):self.server_owned=False;self.calls.append('release');return dict(released=True)
    def close(self):self.calls.append('close')


def state(epoch,owner=None,revision=1):
    row=dict(robot_id='red_infantry',team='red',role='infantry')
    leases={ch:dict(owner=owner,epoch=epoch,occupied=owner is not None) for ch in CHANNELS}
    return dict(schema='rm.sim.platform.v2',source='operator_limited_display',data_plane='operator_limited_display',
        state_projection_version=1,algorithm_input=False,sim_time=1.,sample_sim_time=1.,episode=0,phase='running',
        robots=[row],remaining_seconds=200.,control=dict(robot_ids=['red_infantry'],leases={'red_infantry':leases},
            bindings={'red_infantry':{'navigation':{'owner':None},'aim':{'owner':None}}},
            server_monotonic_s=100.,stopped=False,revision=revision),applied_targets={})


def run_case(postclaim_revoke=False):
    client=Client();t=PlatformTransport(role='operator',clock=lambda:100.,client=client)
    t.connect_once();t.install_state(state(0));t.watch('red_infantry');t.process_jobs()
    began=threading.Event();deliver=threading.Event();results=[];errors=[]
    generation=t._connection_generation
    response=state(2,revision=3) if postclaim_revoke else state(0,revision=1)
    def state_request():
        began.set();assert deliver.wait(1.)
        try:results.append(t.install_state(copy.deepcopy(response),connection_generation=generation,request_started=99.99))
        except Exception as exc:errors.append(type(exc).__name__)
    worker=threading.Thread(target=state_request,name='synthetic-inflight-state');worker.start();assert began.wait(1.)
    # Claim/state ownership handling is the subject. Isolate the precondition
    # of a selectable watched camera; no camera/Qt object is fabricated or used.
    with patch.object(t,'selection_ready',return_value=True):t.request_claim()
    t.process_jobs()
    after_ack=dict(owned_robot=t.owned_robot,epochs=dict(t.owned_epochs),server_owned=client.server_owned)
    if postclaim_revoke:client.server_owned=False
    deliver.set();worker.join(1.);assert not worker.is_alive()
    after_state=dict(owned_robot=t.owned_robot,release_queued=t._release_job is not None,
        server_owned=client.server_owned,note=t.note)
    t.process_jobs()
    result=dict(postclaim_revoke=postclaim_revoke,after_ack=after_ack,after_state=after_state,
        after_release_server_owned=client.server_owned,calls=list(client.calls),install_results=results,errors=errors,
        original_snapshot_control_revision=response['control']['revision'],snapshot_epochs={ch:response['control']['leases']['red_infantry'][ch]['epoch'] for ch in CHANNELS})
    t.stop();return result


out=Path(__file__).resolve().parent
sources=[CLIENT/'rm_client/sim_platform_transport.py',ROOT/'rm_match/platform_v2/control.py',ROOT/'rm_match/platform_v2/state_projection.py']
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
old=run_case();revoked=run_case(True)
result=dict(scope='deterministic pure transport fixture; selectable-camera prerequisite isolated, no Qt/image/network/physics',
    stale_preclaim_snapshot=old,genuine_postclaim_revocation=revoked,source_sha256=before,
    source_unchanged=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in before.items()))
assert old['after_ack']['server_owned'] is True and old['after_ack']['owned_robot']=='red_infantry'
assert old['after_state']['server_owned'] is True and old['after_state']['owned_robot'] is None
assert old['calls']==['claim','release'] and old['errors']==[]
assert revoked['after_state']['owned_robot'] is None and revoked['after_state']['release_queued'] is True
assert result['source_unchanged']
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result,indent=2))
