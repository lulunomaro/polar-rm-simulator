"""Actual PB/BT4 via owned WSL, explicit synthetic DTO branches; no physics."""
from pathlib import Path
import argparse,copy,hashlib,json,sys,time,traceback
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
from tools.prepare_pb_match_decision import write_spec
from rm_match.deployment.decision_plugin import load_decision_plugins,NAVIGATION_CAPABILITIES
from rm_match.deployment.robotio_wsl import create_wsl_plugin
from rm_match.deployment.wsl_jsonl import mounted_path
from rm_match.platform_v2.decision_contracts import build_decision_observation
from rm_match.platform_v2.navigation_feedback_contracts import navigation_feedback,unavailable_navigation_feedback
from test_decision_plugin import nav_observation
from test_navigation_feedback_contracts import estimate
p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,required=True);a=p.parse_args()
out=ROOT/'artifacts'/f'pb-match-native-standalone-20261015-{a.attempt:02}';out.mkdir()
prep=ROOT/'artifacts'/f'pb-match-native-standalone-prep-20261015-{a.attempt:02}'
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
selected=['operator_native/pb_match_decision/runner.cpp','operator_native/pb_match_decision/CMakeLists.txt',
    'tools/prepare_pb_match_decision.py','rm_match/integrations/pb_match_decision_peer.py',
    'artifacts/run_pb_match_standalone_20261015.py']
before={n:sha(ROOT/n) for n in selected};write(out/'SOURCE_BEFORE.json',before)
for name in selected:
    dest=out/'source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((ROOT/name).read_bytes())
config=write_spec(prep,build_path=ROOT/'artifacts/pb-match-native-build-20261015-03-shared/BUILD_RESULT.json',
    environment_path=ROOT/'artifacts/pb-humble-ext4-runtime-20261014/ENVIRONMENT_COMPAT_FINAL.json')
environment=json.loads((prep/'ENVIRONMENT.json').read_bytes());spec=json.loads((prep/'PEER_SPEC.json').read_bytes())
row=dict(adapter_id='custom_pb_match_decision',label='Real PB BT4 standalone branches',
    command=[environment['venv_python'],'-u','-m','rm_match.integrations.pb_match_decision_peer',
        '--spec',mounted_path(prep/'PEER_SPEC.json'),'--sha256',config['spec_sha256']],cwd=mounted_path(ROOT),
    supported_robots=['red_sentry'],transport='wsl_jsonl_v1',capabilities=copy.deepcopy(NAVIGATION_CAPABILITIES),
    wsl=dict(distribution='Ubuntu-22.04',python=environment['venv_python'],process_env=environment['process_environment']))
manifest=out/'decision.json';write(manifest,dict(schema='polar.sim.decision-plugins.v1',adapters=[row]))
rows,digest=load_decision_plugins(manifest);adapter=None;trace=[];errors=[];outputs=[];start=time.perf_counter()
try:
    adapter=create_wsl_plugin(rows[0],manifest=manifest,manifest_sha=digest,repo_root=ROOT,shared_root=out/'resources')
    exchange=adapter._exchange
    def traced(packet,*,timeout):
        began=time.perf_counter();response=exchange(packet,timeout=timeout)
        trace.append(dict(packet=copy.deepcopy(packet),response=copy.deepcopy(response),started_wall=began,completed_wall=time.perf_counter()))
        return response
    adapter._exchange=traced
    adapter.prepare();ready=json.loads((prep/'peer-evidence/READY.json').read_bytes());assert ready['tick_count']==0 and ready['goal_sent'] is False
    adapter.reset(dict(robot_id='red_sentry',episode=0,binding_epoch=1))
    for seq,branch in enumerate(('healthy_current_goal','low_status_rfid_unavailable','paused_hold','emergency_stop_hold','navigation_unavailable'),1):
        o=nav_observation();o.update(robot_id='red_sentry',episode=0,binding_epoch=1,observed_seq=seq,sim_time=seq*.1)
        o['own']['team']='red';cloud=o['sensors']['pointcloud'];cloud.update(frame_id=seq,
            acquisition_start_ns=(seq-1)*100000000,acquisition_end_ns=seq*100000000,capture_sim_time=seq*.1)
        o['sensors']['imu']['capture_sim_time']=seq*.1
        for sample,t in zip(o['sensors']['imu']['samples'],((seq-1)*100000000,seq*100000000)):sample['sample_sim_ns']=t
        if branch=='low_status_rfid_unavailable':o['own']['hp']=199.9
        if branch=='paused_hold':o['referee']['phase']='paused'
        if branch=='emergency_stop_hold':o['referee']['emergency_stop']=True
        o['wall_deadline']=time.perf_counter()+.15
        nav=estimate();nav.update(stamp_ns=seq*100000000-2000000,localization_stamp_ns=seq*100000000-2000000)
        feedback=(unavailable_navigation_feedback(o,'pending_navigation') if branch=='navigation_unavailable' else navigation_feedback(o,nav))
        observation=build_decision_observation(o,feedback,profile='own_referee_navigation_v2')
        value=adapter.act(observation);outputs.append(dict(branch=branch,intent=value))
        assert value['command']['behavior']==('navigate_to_pose' if seq==1 else 'hold'),branch
except BaseException as exc:
    errors.append(type(exc).__name__+':'+str(exc));(out/'FAILURE.log').write_text(traceback.format_exc())
finally:
    if adapter is not None:
        try:adapter.close(deadline=time.perf_counter()+1.5)
        except BaseException as exc:errors.append('cleanup:'+type(exc).__name__+':'+str(exc))
    with (out/'PROTOCOL_TRACE.jsonl').open('xb') as f:
        for entry in trace:f.write(json.dumps(entry,allow_nan=False).encode()+b'\n')
    write(out/'OUTPUTS.json',outputs)
    cleanup=None if adapter is None else adapter.shutdown_status;write(out/'OWNED_CLEANUP.json',cleanup)
after={n:sha(ROOT/n) for n in selected};write(out/'SOURCE_AFTER.json',after)
native_path=prep/'peer-evidence/CLEANUP.json';native=json.loads(native_path.read_bytes()) if native_path.exists() else None
ticks=prep/'peer-evidence/native_ticks.jsonl'
ledger=[json.loads(line) for line in ticks.read_bytes().splitlines()] if ticks.exists() else []
calls=[r for r in trace if r['packet']['op']=='act']
joins=bool(len(calls)==len(ledger)==len(outputs)==5 and all(
    r['packet']['observation']==t['observation'] and r['response']['intent']==t['intent'] for r,t in zip(calls,ledger)))
result=dict(passed=not errors and before==after and joins and bool(cleanup and cleanup['clean']) and bool(native and native['clean']),
    errors=errors,source_unchanged=before==after,public_input_output_native_tick_join=joins,
    native_ticks=len(ledger),elapsed_s=time.perf_counter()-start,decision_spec=config,
    scope='actual PB BT4 standalone branches with explicit synthetic DTOs; no real sensors, physics, navigation or match acceptance')
write(out/'RESULT.json',result);print(json.dumps(result));raise SystemExit(0 if result['passed'] else 2)
