"""Preserve this real BT checkpoint literally; never rewrite earlier packages."""
from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/validation/pb_match_decision_20261015'
BASE='1c2e819566d93ce760e2e601b35be929298652e0'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not OUT.exists()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-15/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,expected in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==expected,name
names=json.loads((ROOT/'artifacts/pb_match_checkpoint_sources_20261015.json').read_bytes())
assert len(names)==len(set(names)) and all(not n.startswith('docs/validation/') for n in names)
paths=[ROOT/n for n in names]
for name in ('pb_match_preflight_20261015.py','build_pb_bt4_20261015.py','build_pb_match_interfaces_20261015.py',
 'run_pb_match_native_build_20261015.py','copy_pb_match_build_evidence_20261015.py',
 'run_pb_match_standalone_20261015.py','run_pb_match_route_20261015.py',
 'run_final_withholding_focused_20261015.py','run_pb_pipeline_cleanup_focused_20261015.py',
 'run_aim_followup_quality_20261014.py','review_pb_match_route_raw_20261015.py',
 'preserve_pb_match_decision_20261015.py','pb_match_checkpoint_sources_20261015.json',
 'pb-match-decision-license-proof-20261015-01.json'):
    paths.append(ROOT/'artifacts'/name)
patterns=('pb-match-build-preflight-20261015-*','pb-match-bt4-build-20261015-*',
 'pb-match-interfaces-build-20261015-*','pb-match-native-build-20261015-*',
 'pb-match-native-standalone*-20261015-*','pb-match-route-*-20261015-*',
 'pb-match-decision-*-focused-20261015-*','pb-goal-plugin-focused-20261015-0[56]',
 'pb-goal-plugin-source-focused-20261015-*','pb-costmap-readiness-focused-20261015-*',
 'pb-match-owned-cleanup-focused-20261015-*','pb-goal-cleanup-focused-20261015-*',
 'pb-pipeline-cleanup-focused-20261015-*','final-withholding-focused-20261015-*',
 'pb-match-plan-copy-20261015-*','pb-match-postqa-review-20261015-*',
 'quality-aim-followup-20261014-15','aim-followup-quality-driver-20261014-15')
for pattern in patterns:
    for directory in sorted((ROOT/'artifacts').glob(pattern)):
        if directory.is_dir():
            paths += [p for p in directory.rglob('*') if p.is_file()
                and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
# Original source subset used by the runner. Whole checkouts and binaries stay local.
source=json.loads((ROOT/'artifacts/pb-match-native-build-20261015-03/SOURCE_IDENTITY.json').read_bytes())
for name,expected in source['inputs'].items():
    prefix='/mnt/c/'
    assert name.startswith(prefix)
    path=Path('C:/'+name[len(prefix):])
    assert path.is_relative_to(ROOT) and sha(path.read_bytes())==expected,name
    paths.append(path)
rows=[];excluded=[]
for path in sorted(set(paths)):
    name=path.relative_to(ROOT).as_posix();raw=path.read_bytes()
    if (path.name in {'SDK_EVENTS.jsonl','admission.json','UserData'}
            or path.name.endswith('.local.json') or path.suffix.lower() in {'.key','.pem','.pfx'}):
        excluded.append(dict(path=name,reason='private_or_credential_excluded'));continue
    assert raw[:4]!=b'\x7fELF' and raw[:2]!=b'MZ',name
    assert path.suffix.lower() not in {'.exe','.elf','.dll','.so','.a','.o','.onnx'},name
    assert len(raw)<=16*1024*1024,name
    if path.suffix=='.bin':raw.decode('utf8')
    if path.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:
        assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,name
    # Short physical paths work with default Windows Git long-path settings.
    # The original full name remains immutable in the preservation manifest.
    stored=Path('records')/(f'{len(rows):04d}'+(path.suffix or '.data'))
    compression='gzip' if len(raw)>4096 and path.suffix not in {'.gz','.png'} else 'literal'
    data=gzip.compress(raw,mtime=0) if compression=='gzip' else raw
    if compression=='gzip':stored=Path(str(stored)+'.gz')
    rows.append((stored,data,dict(original_path=name,original_bytes=len(raw),original_sha256=sha(raw),
        stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for relative,data,_ in rows:
    target=OUT/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit=BASE,
    qualification='actual native PB BT4 with explicit XML overlay through generic registered feedback pipeline; branch DTO tests separate; no full match, aim, RTF or LAN acceptance',
    records=[row[2] for row in rows],excluded=excluded)
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'* -text -whitespace\n*.gz binary\n*.png binary\n*.bin binary\n')
(OUT/'README.md').write_bytes((ROOT/'artifacts/pb_match_archive_readme_20261015.md').read_bytes())
(OUT/'verify_archives.py').write_bytes((ROOT/'docs/validation/goal_velocity_20261015/verify_archives.py').read_bytes())
files=[dict(path=p.relative_to(OUT).as_posix(),bytes=len(p.read_bytes()),sha256=sha(p.read_bytes()))
    for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
(OUT/'FILES.json').write_bytes((json.dumps(dict(files=files),indent=2)+'\n').encode())
subprocess.run([str(ROOT/'.venv-sim/Scripts/python.exe'),str(OUT/'verify_archives.py')],cwd=ROOT,check=True)
result=dict(records=len(rows),package_files=len(files)+1,
    preservation_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()),
    files_sha256=sha((OUT/'FILES.json').read_bytes()))
(ROOT/'artifacts/pb_match_archive_result_20261015_02.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
print(json.dumps(result))
