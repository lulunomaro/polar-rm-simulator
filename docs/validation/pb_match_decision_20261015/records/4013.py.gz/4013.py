"""Fresh real registered PB run, with original sources and outer Job proof."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,sys,threading,time,traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools.prepare_pb_goal_plugin import prepare
from rm_match.deployment.windows_owned_job import WindowsOwnedJobProcess

p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,required=True);args=p.parse_args()
assert 1<=args.attempt<=20
out=ROOT/f'artifacts/pb-match-route-driver-20261015-{args.attempt:02}'
prep=ROOT/f'artifacts/pb-match-route-nav-prep-20261015-{args.attempt:02}'
actual=ROOT/f'artifacts/pb-match-route-actual-20261015-{args.attempt:02}'
assert not out.exists() and not prep.exists() and not actual.exists()
out.mkdir()
write=lambda p,v:p.write_bytes((json.dumps(v,indent=2,allow_nan=False)+'\n').encode())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
names=sorted(set([p.relative_to(ROOT).as_posix() for p in (ROOT/'rm_match').rglob('*.py')]+
    ['tools/prepare_pb_goal_plugin.py','tools/qa_pb_match_decision_sil.py',
     'tools/pb_navigation_stack.py','tools/qa_pb_navigation_sil.py','tools/audit_navigation_goals.py',
     'tools/prepare_pb_match_decision.py','tests/test_pb_match_decision_sil_audit.py',
     'operator_native/pb_match_decision/runner.cpp','operator_native/pb_match_decision/CMakeLists.txt',
     'artifacts/run_pb_match_route_20261015.py']))
before={n:sha(ROOT/n) for n in names}
write(out/'SOURCE_BEFORE.json',before)
for n in names:
    target=out/'source'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/n).read_bytes())
prepared=prepare(ROOT,prep,ROOT/'artifacts/goal-velocity-config-20261015-02/STACK_CONFIG.json',
    ROOT/'artifacts/pb-humble-ext4-runtime-20261014/ENVIRONMENT_COMPAT_FINAL.json')
from tools.prepare_pb_match_decision import write_spec
from rm_match.deployment.wsl_jsonl import mounted_path
from rm_match.deployment.decision_plugin import NAVIGATION_CAPABILITIES
from rm_match.deployment.robotio_plugin import load_robotio_plugins
dec_prep=ROOT/f'artifacts/pb-match-route-decision-prep-20261015-{args.attempt:02}'
graph_out=ROOT/f'artifacts/pb-match-route-graph-20261015-{args.attempt:02}';graph_out.mkdir()
dec=write_spec(dec_prep,build_path=ROOT/'artifacts/pb-match-native-build-20261015-03-shared/BUILD_RESULT.json',
    environment_path=ROOT/'artifacts/pb-humble-ext4-runtime-20261014/ENVIRONMENT_COMPAT_FINAL.json')
env=json.loads((dec_prep/'ENVIRONMENT.json').read_bytes())
row=dict(adapter_id='custom_pb_match_decision',label='Real PB BT4 source-bound match decision',
    command=[env['venv_python'],'-u','-m','rm_match.integrations.pb_match_decision_peer','--spec',mounted_path(dec_prep/'PEER_SPEC.json'),'--sha256',dec['spec_sha256']],
    cwd=mounted_path(ROOT),supported_robots=['red_sentry'],transport='wsl_jsonl_v1',capabilities=NAVIGATION_CAPABILITIES,
    wsl=dict(distribution='Ubuntu-22.04',python=env['venv_python'],process_env=env['process_environment']))
write(graph_out/'decision.json',dict(schema='polar.sim.decision-plugins.v1',adapters=[row]))
(graph_out/'navigation.json').write_bytes((prep/'navigation.json').read_bytes())
write(graph_out/'robotio.json',dict(schema='polar.sim.robotio-plugins.v1',manifests=dict(navigation='navigation.json',decision='decision.json',aim=None),pipelines=[dict(adapter_id='custom_pb_match_pipeline',label='Actual PB BT4 with actual PB navigation',decision_plugin_id='custom_pb_match_decision',navigation_plugin_id='custom_pb_goal_navigation',supported_robots=['red_sentry'])]))
load_robotio_plugins(graph_out/'robotio.json')
prepared['manifest']=str(graph_out/'robotio.json');prepared['pipeline_id']='custom_pb_match_pipeline'
command=[sys.executable,str(ROOT/'tools/qa_pb_match_decision_sil.py'),'--run',
    '--manifest',prepared['manifest'],'--pipeline-id',prepared['pipeline_id'],
    '--peer-evidence-dir',prepared['peer_evidence_dir'],'--out',str(actual),
    '--decision-evidence-dir',dec['peer_evidence_dir'],'--seconds','15','--max-wall-seconds','30','--activation-period-s','.02',
    '--python-switch-interval-s','.001']
write(out/'COMMAND.json',dict(argv=command,prep=prepared,timeout_s=80.,
    scope='real PB through generic registered estimated-feedback pipeline; real native PB BT4 tree with explicit XML scenario overlay'))
owner=reader=None;errors=[];code=None;forced=False;counts=[];cleanup_started=None;cleanup_deadline=None
reader_stopped=False;handles_released=False;job_empty=False;cleanup_elapsed=None
def claim_cleanup():
    global cleanup_started,cleanup_deadline
    if cleanup_started is None:cleanup_started=time.perf_counter();cleanup_deadline=cleanup_started+1.5
    return cleanup_deadline
def remaining():return max(0.,claim_cleanup()-time.perf_counter())
def check(stage):
    if time.perf_counter()>=claim_cleanup():errors.append('shared_cleanup_deadline:'+stage)
start=time.perf_counter()
with (out/'stdout.log').open('xb') as sink,(out/'stderr.log').open('xb') as stderr:
    try:
        owner=WindowsOwnedJobProcess(command,cwd=str(ROOT),env=dict(os.environ),stderr=stderr)
        owner.stdin.close()
        def drain():
            try:shutil.copyfileobj(owner.stdout,sink)
            except BaseException as error:errors.append('stdout:'+type(error).__name__)
        reader=threading.Thread(target=drain,daemon=True);reader.start()
        code=owner.wait(timeout=80.)
        claim_cleanup()
        while True:
            count=owner.active_processes()
            counts.append(dict(elapsed_s=time.perf_counter()-cleanup_started,active_processes=count))
            check('job_query')
            if count==0:job_empty=True;break
            if remaining()<=0:break
            time.sleep(min(.005,remaining()))
        if not job_empty:
            forced=True;write(out/'FORCED_CLEANUP.json',owner.cleanup(claim_cleanup()))
            errors.append('job_not_empty')
    except BaseException as error:
        errors.append(type(error).__name__)
        (out/'failure.log').write_text(traceback.format_exc())
        if owner is not None:
            forced=True;write(out/'FAILURE_CLEANUP.json',owner.cleanup(claim_cleanup()));code=owner.poll()
    finally:
        claim_cleanup()
        if reader is not None:
            reader.join(remaining());reader_stopped=not reader.is_alive()
            if not reader_stopped:errors.append('stdout_reader_unfinished')
        check('reader_join')
        if owner is not None:
            try:
                job_empty=owner.active_processes()==0;code=owner.poll()
                if reader_stopped:owner.stdout.close()
                owner.release_handles();handles_released=True
            except BaseException as error:errors.append('release:'+type(error).__name__)
        check('release')
        cleanup_elapsed=time.perf_counter()-cleanup_started
after={n:sha(ROOT/n) for n in names};write(out/'SOURCE_AFTER.json',after)
probe=json.loads((actual/'RESULT.json').read_bytes()) if (actual/'RESULT.json').is_file() else None
result=dict(passed=bool(code==0 and not errors and before==after and probe and probe.get('passed')
    and probe.get('source_unchanged') and not forced and job_empty and reader_stopped and handles_released
    and cleanup_elapsed is not None and cleanup_elapsed<1.5),
    returncode=code,reaped=code is not None,elapsed_s=time.perf_counter()-start,
    source_unchanged=before==after,source_files=len(names),forced_cleanup=forced,job_empty=job_empty,
    reader_stopped=reader_stopped,handles_released=handles_released,errors=errors,
    outer_cleanup_elapsed_s=cleanup_elapsed,job_observations=counts,
    actual_result=None if probe is None else str(actual/'RESULT.json'))
write(out/'RESULT.json',result);print(json.dumps(result))
raise SystemExit(0 if result['passed'] else 2)
