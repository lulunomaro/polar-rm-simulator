"""Independent read-only joins of original costmap bounds and action gates."""
from pathlib import Path
import argparse,gzip,hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tools'))
from qa_registered_pb_goal_sil import source_key,typed
from rm_match.integrations.pb_costmap_readiness import contains_map_position,validate_costmap_metadata
p=argparse.ArgumentParser();p.add_argument('--attempt',type=int,required=True);a=p.parse_args()
out=ROOT/f'artifacts/pb-match-postqa-review-20261015-{a.attempt:02}';out.mkdir()
actual=ROOT/f'artifacts/pb-match-route-actual-20261015-{a.attempt:02}'
peer=ROOT/f'artifacts/pb-match-route-nav-prep-20261015-{a.attempt:02}/peer-evidence'
rows=lambda path:[json.loads(v) for v in path.read_bytes().splitlines()]
inputs=[actual/'RESULT.json',actual/'TRACE.jsonl.gz',peer/'ROS_SOURCE.jsonl',peer/'STAGES.jsonl',
        peer/'EMIT_GATES.jsonl',peer/'GOAL_REPORT.json',ROOT/'rm_match/integrations/pb_costmap_readiness.py']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
before={str(path):sha(path) for path in inputs}
trace=[json.loads(v) for v in gzip.decompress((actual/'TRACE.jsonl.gz').read_bytes()).splitlines()]
ros=rows(peer/'ROS_SOURCE.jsonl');stages=rows(peer/'STAGES.jsonl');gates=rows(peer/'EMIT_GATES.jsonl')
feedbacks={source_key(r['response']['feedback']['source']):r['response']['feedback'] for r in trace
    if r.get('event')=='peer_exchange' and r.get('peer')=='navigation' and r['packet']['op']=='observe'}
feedback_events={source_key(r['source']):r for r in stages if r['event']=='stage_feedback'}
current_metadata=None;ready={};metadata_count=0;unready_count=0;errors=[]
for row in ros:
    if row['topic_kind']=='costmap_metadata':
        current_metadata=validate_costmap_metadata(row['value']);metadata_count+=1
    elif row['topic_kind']=='costmap_readiness':
        value=row['value'];key=source_key(value['source']);transform=value['transform']
        try:
            assert row['receive_clock']=='linux_local_perf_counter'
            assert typed(value['metadata'])==typed(current_metadata)
            position=[transform['transform']['translation'][k] for k in 'xyz']
            contained=contains_map_position(value['metadata'],position)
            assert value['contains_start'] is contained
            assert value['ready'] is (value['stack_active'] and value['backend_ready'] and contained)
            if value['ready']:
                assert key not in ready and value['metadata'] is not None
                if key in feedbacks:
                    nav=feedbacks[key]['navigation'];event=feedback_events[key]
                    assert typed(value['scan'])==typed(event['scan'])
                    if nav['available']:
                        assert nav['stamp_ns']==value['requested_stamp_ns']
                        assert typed(position)==typed(nav['position_m'])
                        assert typed([transform['transform']['rotation'][k] for k in 'xyzw'])==typed(nav['rotation_xyzw'])
                        assert row['receive_wall']<=event['local_wall']<event['local_deadline']
                ready[key]=value
            else:unready_count+=1
        except (AssertionError,KeyError,TypeError,ValueError) as exc:errors.append(type(exc).__name__+':readiness')
available={k for k,v in feedbacks.items() if v['navigation']['available']}
if available-set(ready):errors.append('available_feedback_missing_actual_costmap_readiness')
goals=json.loads((peer/'GOAL_REPORT.json').read_bytes())['lifecycle']['goals']
if any(source_key(v['origin_intent']) not in ready for v in goals):errors.append('original_goal_without_same_source_ready_map')
if any(g['gate_wall']>=g['local_deadline'] for g in gates):errors.append('late_public_action_gate')
unchanged=all(sha(Path(path))==digest for path,digest in before.items())
result=dict(passed=bool(ready and goals and gates) and not errors and unchanged,
    errors=errors,input_unchanged=unchanged,actual_result_passed=json.loads((actual/'RESULT.json').read_bytes())['passed'],
    original_costmap_metadata_receipts=metadata_count,exact_estimated_pose_map_readiness_joins=len(available),
    original_goal_ready_joins=len(goals),unready_estimates_withheld=unready_count,
    actual_final_action_gates=len(gates),minimum_original_gate_remaining_ms=min(
        ((g['local_deadline']-g['gate_wall'])*1000 for g in gates),default=None),
    qualification='original map bounds and same exact TF/source only; no occupancy, path validity, calibration or RTF claim',
    input_sha256=before)
(out/'RESULT.json').write_bytes((json.dumps(result,indent=2)+'\n').encode())
(out/'REVIEW_DRIVER.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items() if k!='input_sha256'}));raise SystemExit(0 if result['passed'] else 2)
