"""Read saved artifacts only; no ROS execution, import, subprocess or input edits."""
from pathlib import Path
import collections
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
INPUTS = {}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    path = ROOT / path
    raw = path.read_bytes()
    INPUTS[str(path.relative_to(ROOT)).replace("\\", "/")] = digest(raw)
    return raw


def document(path):
    return json.loads(read(path))


def inspect(name):
    base = "artifacts/" + name + "/"
    log = read(base + "session/stack/planner_server.log").decode()
    slam_log = read(base + "session/stack/slam_toolbox.log").decode()
    yaml = read(base + "session/stack/owned_parameters.yaml").decode()
    events = [json.loads(line) for line in read(base + "peer/EXTERNAL_EVENTS.jsonl").decode().splitlines()]
    ros = [json.loads(line) for line in read(base + "peer/ROS_SOURCE.jsonl").decode().splitlines()]
    goal_report = document(base + "peer/GOAL_REPORT.json")
    result = document(base + "RESULT.json")
    config = document(base + "STACK_CONFIG.json") if (ROOT / (base + "STACK_CONFIG.json")).is_file() else {}
    for source in ("tools/qa_navigation_goal_client.py", "tools/qa_pb_external_navigation_goal.py", "tools/pb_navigation_stack.py"):
        read(base + "source/" + source)
    resize, outside = [], []
    for line_no, line in enumerate(log.splitlines(), 1):
        match = re.search(r"StaticLayer: Resizing costmap to (\d+) X (\d+) at ([0-9.]+) m/pix", line)
        if match:
            resize.append(dict(line=line_no, size_x=int(match[1]), size_y=int(match[2]),
                resolution=float(match[3]), literal=line))
        if "Robot is out of bounds of the costmap!" in line:
            outside.append(dict(line=line_no, literal=line))
    params = {}
    for key in ("minimum_time_interval", "minimum_travel_distance", "minimum_travel_heading", "map_update_interval", "use_scan_matching"):
        values = re.findall(r"^    " + key + r": (.+)$", yaml, re.M)
        if len(values) != 1:
            raise ValueError("parameter_not_unique:" + name + ":" + key)
        params[key] = values[0]
    bad = [r for r in events if r["event"] == "map_geometry_not_ready"]
    good = [r for r in events if r["event"] == "actual_estimate_goal"]
    readiness = [r for r in events if r["event"] == "actual_readiness"]
    kinds = collections.Counter(r["topic_kind"] for r in ros)
    motion_path = base + "GOAL_MOTION_AUDIT.json"
    motion = document(motion_path) if (ROOT / motion_path).is_file() else None
    return dict(run=name, saved_run_passed=result.get("passed"),
        saved_run_check_count=len(result.get("checks", {})),
        mapping_profile=config.get("mapping_profile", "legacy_original_parameters"),
        slam_parameters=params,
        planner_log=dict(resize_count=len(resize), resizes=resize,
            outside_count=len(outside), outside_warnings=outside,
            last_resize=resize[-1] if resize else None),
        first_recorded_geometry_rejection=bad[0] if bad else None,
        accepted_goal_geometry_evaluations=good,
        last_stored_map_attempt=goal_report.get("last_map_attempt"),
        last_stored_map_attempt_scope="last goal-selection attempt, not an end-of-run raw map snapshot",
        last_recorded_readiness=readiness[-1] if readiness else None,
        saved_ros_topic_counts=dict(kinds), saved_scenario_completed=goal_report["completed"],
        saved_goal_motion_audit=motion,
        slam_log_has_per_scan_acceptance_records=False,
        slam_log_lines=len(slam_log.splitlines()))


def main():
    runs = [inspect(name) for name in (
        "goal-velocity-coop-actual-20261015-02",
        "navigation-goal-coop-actual-20261015-04",
        "goal-velocity-coop-actual-20261015-03")]
    # Source material used in the earlier read-only diagnosis. No web fetch is
    # performed by this replay; URLs and inspected release line ranges are explicit.
    source_refs = [
        dict(url="https://raw.githubusercontent.com/SteveMacenski/slam_toolbox/2.6.10/src/slam_toolbox_common.cpp",
            lines="462-505 and 362-384", evidence="distance gate remains after elapsed-time gate; map timer republishes processed scans"),
        dict(url="https://raw.githubusercontent.com/SteveMacenski/slam_toolbox/2.6.10/src/slam_mapper.cpp",
            lines="102-113", evidence="distance and heading parameters are passed to original mapper"),
        dict(url="https://raw.githubusercontent.com/SteveMacenski/slam_toolbox/2.6.10/lib/karto_sdk/src/Mapper.cpp",
            lines="2503-2564 and 2903-2931", evidence="original mapper acceptance and scan storage"),
    ]
    for local in (
        "artifacts/pb2025-humble-environment-20261013/prefix/opt/ros/humble/include/karto_sdk/Karto.h",
        "artifacts/pb2025-humble-environment-20261013/prefix/opt/ros/humble/include/karto_sdk/Mapper.h",
        "artifacts/pb2025-humble-environment-20261013/prefix/opt/ros/humble/share/slam_toolbox/package.xml"):
        read(local)
    before = dict(INPUTS)
    after = {name: digest((ROOT / name).read_bytes()) for name in before}
    if before != after:
        raise RuntimeError("readonly_input_changed_during_diagnosis")
    report = dict(schema="polar.pb.saved-goal-map-diagnosis.v1",
        reading_method="CPython pathlib.read_bytes + json/regex; existing artifact bytes only",
        executed_ros=False, executed_algorithm=False, edited_input_artifacts=False,
        diagnosis_script_sha256=digest(Path(__file__).read_bytes()),
        inputs_before=before, inputs_after=after, inputs_unchanged=before == after,
        upstream_source_references=source_refs,
        upstream_source_fetch_scope="previous read-only inspection; this replay does not fetch or execute upstream code",
        observations=runs,
        interpretation=dict(
            actual02="Real planner emitted 41 outside warnings and only one resize; failure is not solely an observer cache artifact.",
            prior04="Original thresholds also began outside; later true map resizing preceded accepted goals. This is not proof of deterministic startup coverage.",
            actual03="Explicit stationary_scan_accumulation_v1 changed original distance/heading gates to 0.0 while time remained 0.2. Saved maps expanded and the original planner/action/controller chain succeeded.",
            inference_boundary="Logs do not directly count accepted scans. First-scan-only accumulation in actual02 is a source-supported inference, not a directly recorded scan counter. Multiple map publications alone do not prove scan integration.",
            comparison_boundary="Runs differ in startup timing and scans; this is an actual-artifact comparison, not a controlled causal experiment.",
            map_boundary="Last stored map attempt is receipt 2 used for goal selection; last planner resize is a separate later record. No full final raw-map snapshot is invented.",
            feasibility="Geometry readiness checks half-open bounds only. Unknown goal cost 255 in actual03 was left unchanged; actual Smac action results determine feasibility.",
            runtime_risk="Stationary scan accumulation can increase storage and map recomputation; original timing gates and 80/150 ms contracts remain required.",
            scope="Recorded short joint SIL with synthetic relative estimated-map goals; no full match decision tree, hardware or fresh ROS run in this diagnosis."))
    target = OUT / "REPORT.json"
    if target.exists():
        raise ValueError("diagnosis_output_exists")
    target.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf8", newline="\n")
    print(json.dumps(dict(report_sha256=digest(target.read_bytes()), inputs=len(before),
        inputs_unchanged=True, executed_ros=False,
        runs=[dict(run=r["run"], resize_count=r["planner_log"]["resize_count"],
            outside_count=r["planner_log"]["outside_count"], last_resize=r["planner_log"]["last_resize"],
            saved_scenario_completed=r["saved_scenario_completed"]) for r in runs]), indent=2))


if __name__ == "__main__":
    main()
