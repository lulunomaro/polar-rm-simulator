
#include <array>
#include <cassert>
#include <cstdint>
#include <memory>
#include <mutex>
#include <set>
#include <iostream>
namespace rclcpp_action {
using GoalUUID = std::array<uint8_t, 16>;
template<class T> struct ServerGoalHandle {
  GoalUUID uuid{}; bool active=true, canceling=false;
  bool is_active() const {return active;}
  bool is_canceling() const {return canceling;}
  GoalUUID get_goal_id() const {return uuid;}
};
}
template<class ActionT> class Server {
public:
  using Handle=rclcpp_action::ServerGoalHandle<ActionT>;
  mutable std::recursive_mutex update_mutex_;
  bool server_active_=true,stop_execution_=false,preempt_requested_=false;
  std::shared_ptr<Handle> current_handle_,pending_handle_;
  bool is_active(std::shared_ptr<Handle> h) const {return h && h->is_active();}
  rclcpp_action::GoalUUID get_current_goal_id() const {return current_handle_->get_goal_id();}

  // A token owns the actual accepted handle of this compute call, not a
  // subscriber's latest UUID. No lock is held while the algorithm runs.
  struct PolarGoalToken {
    std::shared_ptr<rclcpp_action::ServerGoalHandle<ActionT>> handle;
    rclcpp_action::GoalUUID uuid{};
  };

  PolarGoalToken polar_capture_goal() const
  {
    std::lock_guard<std::recursive_mutex> lock(update_mutex_);
    if (!polar_current_usable_locked()) {return {};}
    return {current_handle_, get_current_goal_id()};
  }

  template<class Publish>
  bool polar_finish_goal(const PolarGoalToken & token, Publish publish)
  {
    std::lock_guard<std::recursive_mutex> lock(update_mutex_);
    if (!token.handle || current_handle_ != token.handle ||
      !polar_current_usable_locked() || get_current_goal_id() != token.uuid)
    {
      return false;
    }
    // Serialize accepted cancel/preempt/deactivate callbacks with publication.
    publish();
    return true;
  }

protected:
  std::set<rclcpp_action::GoalUUID> polar_cancel_accepted_;

  void polar_prune_cancel_ids_locked()
  {
    for (auto it = polar_cancel_accepted_.begin(); it != polar_cancel_accepted_.end(); ) {
      if ((!current_handle_ || current_handle_->get_goal_id() != *it) &&
        (!pending_handle_ || pending_handle_->get_goal_id() != *it))
      {
        it = polar_cancel_accepted_.erase(it);
      } else {++it;}
    }
  }

  bool polar_current_usable_locked() const
  {
    // Upstream is_cancel_requested checks pending instead of current whenever
    // pending exists. Check the actual current handle and reject any preempt.
    return server_active_ && !stop_execution_ && !preempt_requested_ &&
      !is_active(pending_handle_) && is_active(current_handle_) &&
      !current_handle_->is_canceling() &&
      !polar_cancel_accepted_.count(current_handle_->get_goal_id());
  }

public:
  void accept_cancel() {std::lock_guard<std::recursive_mutex> lock(update_mutex_);
    polar_prune_cancel_ids_locked();polar_cancel_accepted_.insert(current_handle_->get_goal_id());}
};
int main() {
  Server<int> s;using H=Server<int>::Handle;
  auto a=std::make_shared<H>();a->uuid[0]=1;s.current_handle_=a;
  int publications=0;auto emit=[&](){++publications;};
  auto token=s.polar_capture_goal();assert(token.handle==a);
  assert(s.polar_finish_goal(token,emit));assert(publications==1);
  s.accept_cancel(); // Real accepted cancel recorded before ROS is_canceling changes.
  assert(!a->canceling);assert(!s.polar_finish_goal(token,emit));
  auto b=std::make_shared<H>();b->uuid[0]=2;s.current_handle_=b;
  assert(!s.polar_finish_goal(token,emit)); // Late old compute cannot borrow new UUID.
  auto next=s.polar_capture_goal();assert(next.handle==b);
  s.preempt_requested_=true;assert(!s.polar_finish_goal(next,emit));s.preempt_requested_=false;
  s.pending_handle_=a;assert(!s.polar_finish_goal(next,emit));s.pending_handle_.reset();
  b->canceling=true;assert(!s.polar_finish_goal(next,emit));b->canceling=false;
  b->active=false;assert(!s.polar_finish_goal(next,emit));b->active=true;
  s.server_active_=false;assert(!s.polar_finish_goal(next,emit));s.server_active_=true;
  s.stop_execution_=true;assert(!s.polar_finish_goal(next,emit));s.stop_execution_=false;
  b->uuid[0]=3;assert(!s.polar_finish_goal(next,emit));b->uuid[0]=2;
  assert(s.polar_finish_goal(next,emit));assert(publications==2);
  assert(!s.polar_finish_goal({},emit));assert(publications==2);
  std::cout<<"goal_gate_actual_cpp: accepted_cancel/late_compute/preempt/pending/inactive/stop/uuid/success passed\n";
}
