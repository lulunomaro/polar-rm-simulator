"""Seal immutable actual UUID/velocity evidence after unchanged-source QA12."""
from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs/validation/goal_velocity_20261015'
BASE='c7c6a0f5c5ad3e2d68e0d8905b2752c6781d51fb'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-12/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for n,h in driver['source_after'].items():assert sha((ROOT/n).read_bytes())==h,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==BASE
assert not OUT.exists(),'Immutable package already exists'
directories=['nav2-goal-controller-source-20261015-01','nav2-goal-controller-build-20261015-01',
 'nav2-goal-controller-focused-20261015-01','pb-goal-navigation-bridge-focused-20261015-01',
 'navigation-goal-consumption-focused-20261015-01','goal-uuid-stack-focused-20261015-01',
 'goal-uuid-stack-focused-20261015-02','goal-map-diagnosis-20261015-01',
 'goal-velocity-config-20261015-01','goal-velocity-config-20261015-02',
 'quality-aim-followup-20261014-12','aim-followup-quality-driver-20261014-12']
directories += [f'goal-velocity-coop-{kind}-20261015-{n:02}' for kind in ('actual','driver') for n in range(1,4)]
sources=['rm_match/integrations/pb_navigation_bridge.py','rm_match/integrations/pb_wsl_navigation.py',
 'rm_match/integrations/pb_wsl_navigation_worker.py','rm_match/integrations/pb_goal_controller_context.hpp',
 'tools/pb_navigation_stack.py','tools/qa_navigation_goal_client.py','tools/qa_pb_navigation_sil.py',
 'tools/prepare_nav2_goal_controller_overlay.py','tools/audit_navigation_goals.py','tools/qa_goal_velocity_coop_sil.py',
 'tests/test_nav2_goal_controller_overlay.py','tests/test_navigation_goal_consumption.py',
 'tests/test_pb_goal_navigation_bridge.py','tests/test_pb_goal_stack_profile.py',
 'docs/NAV2_GOAL_VELOCITY.md','docs/NAVIGATION_GOAL_LIFECYCLE.md','docs/UNIVERSAL_PLUGIN_INTERFACES.md',
 'docs/COOP_PLAYABLE_PATH.md','docs/IMPLEMENTATION_PROGRESS.md',
 'licenses/Apache-2.0.txt','licenses/NAV2_GOAL_CONTROLLER_NOTICE.md',
 'artifacts/fetch_nav2_goal_controller_20261015.py','artifacts/create_goal_velocity_coop_probe_20261015.py',
 'artifacts/create_goal_velocity_driver_20261015.py','artifacts/run_goal_velocity_coop_20261015.py',
 'artifacts/run_stationary_goal_velocity_coop_20261015.py','artifacts/prepare_goal_velocity_actual_20261015.py',
 'artifacts/prepare_stationary_goal_velocity_actual_20261015.py','artifacts/run_goal_uuid_focus_20261015.py',
 'artifacts/run_goal_uuid_focus_20261015_02.py','artifacts/run_aim_followup_quality_20261014.py',
 'artifacts/preserve_goal_velocity_20261015.py']
files=[ROOT/n for n in sources]
for name in directories:
    d=ROOT/'artifacts'/name;assert d.is_dir(),name
    files += [p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
rows=[];excluded=[]
for p in sorted(set(files)):
    name=p.relative_to(ROOT).as_posix();raw=p.read_bytes();reason=None
    if (p.name in {'SDK_EVENTS.jsonl','admission.json','UserData'} or p.name.endswith('.local.json')
        or p.suffix.lower() in {'.key','.pem','.pfx'}):reason='private_or_credential_excluded'
    elif raw[:4]==b'\x7fELF' or raw[:2]==b'MZ' or p.suffix.lower() in {'.exe','.elf','.dll','.so','.a','.o','.onnx'}:
        reason='binary_asset_excluded_source_and_identity_retained'
    if reason:
        excluded.append(dict(path=name,reason=reason));continue
    assert len(raw)<=12*1024*1024,name
    if p.suffix=='.bin':raw.decode('utf8') # Explicit focused text logs, never native binary.
    if p.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:
        assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,name
    compression='gzip' if len(raw)>4096 and p.suffix not in {'.gz','.png'} else 'literal'
    stored=Path('records')/name
    if compression=='gzip':stored=Path(str(stored)+'.gz');data=gzip.compress(raw,mtime=0)
    else:data=raw
    rows.append((stored,data,dict(original_path=name,original_bytes=len(raw),original_sha256=sha(raw),
        stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for path,data,_ in rows:
    target=OUT/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit=BASE,
 qualification='actual standalone Nav2 FollowPath handle UUID to original PB scan/LIO/PID action and physical receipts, offscreen original Qt, synthetic high-level policy; first config/map failures retained; no goal-aware plugin/decision feedback/aim/full-match acceptance',
 records=[r[2] for r in rows],excluded=excluded)
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'* -text -whitespace\n*.gz binary\n*.png binary\n*.bin binary\n')
print(json.dumps(dict(records=len(rows),excluded=len(excluded),original_bytes=sum(r[2]['original_bytes'] for r in rows),
 stored_bytes=sum(r[2]['stored_bytes'] for r in rows),manifest_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()))))
