"""Root-scheduled Windows->WSL real DDS protocol fixture, not navigation."""
from pathlib import Path
import argparse
import base64
import copy
import hashlib
import json
import struct
import sys
import time
import traceback
import uuid

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
ENV_REF=ROOT/'artifacts/pb-humble-ext4-runtime-20261014/ENVIRONMENT_COMPAT_FINAL.json'
ENV_SHA='d60183ebf62d520c72eb20b84207fa4344d8f17183bb0df8eee92f97b7f981ee'
SOURCE_FILES=('tools/robotio_ros2_fixture_node.py','tools/robotio_ros2_fixture_peer.py',
    'rm_match/deployment/robotio_wsl.py','rm_match/deployment/navigation_plugin.py',
    'rm_match/deployment/decision_plugin.py','rm_match/deployment/wsl_jsonl.py',
    'rm_match/deployment/wsl_jsonl_worker.py','rm_match/deployment/wsl_jsonl_owned_tree.py',
    'rm_match/deployment/json_adapter.py','rm_match/deployment/json_owned_process.py',
    'rm_match/deployment/windows_owned_job.py','rm_match/integrations/robotio_ros2_bridge.py',
    'rm_match/integrations/ros2_bridge_transport.py','rm_match/platform_v2/navigation_contracts.py',
    'rm_match/platform_v2/decision_contracts.py','rm_match/platform_v2/contracts.py')

def write(path,value):
    path.write_text(json.dumps(value,allow_nan=False,indent=2)+'\n',encoding='utf8')

def synthetic_observation():
    from rm_match.platform_v2.navigation_contracts import NAV_SCHEMA,NAV_FRAMES,POINT_ENCODING,validate_navigation_observation
    ext=dict(parent_frame='base_link',translation_m=[0.,0.,.5],rotation_xyzw=[0.,0.,0.,1.],calibration_id='synthetic_dds_fixture_mount')
    value=dict(schema=NAV_SCHEMA,robot_id='blue_sentry',episode=4,binding_epoch=8,observed_seq=1,
        sim_time=.1,wall_deadline=time.perf_counter()+.15,frames=dict(NAV_FRAMES),
        own=dict(team='blue',role='sentry',hp=100.,ammo=10.,heat=0.,alive=True),
        referee=dict(phase='running',remaining_seconds=299.,emergency_stop=False),
        sensors=dict(pointcloud=dict(available=True,reason='available',frame_id=1,acquisition_start_ns=0,
            acquisition_end_ns=100000000,capture_sim_time=.1,frame='livox_frame',encoding=POINT_ENCODING,
            point_count=1,data_base64=base64.b64encode(struct.pack('<fffIBBBx',1.,0.,0.,0,24,0x10,0)).decode(),
            range_min_m=.1,range_max_m=20.,time_quantization_ns=2000000,
            provenance='mujoco_ray_cast_nonrepeating_profile_v1',profile_sha256='1'*64,extrinsics=ext),
            imu=dict(available=True,reason='available',frame='livox_frame',capture_sim_time=.1,
                extrinsics=copy.deepcopy(ext),provenance='mujoco_gyro_accelerometer_v1',samples=[dict(
                    sample_sim_ns=t,angular_velocity_rps=[.1,.2,.3],linear_acceleration_mps2=[0.,0.,9.81]) for t in (0,100000000)])))
    # Values obey the codec; provenance strings are schema test values only.
    # No physical sensor was sampled by this driver.
    return validate_navigation_observation(value)

def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--out',required=True)
    parser.add_argument('--run',action='store_true',help='explicit root-scheduled actual WSL/DDS execution')
    args=parser.parse_args()
    if not args.run:raise RuntimeError('candidate_execution_requires_explicit_run')
    out=Path(args.out).absolute()
    if out.exists():raise RuntimeError('fresh_output_required')
    out.mkdir(parents=True)
    started=time.perf_counter();pool=None;claimed=[];checks={};errors=[];code=2;inputs=[]
    try:
        raw=ENV_REF.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=ENV_SHA:raise RuntimeError('frozen_environment_identity_changed')
        env=json.loads(raw);(out/'ENVIRONMENT_COMPAT_FINAL.json').write_bytes(raw)
        for relative in SOURCE_FILES:
            data=(ROOT/relative).read_bytes();target=out/'source'/relative
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            inputs.append(dict(path=relative,size=len(data),sha256=hashlib.sha256(data).hexdigest()))
        write(out/'SOURCE_MANIFEST.json',dict(files=inputs))
        from rm_match.deployment.wsl_jsonl import mounted_path
        from rm_match.deployment.robotio_wsl import PreparedWslPlugins
        from rm_match.deployment.navigation_plugin import CAPABILITIES as NAV_CAPS,validate_result
        from rm_match.deployment.decision_plugin import CAPABILITIES as DEC_CAPS
        from rm_match.platform_v2.decision_contracts import build_decision_observation,validate_decision_intent
        from rm_match.deployment.profile import digest
        token=uuid.uuid4().hex;rows=[]
        for kind,caps,domain in [('navigation',NAV_CAPS,90),('decision',DEC_CAPS,91)]:
            aid='custom_fixture_'+kind;topic='/polar_fixture_'+token+'/'+kind
            command=[env['venv_python'],mounted_path(ROOT/'tools/robotio_ros2_fixture_peer.py'),
                '--adapter-id',aid,'--kind',kind,'--node-name','bridge_'+kind,
                '--observation-topic',topic+'/observation','--action-topic',topic+'/result','--domain-id',str(domain)]
            settings=dict(distribution='Ubuntu-22.04',python=env['venv_python'],
                command=command,cwd=mounted_path(ROOT),process_env=env['process_environment'])
            rows.append(dict(adapter_id=aid,label='Synthetic '+kind+' DDS fixture only',kind=kind,
                command=command,cwd=settings['cwd'],supported_robots=['blue_sentry'],transport='wsl_jsonl_v1',
                capabilities=copy.deepcopy(caps),required_sensors=['pointcloud','imu'] if kind=='navigation' else [],linux=settings))
        manifest=out/'local_manifest.json';write(manifest,dict(schema='polar.sim.fixture-local-components.v1',adapters=rows))
        write(out/'COMMAND.json',dict(host_argv=sys.argv,rows=rows,environment_sha256=ENV_SHA,
            scope='actual WSL DDS synthetic NAV/decision codec only; no physics/NN/controller/navigation'))
        pool=PreparedWslPlugins(rows,manifest=manifest,manifest_sha=digest(manifest),repo_root=ROOT,shared_root=out)
        checks['two_real_prepare_acks']=all(a.prepared for a in pool.instances.values())
        o=synthetic_observation();context={k:o[k] for k in ('episode','robot_id','binding_epoch')}
        for kind in ('navigation','decision'):
            a=pool.take('custom_fixture_'+kind,pool.sha);claimed.append(a)
            start=time.perf_counter();a.reset(context)
            checks[kind+'_reset_under_original_2s']=time.perf_counter()-start<2.
            # Fresh synthetic request; never refresh an actual archived sensor.
            o=synthetic_observation()
            value=o if kind=='navigation' else build_decision_observation(o)
            write(out/(kind+'_synthetic_input.json'),value)
            returned=a.act(value)
            if kind=='navigation':validate_result(returned,o)
            else:validate_decision_intent(returned,value)
            write(out/(kind+'_response.json'),returned)
            checks[kind+'_source_echo']=all(type(returned[k]) is type(value[k]) and returned[k]==value[k]
                for k in ('episode','robot_id','binding_epoch','observed_seq','sim_time','wall_deadline'))
        code=0 if all(checks.values()) else 2
    except BaseException as exc:
        errors.append(type(exc).__name__)
        (out/'traceback.log').write_text(traceback.format_exc(),encoding='utf8')
        if pool is None:pool=getattr(exc,'resources',None)
    finally:
        # One shared host cleanup budget, not a new budget per component.
        deadline=time.perf_counter()+1.5
        cleanup=[]
        for a in claimed:
            try:a.close(deadline=deadline)
            except Exception as exc:errors.append('claimed_cleanup:'+type(exc).__name__)
            cleanup.append(dict(adapter_id=a.descriptor['adapter_id'],proof=a.shutdown_status))
        if pool is not None:
            try:pool.close_unclaimed(deadline=deadline)
            except Exception as exc:errors.append('pool_cleanup:'+type(exc).__name__)
            cleanup.append(dict(unclaimed=pool.cleanup_status))
        write(out/'CLEANUP_RESULT.json',cleanup)
        unchanged=all(hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in inputs)
        if errors or not unchanged:code=2
        write(out/'RESULT.json',dict(exit_code=code,checks=checks,errors=errors,source_unchanged=unchanged,
            elapsed_seconds=time.perf_counter()-started,scope='synthetic protocol DDS; not a team algorithm, NN, physics or navigation qualification'))
    return code

if __name__=='__main__':raise SystemExit(main())
