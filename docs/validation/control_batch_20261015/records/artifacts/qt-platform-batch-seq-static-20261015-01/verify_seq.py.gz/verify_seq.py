"""Pure ACK regression; original SDK methods, no HTTP, Qt or physical run."""
import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import threading
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
PEER = ROOT / 'tools/qa_qt_platform_robotio_peer.py'
CLIENT_ROOT = ROOT / 'external/polar-rm-client-robotio-batch-review'
sys.path.insert(0, str(CLIENT_ROOT))
from rm_client.sim_platform_client import PlatformClient

tree = ast.parse(PEER.read_text(), feature_version=(3, 10))
hook = next(node for node in ast.walk(tree)
            if isinstance(node, ast.FunctionDef) and node.name == 'control_batch')
hook_code = compile(ast.fix_missing_locations(ast.Module(body=[hook], type_ignores=[])), str(PEER), 'exec')
assert b'\r' not in PEER.read_bytes()
assert not any(name.startswith('PySide6') for name in sys.modules)
rid = 'red_infantry'
epochs = dict(motion=1, gimbal=1, fire=1)
window = dict(robot_id=rid, session_id='fixture-session', lease_epochs=epochs,
              window_id=1, issued_wall=100., expires_wall=100.15, valid_for_s=.15)
client = PlatformClient('http://127.0.0.1:10499', control_profile='server_window_v1',
                        diagnostic_clock=lambda: 100.01)
client.role = 'operator'
client.control_batch_version = 1
for channel in epochs:
    client._leases[rid, channel] = 1
    client._seq[rid, channel, 1] = -1  # Original claim initial sequence.
client._bindings[rid, 'navigation'] = 1
client._adapter_seq[rid, 'navigation', 1] = -1  # Original bind initial sequence.
client._windows[rid] = copy.deepcopy(window)
client._window_started[rid] = 100.
requests = []

def request(path, body):
    requests.append(copy.deepcopy(dict(path=path, body=body)))
    return dict(schema='rm.sim.platform.v2', accepted=True, robot_id=rid,
                lease_epochs=copy.deepcopy(epochs), window_id=1, batch_version=1,
                adapter_inputs=[dict(row, accepted=True, robot_id=rid, window_id=1,
                                     activation_expires=100.15) for row in body['adapter_inputs']],
                controls=[dict({k: v for k, v in row.items() if k != 'value'},
                               accepted=True, robot_id=rid, window_id=1, input_expires=100.15)
                          for row in body['controls']])

client._request = request
ack = client.control_batch(rid, {'navigation': 1},
                          {'gimbal': {'yaw_rad': 0., 'pitch_rad': 0.}, 'fire': {'fire': False}},
                          window_id=1)
assert len(requests) == 1
assert [item['seq'] for key in ('adapter_inputs', 'controls') for item in ack[key]] == [0, 0, 0]

def observe(value):
    events, errors, emitted = [], [], []
    state = dict(control_batch_submit_count=0, control_batch_ack_count=0, activation_count=0)
    channels = set()
    env = dict(lock=threading.RLock(), state=state, time=time, copy=copy, math=math,
               args=type('Args', (), dict(robot_id=rid))(), manual_batch_channels=channels,
               wrapped={'control_batch': lambda *a, **kw: value}, last_window={1: copy.deepcopy(window)},
               remember=lambda event, **kw: events.append(dict(event=event, **kw)),
               emit=lambda event, **kw: emitted.append(dict(event=event, **kw)),
               error=lambda phase, exc: errors.append(dict(phase=phase, error=str(exc))))
    exec(hook_code, env)
    returned = env['control_batch'](rid, {'navigation': 1}, {}, window_id=1)
    assert returned is value  # Observational hook never changes ACK.
    return state, errors, emitted, channels

state, errors, emitted, channels = observe(ack)
assert not errors and state['control_batch_ack_count'] == 1
assert state['activation_count'] == 1 and channels == {'gimbal', 'fire'}
assert len(emitted) == 1 and emitted[0]['activation']['seq'] == 0
assert emitted[0]['window'] == window
checks = ['original_SDK_first_batch_generates_three_seq_zero', 'actual_peer_hook_accepts_zero_and_preserves_identity']
for collection, field, value in [
    ('adapter_inputs', 'seq', -1), ('adapter_inputs', 'seq', True), ('adapter_inputs', 'seq', 0.),
    ('controls', 'seq', -1), ('controls', 'seq', True), ('controls', 'seq', 0.),
    ('adapter_inputs', 'binding_epoch', 0), ('adapter_inputs', 'window_id', 0),
    ('controls', 'lease_epoch', 0), ('controls', 'window_id', 0),
]:
    bad = copy.deepcopy(ack)
    bad[collection][0][field] = value
    before = copy.deepcopy(bad)
    state, errors, emitted, channels = observe(bad)
    assert errors and not emitted and not channels and state['control_batch_ack_count'] == 0
    assert bad == before
    checks.append(f'reject_{collection}_{field}_{type(value).__name__}_{value}')

proof = dict(schema='polar.qt.batch-sequence-static.v1', pid=os.getpid(), passed=True,
             scope='Pure ACK fixture only; original SDK call uses intercepted HTTP, no Qt/WSL/physics/NN',
             checks=checks, check_count=len(checks), original_SDK_request=requests[0],
             original_SDK_first_ACK=ack, peer_sha256=hashlib.sha256(PEER.read_bytes()).hexdigest(),
             client_sha256=hashlib.sha256((CLIENT_ROOT/'rm_client/sim_platform_client.py').read_bytes()).hexdigest(),
             before_sha256=hashlib.sha256((OUT/'PEER_BEFORE.py').read_bytes()).hexdigest(),
             ast_python_310=True, source_unchanged=PEER.read_bytes() == (OUT/'PEER_AFTER.py').read_bytes(),
             no_Qt_import=not any(name.startswith('PySide6') for name in sys.modules))
(OUT/'RESULT.json').write_text(json.dumps(proof, allow_nan=False, indent=2)+'\n')
print(json.dumps(dict(passed=True, checks=len(checks), pid=os.getpid(), peer_sha256=proof['peer_sha256'])))
