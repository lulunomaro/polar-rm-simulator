"""Preserve new batch sources and literal execution evidence after final QA."""
from pathlib import Path
import gzip,hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'docs/validation/control_batch_20261015'
def sha(raw):return hashlib.sha256(raw).hexdigest()
driver=json.loads((ROOT/'artifacts/aim-followup-quality-driver-20261014-08/RESULT.json').read_bytes())
assert driver['returncode']==0 and driver['reaped'] and driver['source_unchanged']
for name,expected in driver['source_after'].items():assert sha((ROOT/name).read_bytes())==expected,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='3e6094ce9c2775e7651c6e82ecc549e51a746a54'
assert not OUT.exists(),'Immutable package already exists'
directories=['control-batch-focused-20261015-01','control-batch-sdk-focused-20261015-01',
 'client-robotio-batch-20261015-01','qt-platform-batch-seq-static-20261015-01',
 'qt-control-batch-actual-20261015-01','qt-control-batch-actual-20261015-02',
 'qt-control-batch-driver-20261015-01','qt-control-batch-driver-20261015-02',
 'quality-aim-followup-20261014-08','aim-followup-quality-driver-20261014-08']
files=[]
for name in directories:
    d=ROOT/'artifacts'/name;assert d.is_dir(),name
    files += [p for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}]
source=['DEVELOPMENT_CHANGES.json','rm_match/platform_v2/client.py','rm_match/platform_v2/control.py','rm_match/platform_v2/server.py',
 'tests/test_control_batch.py','tests/test_control_batch_client.py','tools/qa_qt_platform_robotio.py','tools/qa_qt_platform_robotio_peer.py',
 'client_patches/CLIENT_ROBOTIO_BATCH_PATCH_MANIFEST.json','client_patches/robotio_control_batch_v1.patch','client_patches/README.md',
 'examples/coop_robotio_batch_protocol.json','docs/CONTROL_BATCH_INTERFACE.md','docs/CLIENT_ROBOTIO_INTERFACE.md',
 'docs/UNIVERSAL_PLUGIN_INTERFACES.md','docs/IMPLEMENTATION_PROGRESS.md','artifacts/run_qt_control_batch_20261015.py',
 'artifacts/run_batch_sdk_focused_20261015.py','artifacts/update_batch_provenance_20261015.py',
 'artifacts/run_aim_followup_quality_20261014.py','artifacts/preserve_control_batch_20261015.py']
files += [ROOT/name for name in source]
rows=[]
for p in sorted(set(files)):
    original=p.relative_to(ROOT).as_posix();raw=p.read_bytes()
    assert p.suffix.lower() not in {'.exe','.elf','.dll','.onnx','.bin','.key','.pem','.pfx','.git'},original
    assert p.name not in {'SDK_EVENTS.jsonl','admission.json','UserData'} and not p.name.endswith('.local.json'),original
    assert len(raw)<=12*1024*1024,original
    if p.suffix in {'.json','.jsonl','.log','.txt','.stdout','.stderr'}:assert b'"POLAR_SIM_ADMISSION_CREDENTIAL":' not in raw,original
    compression='gzip' if len(raw)>4096 and p.suffix not in {'.gz','.png'} else 'literal'
    stored=Path('records')/original
    if compression=='gzip':stored=Path(str(stored)+'.gz');data=gzip.compress(raw,mtime=0)
    else:data=raw
    rows.append((stored,data,dict(original_path=original,original_bytes=len(raw),original_sha256=sha(raw),
        stored_path=stored.as_posix(),stored_bytes=len(data),stored_sha256=sha(data),compression=compression)))
OUT.mkdir(parents=True)
for stored,data,_ in rows:
    p=OUT/stored;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
manifest=dict(schema='polar.evidence.literal-preservation.v1',parent_commit='3e6094ce9c2775e7651c6e82ecc549e51a746a54',
    qualification='atomic batch tests and two real offscreen window camera SDK MuJoCo short low-rate synthetic protocol passes; no team algorithm/long duration/visible desktop/raw aim80ms/match/milestone acceptance',
    records=[r[2] for r in rows])
(OUT/'PRESERVATION_MANIFEST.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
(OUT/'.gitattributes').write_bytes(b'# Literal evidence/source bytes; no checkout conversion.\n* -text -whitespace\n*.gz binary\n*.png binary\n')
print(json.dumps(dict(records=len(rows),original_bytes=sum(r[2]['original_bytes'] for r in rows),stored_bytes=sum(r[2]['stored_bytes'] for r in rows),manifest_sha256=sha((OUT/'PRESERVATION_MANIFEST.json').read_bytes()))))
