"""Pure CPU operator transport boundary tests; no Qt, renderer or hardware."""
import copy
import unittest
from types import SimpleNamespace

from rm_client.sim_platform_transport import PlatformTransport
from platform_v2_fixtures import frame


class Client:
    uncertain=False;session_id='own-session';control_profile='server_window_v1'
    def __init__(self):self.calls=[]
    def open(self,role):return dict(session_id=self.session_id,role=role)
    def watch(self,rid):self.calls.append(('watch',rid));return dict(watch_epoch=1,robot_id=rid)
    def claim(self,rid,channels):self.calls.append(('claim',rid));return dict(lease_epochs={c:2 for c in channels})
    def release(self,rid,channels):self.calls.append(('release',rid));return {'released':True}
    def renew(self,rid,channels):self.calls.append(('renew',rid));return {}
    def keepalive(self):return {}
    def control(self,*args,**kwargs):self.calls.append(('control',args));return {'accepted':True}


def state(*,owned=False,stamp=1.,server_now=1000.,expires=1001.,alive=True,red_unowned_epoch=0):
    rows=[];leases={};bindings={}
    for team in ('red','blue'):
        for role in ('hero','infantry','sentry'):
            rid=team+'_'+role;row=dict(robot_id=rid,team=team,role=role)
            live=owned and rid=='red_infantry'
            if live:row.update(hp=300.,max_hp=300.,ammo=20.,heat=0.,heat_max=100.,alive=alive,gimbal_yaw=.25,gimbal_pitch=-.1)
            rows.append(row)
            leases[rid]={c:dict(owner='own-session' if live else None,epoch=2 if live else red_unowned_epoch if rid=='red_infantry' else 0,occupied=live,**({'expires':expires,'input':None,'input_expires':0.} if live else {})) for c in ('motion','gimbal','fire')}
            bindings[rid]={k:{'owner':None} for k in ('navigation','aim')}
    return dict(schema='rm.sim.platform.v2',display_schema='polar.sim.display.v2',source='operator_limited_display',
        data_plane='operator_limited_display',state_projection_version=1,algorithm_input=False,sim_time=stamp,
        sample_sim_time=stamp,episode=0,phase='running',remaining_seconds=299.,robots=rows,
        control=dict(robot_ids=[r['robot_id'] for r in rows],leases=leases,bindings=bindings,
                     stopped=False,server_monotonic_s=server_now,revision=1),applied_targets={})


class OperatorProjectionTests(unittest.TestCase):
    def setUp(self):
        self.now=[10.];self.client=Client()
        self.t=PlatformTransport(role='operator',clock=lambda:self.now[0],client=self.client)
        self.t.connect_once();self.t.install_state(state());self.t.watch('red_infantry');self.t.process_jobs()
        self.t.install_state(state());self.t.video=object();self.t.video_at=10.
    def claim(self):
        self.t.request_claim();self.t.process_jobs()
    def own(self,**kwargs):
        self.claim();self.t.install_state(state(owned=True,**kwargs))
    def test_static_roster_and_real_camera_allow_claim_but_cannot_arm(self):
        self.assertTrue(self.t.selection_ready());self.assertIsNone(self.t.snapshot()[0]['own'])
        self.assertFalse(self.t.request_claim());self.t.process_jobs()
        self.assertEqual(self.t.owned_robot,'red_infantry');self.assertFalse(self.t.activate())
        self.assertFalse(any(c[0]=='control' for c in self.client.calls))
        self.t.install_state(state(owned=True));self.assertTrue(self.t.activate())
        self.assertEqual(self.t._angles,[.25,-.1])
    def test_operator_rejects_legacy_truth_and_position_or_enemy_dynamic_data(self):
        values=[]
        legacy=state();legacy['source']='simulator_truth_display_only';values.append(legacy)
        xy=state();xy['robots'][0]['xy']=[0.,0.];values.append(xy)
        enemy=state();enemy['robots'][-1]['hp']=300.;values.append(enemy)
        future=state();future['motion_feedback']={};values.append(future)
        for value in values:
            with self.subTest(value=value),self.assertRaises(ValueError):self.t.install_state(value)
    def test_own_hud_has_no_position_and_enemy_health_or_invented_score(self):
        self.own();data=self.t.snapshot()[0]
        self.assertNotIn('xy',data['own']);self.assertNotIn('chassis_yaw',data['own'])
        self.assertEqual(data['vp'],{'red':None,'blue':None});self.assertFalse(data['map_available'])
        self.assertEqual(set(data['robots'][-1]),{'robot_id','team','role'})
    def test_duplicate_sample_cannot_rejuvenate_own_gimbal(self):
        self.own();self.assertTrue(self.t.activate());self.now[0]+=.4
        self.t.install_state(state(owned=True,server_now=1000.4,expires=1001.4))
        self.now[0]+=.11
        self.assertIsNone(self.t.snapshot()[0]['own']);self.assertFalse(self.t.activate())
    def test_transfer_and_lease_expiry_cannot_rejuvenate_hud(self):
        self.claim();self.t.install_state(state(owned=True,expires=1000.1),request_started=9.85)
        self.assertIsNone(self.t.snapshot()[0]['own']);self.assertFalse(self.t.activate())
    def test_release_or_expired_hud_neutralizes_focus(self):
        self.own();self.assertTrue(self.t.activate())
        # Real release/expiry increments the ACK's epoch 2 to 3.
        self.t.install_state(state(stamp=1.1,red_unowned_epoch=3))
        self.assertFalse(self.t._focus);self.assertIsNone(self.t.owned_robot)
    def test_explicit_local_release_cannot_continue_using_old_hud_cache(self):
        self.own();self.assertTrue(self.t.activate());self.t.neutral('Explicit release')
        self.assertIsNone(self.t.snapshot()[0]['own']);self.assertFalse(self.t.activate())
        self.assertTrue(all(set(r)=={'robot_id','team','role'} for r in self.t.snapshot()[0]['robots']))
    def test_dead_robot_cannot_activate(self):
        self.own(alive=False);self.assertFalse(self.t.activate())
    def test_missing_actual_gimbal_is_rejected(self):
        self.claim();value=state(owned=True)
        del value['robots'][1]['gimbal_yaw']
        with self.assertRaises(ValueError):self.t.install_state(value)
    def test_stale_own_hud_cannot_issue_a_control_window_or_fire(self):
        self.own();self.assertTrue(self.t.activate());self.t.heartbeat(True)
        self.t.submit_input(vx_mps=0,vy_mps=0,fire=True);self.now[0]+=.51
        self.t.control_tick()
        self.assertFalse(self.t._focus);self.assertFalse(any(c[0]=='control' for c in self.client.calls))
    def test_spectator_validation_remains_full_and_strict(self):
        spectator=PlatformTransport(role='spectator',clock=lambda:self.now[0],client=Client());spectator.connect_once()
        with self.assertRaises(ValueError):spectator.install_state(state())
        full=state();full['source']='simulator_truth_display_only';full.pop('data_plane')
        for row in full['robots']:
            row.update(xy=[1.,2.],hp=300.,alive=True,yaw=.5,gimbal_yaw=.2,gimbal_pitch=.1)
        self.assertIsNone(spectator.install_state(full));self.assertEqual(spectator.robot_ids,self.t.robot_ids)
        broken=copy.deepcopy(full);broken['robots'][0].pop('xy')
        with self.assertRaises(ValueError):spectator.install_state(broken)
    def test_operator_camera_before_claim_uses_actual_jpeg_without_exposure_pose(self):
        value=frame(self.t)
        self.assertEqual(value['source'],'operator_camera_display_v1')
        self.assertNotIn('own_odom_at_capture',value)
        self.assertTrue(self.t.install_frame(value,generation=self.t._watch_generation))
        self.assertEqual(self.t.video.shape,(6,8,3));self.assertTrue(self.t.selection_ready())
    def test_operator_camera_rejects_any_world_exposure_field_or_legacy_source(self):
        for key,value in [('xy',[1,2]),('own_qpos_at_capture',[0.]*5),('own_qvel_at_capture',[0.]*5),
                          ('own_odom_at_capture',[0.]*3),('own_odom_velocity_at_capture',[0.]*3),
                          ('source','simulated_raw_camera_display_jpeg')]:
            payload=frame(self.t);payload[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):
                self.t.install_frame(payload,generation=self.t._watch_generation)
    def test_operator_camera_rejects_future_nested_pose_in_calibration_or_image(self):
        for location in ('calibration','image'):
            payload=frame(self.t);payload[location]['world_pose']=[1,2,3]
            with self.subTest(location=location),self.assertRaises(ValueError):
                self.t.install_frame(payload,generation=self.t._watch_generation)
    def test_actual_ui_runtime_can_claim_before_own_hud_then_arm_only_after_hud(self):
        from rm_client.sim_platform_runtime import PlatformRuntime
        runtime=PlatformRuntime(transport=self.t)
        try:
            self.assertFalse(runtime.arm());self.t.process_jobs()
            self.assertFalse(runtime.arm())
            self.t.install_state(state(owned=True));self.assertTrue(runtime.arm())
        finally:runtime._tmp.cleanup()
    def test_actual_model_projection_clears_map_and_released_robot_rows(self):
        from rm_client.sim_platform_runtime import PlatformRuntime
        runtime=PlatformRuntime(transport=self.t);model=SimpleNamespace()
        try:
            runtime.apply_state(model)
            self.assertFalse(model.mujoco_telemetry_valid);self.assertEqual(model.map_robots,[])
            self.own();runtime.apply_state(model)
            self.assertTrue(model.mujoco_telemetry_valid);self.assertEqual(model.current_health,300)
            self.assertEqual(model.map_robots,[]);self.assertEqual(model.map_markers,[])
            self.assertIsNone(model.enemy_victory_points)
            self.assertEqual([row['name'] for row in model.robot_rows],['red_infantry'])
            self.t.install_state(state(stamp=1.1,red_unowned_epoch=3));runtime.apply_state(model)
            self.assertEqual(model.robot_rows,[]);self.assertFalse(model.mujoco_telemetry_valid)
        finally:runtime._tmp.cleanup()


if __name__=='__main__':unittest.main()
