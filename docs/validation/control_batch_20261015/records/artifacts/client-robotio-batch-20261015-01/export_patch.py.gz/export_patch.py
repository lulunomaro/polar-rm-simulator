"""Export an independent fixed-base combination; never overwrite prior files."""
import difflib
import json
from pathlib import Path
import re
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT))
from tools.apply_client_patch import inspect_client,git,source_sha,sha
BASE='0cedf99b70b1beec99865b9980af6789e6c53d99'
CLIENT=ROOT/'external/polar-rm-client-robotio-batch-review'
old_pairs=[(ROOT/'external/polar-rm-client-state-review',ROOT/'client_patches/CLIENT_PATCH_MANIFEST.json'),
           (ROOT/'external/polar-rm-client-robotio-review',ROOT/'client_patches/CLIENT_ROBOTIO_PATCH_MANIFEST.json'),
           (ROOT/'external/polar-rm-client-robotio-state-review',ROOT/'client_patches/CLIENT_ROBOTIO_STATE_PATCH_MANIFEST.json')]
old_records=[]
for checkout,path in old_pairs:
    raw=path.read_bytes();manifest=json.loads(raw);patch=path.parent/manifest['patch_file']
    check=inspect_client(checkout,path)
    old_records.append(dict(checkout=str(checkout),manifest=str(path),manifest_bytes=raw,
        manifest_sha256=sha(raw),patch=str(patch),patch_sha256=sha(patch.read_bytes()),
        source_raw_sha256={name:sha((checkout/name).read_bytes()) for name in manifest['files']},check=check))
baseline=json.loads((HERE/'OLD_IDENTITIES.json').read_bytes())
for observed,expected in zip(old_records,baseline):
    if observed['manifest_sha256']!=expected['manifest_sha256'] or observed['patch_sha256']!=expected['patch_sha256'] or observed['source_raw_sha256']!=expected['files']:
        raise ValueError('old_raw_identity_changed_since_before')
prior=json.loads(old_records[-1]['manifest_bytes'])
if prior['patch_sha256']!='a5f3fccfeb7afd50807e464ca39e5c00f49c77648213872b909f54c6d085ee93':raise ValueError('prior_patch_identity')
if git(CLIENT,'rev-parse','HEAD').decode().strip()!=BASE:raise ValueError('new_base_identity')
new_files={'rm_client/sim_platform_client.py','rm_client/sim_platform_transport.py','rm_client/sim_platform_handoff.py',
           'rm_client/sim_platform_diagnostics.py','tests/test_platform_control_batch.py','tests/test_platform_handoff.py'}
names=set(prior['files'])|new_files
changed={p.decode('utf8') for p in git(CLIENT,'diff','HEAD','--name-only','-z').split(b'\0') if p}
if changed-names:raise ValueError('unexpected_tracked_source')
result=json.loads((HERE/'pytest-after-all/PROCESS_RESULT.json').read_bytes())
if result['exit_code']!=0 or not result['cleanup']['clean'] or not result['reader_stopped'] or not result['source_unchanged']:
    raise ValueError('final_suite_not_clean_pass')
log=(HERE/'pytest-after-all/stdout.log').read_text(encoding='utf8')
match=re.search(r'(\d+) passed, (\d+) subtests passed',log)
if not match:raise ValueError('missing_actual_test_counts')
manifest=dict(schema='polar.sim.own_client_patch.v1',base_commit=BASE,patch_file='robotio_control_batch_v1.patch',
    source_hash_scope='UTF-8 file bytes with CRLF normalized to LF',prior_patch_sha256=prior['patch_sha256'],files={},
    qualification='Fixed-base combined operator/RobotIO/state-order/control-batch patch; explicit advertised version only and original window/deadline/typed ACK gates; offscreen protocol fixtures, not physical/visible GUI/full-match qualification',
    validation=dict(tests_passed=int(match[1]),subtests_passed=int(match[2]),tests_skipped=0,
        qt_platform='offscreen',process_result='artifacts/client-robotio-batch-20261015-01/pytest-after-all/PROCESS_RESULT.json',
        original_operator_projection_preserved=True,original_deadlines_preserved=True,
        physical_ROS_NN_GUI_visible_run=False,actual_prior_window_failure_root_cause_proven=False))
pieces=[];records=[]
for name in sorted(names):
    raw=(CLIENT/name).read_bytes();normalized=raw.replace(b'\r\n',b'\n')
    tracked=bool(git(CLIENT,'ls-tree',BASE,'--',name).strip())
    before=git(CLIENT,'show',BASE+':'+name) if tracked else None
    if name in prior['files'] and (None if before is None else source_sha(before))!=prior['files'][name]['before_sha256']:
        raise ValueError('original_blob_changed:'+name)
    pieces.extend(difflib.unified_diff((b'' if before is None else before.replace(b'\r\n',b'\n')).decode('utf8').splitlines(True),
        normalized.decode('utf8').splitlines(True),fromfile='/dev/null' if before is None else 'a/'+name,tofile='b/'+name))
    reason=prior['files'].get(name,{}).get('reason','Transport safety and deterministic claim/state ordering regression')
    if name=='rm_client/sim_platform_transport.py':reason+='; advertised atomic batch only, all activation ACKs checked before installation, retained post-window fresh sample and focus/own-HUD/session gates'
    if name=='rm_client/sim_platform_client.py':reason+='; batch exact typed full ACK, whole-lock sequence reservation and per-entry request-start local expiry, no retry; duplicate JSON response keys reject'
    if name=='rm_client/sim_platform_handoff.py':reason+='; optional batched cost uses observed batch RTT max and original fixed margins, legacy cost unchanged, neutral reset keeps RTT'
    if name=='rm_client/sim_platform_diagnostics.py':reason+='; credential-free control_batch endpoint diagnostic allowlist'
    if name=='tests/test_platform_handoff.py':reason+='; original single-path routing fixture explicitly removes new capability advertisement; original assertions unchanged'
    if name=='tests/test_platform_control_batch.py':reason='Atomic typed batch SDK, exact expiry/short-TTL, concurrent sequences, original fresh input/focus/revoke, real ControlPlane routing and legacy compatibility regressions; no physics/NN'
    manifest['files'][name]=dict(before_sha256=None if before is None else source_sha(before),after_sha256=source_sha(raw),
        after_checkout_sha256=sha(raw),reason=reason)
    if name in new_files:
        target=HERE/'final'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    records.append(dict(path=name,raw_sha256=sha(raw)))
patch=''.join(pieces).encode('utf8');manifest['patch_sha256']=sha(patch)
patch_path=ROOT/'client_patches'/manifest['patch_file'];manifest_path=ROOT/'client_patches/CLIENT_ROBOTIO_BATCH_PATCH_MANIFEST.json'
if patch_path.exists() or manifest_path.exists():raise ValueError('new_export_already_exists')
patch_path.write_bytes(patch);manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8',newline='\n')
new_check=inspect_client(CLIENT,manifest_path);git(CLIENT,'apply','--reverse','--check',str(patch_path))
for row in old_records:
    if Path(row['manifest']).read_bytes()!=row['manifest_bytes'] or sha(Path(row['patch']).read_bytes())!=row['patch_sha256']:
        raise ValueError('old_patch_changed')
    if any(sha((Path(row['checkout'])/name).read_bytes())!=value for name,value in row['source_raw_sha256'].items()):raise ValueError('old_checkout_changed')
    inspect_client(row['checkout'],row['manifest']);row.pop('manifest_bytes')
proof=dict(new_manifest_sha256=sha(manifest_path.read_bytes()),new_patch_sha256=sha(patch),
    new_checkout_check=new_check,reverse_apply_check=True,old_patch_checkout_unchanged=True,
    old_checks=old_records,files=records,export_script_sha256=sha(Path(__file__).read_bytes()))
(HERE/'EXPORT_PROOF.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items() if k not in ('old_checks','files')},indent=2))
