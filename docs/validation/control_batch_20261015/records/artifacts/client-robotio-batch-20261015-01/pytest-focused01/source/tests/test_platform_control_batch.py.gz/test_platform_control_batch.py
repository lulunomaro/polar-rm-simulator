"""Advertised atomic protocol and fake-clock Qt scheduling; no physics/GL/NN."""
import copy
import json
import threading
import unittest
from unittest.mock import patch

from rm_client.sim_platform_client import PlatformClient,ClientError,SCHEMA
from rm_client.sim_platform_handoff import HandoffSchedule
from rm_client.sim_platform_transport import PlatformTransport
from platform_v2_fixtures import state,install_owned_state
from test_platform_control_windows import WindowClient
from test_platform_adapters import catalog

CHANNELS=('motion','gimbal','fire')
MOTION=dict(frame='base_link',vx_mps=.25,vy_mps=0.,wz_rps=0.)
GIMBAL=dict(frame='base_link',yaw_rad=.1,pitch_rad=.05)
FIRE=dict(fire=False)

class Wire:
    def __init__(self,advertised=1):
        self.now=10.;self.advertised=advertised;self.sent=[];self.mutation=None;self.ack_delay=0.;self.on_batch=None
        self.client=PlatformClient('http://127.0.0.1:8766',control_profile='server_window_v1',diagnostic_clock=lambda:self.now)
        self.client._request=self.request
    def request(self,path,body=None,**kwargs):
        self.sent.append((path,copy.deepcopy(body)))
        if path=='/v2/sessions':
            r=dict(schema=SCHEMA,token='synthetic',session_id='s',role=body['role'],session_expires=101.,server_monotonic_s=100.,
                control_profile='server_window_v1',control_window_version=1,control_window_ttl_s=.15)
            if self.advertised!='missing':r['control_batch_version']=self.advertised
            return r
        if path=='/v2/claim':return dict(schema=SCHEMA,robot_id=body['robot_id'],lease_epochs={c:2 for c in body['channels']},lease_expires={c:101. for c in body['channels']})
        if path=='/v2/bind':return dict(schema=SCHEMA,robot_id=body['robot_id'],kind=body['kind'],adapter_id=body['adapter_id'],binding_epoch=3,activation_required=True,activation_version=1)
        if path=='/v2/control_window':return dict(schema=SCHEMA,robot_id=body['robot_id'],session_id='s',lease_epochs=body['lease_epochs'],window_id=4,issued_wall=1000.,expires_wall=1000.15,valid_for_s=.15)
        if path=='/v2/control_batch':
            r=dict(schema=SCHEMA,accepted=True,robot_id=body['robot_id'],lease_epochs=body['lease_epochs'],window_id=body['window_id'],batch_version=1,adapter_inputs=[],controls=[])
            for sent in body['adapter_inputs']:
                r['adapter_inputs'].append(dict(accepted=True,robot_id=body['robot_id'],window_id=body['window_id'],activation_expires=1000.+body['valid_for_s'],**sent))
            for sent in body['controls']:
                r['controls'].append(dict(accepted=True,robot_id=body['robot_id'],window_id=body['window_id'],input_expires=1000.+body['valid_for_s'],**{k:v for k,v in sent.items() if k!='value'}))
            self.now+=self.ack_delay
            if self.on_batch:self.on_batch()
            if self.mutation:self.mutation(r)
            return r
        raise AssertionError(path)
    def ready(self,bindings=('navigation','aim')):
        c=self.client;c.open('operator');c.claim('red_infantry',CHANNELS)
        for k in bindings:c.bind('red_infantry',k,'custom_'+k,{})
        c.control_window('red_infantry',CHANNELS);return c

class BatchSDKTests(unittest.TestCase):
    def test_complete_two_kind_wire_and_manual_fire_ack(self):
        w=Wire();c=w.ready();r=c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
        path,body=w.sent[-1];self.assertEqual(path,'/v2/control_batch')
        self.assertEqual(set(body),{'robot_id','lease_epochs','window_id','valid_for_s','adapter_inputs','controls'})
        self.assertEqual(body['lease_epochs'],{k:2 for k in CHANNELS});self.assertEqual([p['kind'] for p in r['adapter_inputs']],['navigation','aim'])
        self.assertEqual(body['controls'],[dict(channel='fire',lease_epoch=2,seq=0,value=FIRE)])
        self.assertFalse(c.uncertain)
    def test_manual_and_one_kind_coverage(self):
        for kinds,controls in [({},dict(motion=MOTION,gimbal=GIMBAL,fire=FIRE)),({'navigation':3},dict(gimbal=GIMBAL,fire=FIRE)),({'aim':3},dict(motion=MOTION,fire=FIRE))]:
            with self.subTest(kinds=kinds):
                w=Wire();c=w.ready(tuple(kinds));r=c.control_batch('red_infantry',kinds,controls,window_id=4)
                self.assertEqual(len(r['adapter_inputs'])+len(r['controls']),3)
    def test_missing_capability_old_method_only(self):
        w=Wire('missing');c=w.ready();count=len(w.sent)
        with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
        self.assertEqual(count,len(w.sent));self.assertIsNone(c.control_batch_version)
    def test_unknown_and_untyped_advertisement_fail_closed(self):
        for value in (True,1.,0,2,None,'1'):
            with self.subTest(value=value):
                w=Wire(value)
                with self.assertRaises(ClientError):w.client.open('operator')
                self.assertTrue(w.client.uncertain)
    def test_complete_current_window_binding_and_nonoverlap_required(self):
        for kinds,controls in [({'navigation':3},dict(fire=FIRE)),({'navigation':3},dict(motion=MOTION,gimbal=GIMBAL,fire=FIRE)),({'wrong':3},dict(gimbal=GIMBAL,fire=FIRE)),({'navigation':True},dict(gimbal=GIMBAL,fire=FIRE)),({'navigation':4},dict(gimbal=GIMBAL,fire=FIRE))]:
            with self.subTest(kinds=kinds):
                w=Wire();c=w.ready();count=len(w.sent)
                with self.assertRaises((ClientError,ValueError)):c.control_batch('red_infantry',kinds,controls,window_id=4)
                self.assertEqual(count,len(w.sent))
        w=Wire();c=w.ready();c._windows['red_infantry']['lease_epochs'].pop('fire')
        with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
    def test_all_ack_fields_types_lengths_and_expiries_no_partial_install_no_retry(self):
        mutations=[lambda r:r.update(extra=True),lambda r:r.pop('accepted'),lambda r:r.update(accepted=1),lambda r:r.update(batch_version=True),
            lambda r:r.update(window_id=3),lambda r:r.update(robot_id='blue_sentry'),lambda r:r['lease_epochs'].update(fire=True),
            lambda r:r['controls'].clear(),lambda r:r['adapter_inputs'].append(copy.deepcopy(r['adapter_inputs'][0])),
            lambda r:r['adapter_inputs'][1].update(binding_epoch=True),lambda r:r['adapter_inputs'][0].update(seq=99),
            lambda r:r['adapter_inputs'][0].update(kind='aim'),lambda r:r['adapter_inputs'][0].update(activation_expires=float('nan')),
            lambda r:r['adapter_inputs'][0].update(activation_expires=1000.),lambda r:r['controls'][0].update(input_expires=1000.151),
            lambda r:r['controls'][0].update(value=FIRE),lambda r:r['controls'][0].update(lease_epoch=3)]
        for mutation in mutations:
            with self.subTest(mutation=mutations.index(mutation)):
                w=Wire();c=w.ready();w.mutation=mutation
                with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
                self.assertTrue(c.uncertain)
                with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
                self.assertEqual(1,sum(path=='/v2/control_batch' for path,_ in w.sent))
    def test_short_entry_deadline_and_request_start_anchor(self):
        for delay in (.01,.011):
            with self.subTest(delay=delay):
                w=Wire();c=w.ready();w.ack_delay=delay
                with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4,valid_for_s=.01)
                self.assertTrue(c.uncertain)
        w=Wire();c=w.ready();w.now+=.149;w.ack_delay=.002
        with self.assertRaises(ClientError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
    def test_seqs_reserved_once_even_on_transport_failure(self):
        w=Wire();c=w.ready();w.on_batch=lambda:(_ for _ in ()).throw(OSError('fixture'))
        with self.assertRaises(OSError):c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
        self.assertTrue(c.uncertain);self.assertEqual(0,c._adapter_seq['red_infantry','aim',3]);self.assertEqual(0,c._seq['red_infantry','fire',2])
    def test_concurrent_batches_lock_reserves_all_three_monotone_seqs(self):
        w=Wire();c=w.ready();entered=threading.Event();release=threading.Event();errors=[]
        def wait_once():
            if not entered.is_set():entered.set();self.assertTrue(release.wait(1.))
        w.on_batch=wait_once
        def send():
            try:c.control_batch('red_infantry',{'navigation':3,'aim':3},{'fire':FIRE},window_id=4)
            except BaseException as exc:errors.append(type(exc).__name__)
        a=threading.Thread(target=send);b=threading.Thread(target=send);a.start();self.assertTrue(entered.wait(1.));b.start();release.set();a.join(1.);b.join(1.)
        self.assertFalse(a.is_alive() or b.is_alive());self.assertEqual(errors,[])
        rows=[r for path,r in w.sent if path=='/v2/control_batch'];self.assertEqual([p['controls'][0]['seq'] for p in rows],[0,1])
        self.assertEqual([[p['seq'] for p in r['adapter_inputs']] for r in rows],[[0,0],[1,1]])

class BatchClient(WindowClient):
    def __init__(self,batch=True):super().__init__();self.batch=batch;self.binding=0;self.on_batch=None
    def open(self,role):
        r=super().open(role)
        if self.batch:r['control_batch_version']=1
        return r
    def bind(self,rid,kind,adapter_id,config):
        self.binding+=1;self.calls.append(('bind',rid,kind));return dict(binding_epoch=self.binding)
    def control_batch(self,rid,adapter_inputs,controls,*,window_id,valid_for_s):
        self.calls.append(('batch',rid,copy.deepcopy(adapter_inputs),copy.deepcopy(controls),window_id))
        r=dict(adapter_inputs=[dict(kind=k,window_id=window_id,activation_expires=900000.15) for k in adapter_inputs])
        if self.on_batch:self.on_batch()
        return r

class BatchTransportTests(unittest.TestCase):
    def ready(self,plan=None,batch=True):
        self.now=[100.];self.c=BatchClient(batch);t=self.t=PlatformTransport(role='operator',client=self.c,clock=lambda:self.now[0])
        t.connect_once();t.install_state(state());t.watch('red_infantry');t.process_jobs();t.install_state(state());t.video=object();t.video_at=100.
        t.install_catalog(catalog(),connection_generation=t._connection_generation,serial=1)
        if plan:t.configure_adapters(plan,{'V2 Goal X':.75})
        t.request_claim();t.process_jobs();install_owned_state(t);t.activate();self.sample()
        if plan:t.control_tick()
        self.sample();t.control_tick()
        return t
    def sample(self):self.t.heartbeat(True);self.t.submit_input(vx_mps=.25,vy_mps=0.,fire=False)
    def batches(self):return [c for c in self.c.calls if c[0]=='batch']
    def test_ack_window_requires_new_keyboard_sample(self):
        t=self.ready();t.control_tick();self.assertEqual(self.batches(),[])
        t.submit_mouse(.02,.01);t.control_tick();self.assertEqual(self.batches(),[])
        self.sample();t.control_tick();self.assertEqual(len(self.batches()),1)
        self.assertEqual(set(self.batches()[0][3]),set(CHANNELS));t.control_tick();self.assertEqual(len(self.batches()),1)
    def test_navigation_manual_gimbal_fire_and_dual_kind_all_acknowledged(self):
        for plan,expected in [({'navigation':'nav_rule_v1'},{'gimbal','fire'}),({'navigation':'nav_rule_v1','aim':'aim_pixel_baseline_v1'},{'fire'})]:
            with self.subTest(plan=plan):
                t=self.ready(plan);self.sample();t.control_tick()
                batch=self.batches()[-1];self.assertEqual(set(batch[2]),set(plan));self.assertEqual(set(batch[3]),expected)
                self.assertEqual(set(t._activation_acks),set(plan));self.assertEqual(t._handoff.population_acked,set(plan));self.assertEqual(t._handoff.phase,'CURRENT')
                self.assertFalse(any(c[0]=='control' for c in self.c.calls))
    def test_focus_or_watch_loss_during_batch_ack_never_restores(self):
        for hook in (lambda t:t.neutral('blur'),lambda t:t.watch('blue_hero'),lambda t:t._failed(ValueError('lost session'))):
            with self.subTest(hook=hook):
                t=self.ready({'navigation':'nav_rule_v1'});self.c.on_batch=lambda:hook(t);self.sample();t.control_tick()
                self.assertFalse(t._focus);self.assertEqual(t._activation_acks,{});self.assertIsNone(t._window)
    def test_expired_ack_never_finishes_or_refreshes_window(self):
        t=self.ready();deadline=t._window_deadline;self.c.on_batch=lambda:self.now.__setitem__(0,deadline);self.sample();t.control_tick()
        self.assertFalse(t._focus);self.assertIsNone(t._window);self.assertEqual(t._batch_revision,-1)
    def test_missing_advertisement_preserves_single_path(self):
        t=self.ready(batch=False);self.sample();t.control_tick();self.assertEqual(self.batches(),[])
        self.assertEqual([c[2] for c in self.c.calls if c[0]=='control'],list(CHANNELS))

class BatchBudgetTests(unittest.TestCase):
    def test_explicit_batch_uses_one_rtt_old_formula_unchanged_and_reset_preserves(self):
        p=HandoffSchedule();old=p.cost(2,1);self.assertAlmostEqual(old,.07)
        p.observe('pulse',0.,.1);p.observe('batch',0.,.035)
        self.assertAlmostEqual(p.cost(2,1,batched=True),.075)
        self.assertGreater(p.cost(2,1),.15);self.assertEqual(p.next_action(0.,kinds=2,controls=1,fresh=True),'budget_pressure')
        self.assertEqual(p.next_action(0.,kinds=2,controls=1,fresh=True,batched=True),'fetch')
        p.reset();self.assertEqual(p.costs['batch'],.035)
    def test_slow_batch_stops_budget_without_relaxing_ttl(self):
        p=HandoffSchedule();p.observe('batch',0.,.12)
        self.assertEqual(p.next_action(0.,kinds=2,controls=1,fresh=True,batched=True),'budget_pressure')

if __name__=='__main__':unittest.main()
